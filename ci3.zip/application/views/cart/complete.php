<h1 class="content-title page-title">
Ваш Заказ № <?=$order_id?>
</h1>

<div id="flash_messages">
    <div class="message">
        <p class="notice notice--info">
    Спасибо, Ваш заказ принят. В ближайшее время наши менеджеры обязательно свяжутся с Вами.
        </p>
    </div>
</div>
<div class="line"></div>