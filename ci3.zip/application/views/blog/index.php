<h2><?=$this->lang->line('header_menu_blog');?></h2>
<?php $this->load->view('widgets/posts',$data); ?>