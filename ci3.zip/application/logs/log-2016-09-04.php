<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-09-04 12:48:34 --> 404 Page Not Found --> admin
ERROR - 2016-09-04 12:48:45 --> Severity: Warning  --> scandir(): Directory name cannot be empty D:\openserver\domains\ci3\application\models\gallery_model.php 50
ERROR - 2016-09-04 12:48:45 --> Severity: Warning  --> array_diff(): Argument #1 is not an array D:\openserver\domains\ci3\application\models\gallery_model.php 51
ERROR - 2016-09-04 12:48:45 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\models\gallery_model.php 55
ERROR - 2016-09-04 12:49:30 --> Severity: Notice  --> Undefined variable: status D:\openserver\domains\ci3\application\modules\orders\views\form.php 131
ERROR - 2016-09-04 12:49:30 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\system\helpers\form_helper.php 332
ERROR - 2016-09-04 12:51:28 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-04 12:53:09 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-04 12:53:35 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-04 12:54:42 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-04 13:15:29 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 13:16:18 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 13:38:55 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 13:39:00 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 13:39:12 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 13:43:58 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 13:44:29 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 13:52:59 --> Severity: Notice  --> Undefined index: post_comment_status D:\openserver\domains\ci3\application\modules\posts\views\view.php 87
ERROR - 2016-09-04 13:52:59 --> Severity: Notice  --> Undefined index: post_comment_status D:\openserver\domains\ci3\application\modules\posts\views\view.php 87
ERROR - 2016-09-04 13:53:00 --> Severity: Notice  --> Undefined index: post_comment_status D:\openserver\domains\ci3\application\modules\posts\views\view.php 87
ERROR - 2016-09-04 13:53:00 --> Severity: Notice  --> Undefined index: post_comment_status D:\openserver\domains\ci3\application\modules\posts\views\view.php 87
ERROR - 2016-09-04 13:53:00 --> Severity: Notice  --> Undefined index: post_comment_status D:\openserver\domains\ci3\application\modules\posts\views\view.php 87
ERROR - 2016-09-04 13:53:00 --> Severity: Notice  --> Undefined index: post_comment_status D:\openserver\domains\ci3\application\modules\posts\views\view.php 87
ERROR - 2016-09-04 13:53:00 --> Severity: Notice  --> Undefined index: post_comment_status D:\openserver\domains\ci3\application\modules\posts\views\view.php 87
ERROR - 2016-09-04 13:53:00 --> Severity: Notice  --> Undefined index: post_comment_status D:\openserver\domains\ci3\application\modules\posts\views\view.php 87
ERROR - 2016-09-04 13:53:00 --> Severity: Notice  --> Undefined index: post_comment_status D:\openserver\domains\ci3\application\modules\posts\views\view.php 87
ERROR - 2016-09-04 13:53:00 --> Severity: Notice  --> Undefined index: post_comment_status D:\openserver\domains\ci3\application\modules\posts\views\view.php 87
ERROR - 2016-09-04 13:55:58 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 13:55:58 --> Query error: Unknown column 'post_comment_status' in 'field list'
ERROR - 2016-09-04 13:55:58 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-04 13:55:58 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-04 13:57:25 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 13:57:25 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`myshop`.`posts`, CONSTRAINT `fk_posts_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE)
ERROR - 2016-09-04 13:57:25 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-04 13:57:25 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-04 13:57:33 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 13:57:33 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`myshop`.`posts`, CONSTRAINT `fk_posts_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE)
ERROR - 2016-09-04 13:57:33 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-04 13:57:33 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-04 13:58:36 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 13:58:36 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`myshop`.`posts`, CONSTRAINT `fk_posts_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE)
ERROR - 2016-09-04 13:58:36 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-04 13:58:36 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-04 14:02:20 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 14:02:20 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`myshop`.`posts`, CONSTRAINT `fk_posts_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE)
ERROR - 2016-09-04 14:02:20 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-04 14:02:20 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-04 14:03:33 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 14:55:16 --> Severity: Notice  --> Undefined variable: category D:\openserver\domains\ci3\application\modules\products\views\form.php 25
ERROR - 2016-09-04 14:55:16 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\system\helpers\form_helper.php 332
ERROR - 2016-09-04 14:55:16 --> Severity: Notice  --> Undefined variable: product_properties D:\openserver\domains\ci3\application\modules\products\views\form.php 154
ERROR - 2016-09-04 14:55:16 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\system\helpers\form_helper.php 332
ERROR - 2016-09-04 14:57:57 --> Severity: Notice  --> Undefined variable: product_properties D:\openserver\domains\ci3\application\modules\products\views\form.php 154
ERROR - 2016-09-04 14:57:57 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\system\helpers\form_helper.php 332
ERROR - 2016-09-04 14:58:40 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-04 15:00:23 --> Severity: Notice  --> Undefined index: category_title D:\openserver\domains\ci3\application\modules\products\views\form.php 26
ERROR - 2016-09-04 15:01:19 --> Severity: Notice  --> Undefined index: category_title D:\openserver\domains\ci3\application\modules\products\views\form.php 26
ERROR - 2016-09-04 15:01:27 --> Severity: Notice  --> Undefined index: category_title D:\openserver\domains\ci3\application\modules\products\views\form.php 26
ERROR - 2016-09-04 15:01:43 --> Severity: Notice  --> Undefined property: stdClass::$catalog_title D:\openserver\domains\ci3\application\modules\products\models\productss.php 376
ERROR - 2016-09-04 15:01:43 --> Severity: Notice  --> Undefined index: category_title D:\openserver\domains\ci3\application\modules\products\views\form.php 26
ERROR - 2016-09-04 15:02:20 --> Severity: Notice  --> Undefined index: category_title D:\openserver\domains\ci3\application\modules\products\views\form.php 26
ERROR - 2016-09-04 15:02:41 --> Severity: Notice  --> Undefined index: category_title D:\openserver\domains\ci3\application\modules\products\views\form.php 26
ERROR - 2016-09-04 15:03:35 --> Severity: Notice  --> Undefined index: category_title D:\openserver\domains\ci3\application\modules\products\views\form.php 26
ERROR - 2016-09-04 15:03:52 --> Severity: Notice  --> Undefined index: category_title D:\openserver\domains\ci3\application\modules\products\views\form.php 26
ERROR - 2016-09-04 15:03:58 --> Severity: Notice  --> Undefined index: category_title D:\openserver\domains\ci3\application\modules\products\views\form.php 26
ERROR - 2016-09-04 15:05:29 --> Severity: Notice  --> Undefined index: category_title D:\openserver\domains\ci3\application\modules\products\views\form.php 22
ERROR - 2016-09-04 15:05:29 --> Severity: Notice  --> Undefined index: category_title D:\openserver\domains\ci3\application\modules\products\views\form.php 26
ERROR - 2016-09-04 15:07:03 --> Severity: Notice  --> Undefined index: category_title D:\openserver\domains\ci3\application\modules\products\views\form.php 22
ERROR - 2016-09-04 15:07:23 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-04 15:09:12 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-04 15:25:55 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-04 15:28:58 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-04 15:43:36 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-04 15:44:52 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-04 15:51:47 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 15:51:47 --> Could not find the language line "required"
ERROR - 2016-09-04 15:53:07 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-04 15:53:46 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-04 15:56:43 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-04 16:02:22 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-04 16:09:02 --> Severity: Notice  --> Use of undefined constant id - assumed 'id' D:\openserver\domains\ci3\application\modules\products\views\form.php 146
ERROR - 2016-09-04 16:09:02 --> Severity: Notice  --> Use of undefined constant id - assumed 'id' D:\openserver\domains\ci3\application\modules\products\views\form.php 146
ERROR - 2016-09-04 16:09:02 --> Severity: Notice  --> Use of undefined constant id - assumed 'id' D:\openserver\domains\ci3\application\modules\products\views\form.php 146
ERROR - 2016-09-04 16:09:02 --> Severity: Notice  --> Use of undefined constant id - assumed 'id' D:\openserver\domains\ci3\application\modules\products\views\form.php 146
ERROR - 2016-09-04 16:09:18 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-04 17:20:44 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 17:20:44 --> Severity: Warning  --> trim() expects parameter 1 to be string, array given D:\openserver\domains\ci3\system\libraries\Form_validation.php 620
ERROR - 2016-09-04 17:20:44 --> Could not find the language line "required"
ERROR - 2016-09-04 17:21:44 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 17:29:03 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 17:29:32 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 17:41:52 --> Severity: Notice  --> Undefined variable: product_properties D:\openserver\domains\ci3\application\modules\products\views\form.php 151
ERROR - 2016-09-04 17:41:52 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\openserver\domains\ci3\application\modules\products\views\form.php 151
ERROR - 2016-09-04 17:41:52 --> Severity: Notice  --> Undefined variable: product_properties D:\openserver\domains\ci3\application\modules\products\views\form.php 151
ERROR - 2016-09-04 17:41:52 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\openserver\domains\ci3\application\modules\products\views\form.php 151
ERROR - 2016-09-04 17:41:52 --> Severity: Notice  --> Undefined variable: product_properties D:\openserver\domains\ci3\application\modules\products\views\form.php 151
ERROR - 2016-09-04 17:41:52 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\openserver\domains\ci3\application\modules\products\views\form.php 151
ERROR - 2016-09-04 17:41:52 --> Severity: Notice  --> Undefined variable: product_properties D:\openserver\domains\ci3\application\modules\products\views\form.php 151
ERROR - 2016-09-04 17:41:52 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\openserver\domains\ci3\application\modules\products\views\form.php 151
ERROR - 2016-09-04 17:43:38 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 17:44:45 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-04 17:46:51 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-04 17:48:03 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-04 17:50:56 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-04 17:51:23 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-04 17:52:48 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-04 17:52:59 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 17:52:59 --> Severity: Warning  --> strip_tags() expects parameter 1 to be string, array given D:\openserver\domains\ci3\application\modules\products\models\productss.php 328
ERROR - 2016-09-04 17:52:59 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-04 17:52:59 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-04 17:54:31 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 17:54:54 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 17:55:34 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 18:14:48 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 18:15:25 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 18:15:25 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 18:15:25 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 18:15:25 --> upload_no_file_selected
ERROR - 2016-09-04 18:15:25 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 18:15:41 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 18:15:41 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 18:15:41 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 18:15:41 --> upload_no_file_selected
ERROR - 2016-09-04 18:15:41 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 18:15:41 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 18:15:41 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 18:15:41 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 18:17:29 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 18:17:29 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 18:17:29 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 18:17:29 --> upload_no_file_selected
ERROR - 2016-09-04 18:17:29 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 18:17:29 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 18:17:29 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 18:17:29 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 18:21:01 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-04 18:22:39 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 18:22:39 --> Could not find the language line "required"
ERROR - 2016-09-04 18:22:51 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 18:22:51 --> Could not find the language line "required"
ERROR - 2016-09-04 18:24:05 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 18:24:05 --> Could not find the language line "required"
ERROR - 2016-09-04 18:27:23 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 18:27:23 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 18:27:23 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 18:27:23 --> upload_no_file_selected
ERROR - 2016-09-04 18:27:23 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 18:27:23 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 18:27:23 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 18:27:23 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 18:28:30 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 18:28:30 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 18:28:30 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 18:28:30 --> upload_no_file_selected
ERROR - 2016-09-04 18:28:30 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 18:28:30 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 18:28:30 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 18:28:30 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 18:29:24 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-04 18:31:45 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 18:31:45 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 18:31:45 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 18:31:45 --> upload_no_file_selected
ERROR - 2016-09-04 18:31:45 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 18:31:45 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 18:31:45 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 18:31:45 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 18:36:13 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 18:36:13 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 18:36:13 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 18:36:13 --> upload_no_file_selected
ERROR - 2016-09-04 18:36:13 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 18:36:13 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 18:36:13 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 18:36:13 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 18:38:06 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-04 18:39:34 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-04 18:39:41 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 18:42:35 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-04 18:48:56 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-04 18:51:05 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-04 19:04:40 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 19:04:40 --> Severity: Notice  --> Undefined property: product_properties::$Gallery_model D:\openserver\domains\ci3\application\modules\product_properties\controllers\product_properties.php 140
ERROR - 2016-09-04 19:05:09 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 19:05:09 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 19:05:09 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 19:05:09 --> upload_no_file_selected
ERROR - 2016-09-04 19:05:09 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 19:05:09 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 19:05:09 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 19:05:09 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 19:05:21 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 19:05:21 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 19:05:21 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 19:05:21 --> upload_no_file_selected
ERROR - 2016-09-04 19:05:21 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 19:05:21 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 19:05:21 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 19:05:21 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 19:06:49 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 19:06:49 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 19:06:49 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 19:06:49 --> upload_no_file_selected
ERROR - 2016-09-04 19:06:49 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 19:06:49 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 19:06:49 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 19:06:49 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 19:07:00 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 19:07:00 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 19:07:00 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 19:07:00 --> upload_no_file_selected
ERROR - 2016-09-04 19:07:00 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 19:07:00 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 19:07:00 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 19:07:00 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 19:10:02 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 19:10:02 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 19:10:02 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 19:10:02 --> upload_no_file_selected
ERROR - 2016-09-04 19:10:02 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 19:10:02 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 19:10:02 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 19:10:02 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 19:10:13 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 19:10:13 --> Could not find the language line "required"
ERROR - 2016-09-04 19:10:59 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 19:10:59 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 19:10:59 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 19:10:59 --> upload_no_file_selected
ERROR - 2016-09-04 19:10:59 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 19:10:59 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 19:10:59 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 19:10:59 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 19:11:08 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 19:11:08 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 19:11:08 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 19:11:08 --> upload_no_file_selected
ERROR - 2016-09-04 19:11:08 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 19:11:08 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 19:11:08 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 19:11:08 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 19:14:53 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 19:14:53 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 19:14:53 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 19:14:53 --> upload_no_file_selected
ERROR - 2016-09-04 19:14:53 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 19:14:53 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 19:14:53 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 19:14:53 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 19:16:19 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 19:16:19 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 19:16:19 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 19:16:19 --> upload_no_file_selected
ERROR - 2016-09-04 19:16:19 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 19:16:19 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 19:16:19 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 19:16:19 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 19:16:39 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 19:16:39 --> Severity: Warning  --> Missing argument 1 for Gallery_model::do_upload(), called in D:\openserver\domains\ci3\application\modules\product_properties\controllers\product_properties.php on line 138 and defined D:\openserver\domains\ci3\application\models\gallery_model.php 16
ERROR - 2016-09-04 19:16:39 --> Severity: Notice  --> Undefined variable: filename D:\openserver\domains\ci3\application\models\gallery_model.php 27
ERROR - 2016-09-04 19:16:39 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 19:16:39 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 19:16:39 --> upload_no_file_selected
ERROR - 2016-09-04 19:16:39 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 19:16:39 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 19:16:39 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 19:16:39 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 19:16:51 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 19:16:51 --> Severity: Warning  --> Missing argument 1 for Gallery_model::do_upload(), called in D:\openserver\domains\ci3\application\modules\product_properties\controllers\product_properties.php on line 138 and defined D:\openserver\domains\ci3\application\models\gallery_model.php 16
ERROR - 2016-09-04 19:16:51 --> Severity: Notice  --> Undefined variable: filename D:\openserver\domains\ci3\application\models\gallery_model.php 27
ERROR - 2016-09-04 19:16:51 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 19:16:51 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 19:16:51 --> upload_no_file_selected
ERROR - 2016-09-04 19:16:51 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 19:16:51 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 19:16:51 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 19:16:51 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 19:27:08 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 19:27:14 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 19:28:18 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 19:28:54 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 19:34:49 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 19:35:59 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 19:35:59 --> Could not find the language line "required"
ERROR - 2016-09-04 19:36:08 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 19:36:08 --> Could not find the language line "required"
ERROR - 2016-09-04 19:54:16 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:04:15 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:04:15 --> Severity: Notice  --> Undefined index: userfiles D:\openserver\domains\ci3\application\models\gallery_model.php 26
ERROR - 2016-09-04 20:04:15 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-04 20:04:15 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-04 20:05:41 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:05:41 --> Severity: Notice  --> Undefined index: file_name D:\openserver\domains\ci3\application\models\gallery_model.php 27
ERROR - 2016-09-04 20:05:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-04 20:05:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-04 20:07:32 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:09:35 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:10:07 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:11:09 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:16:01 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:20:38 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:20:38 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 20:20:38 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 20:20:38 --> upload_no_file_selected
ERROR - 2016-09-04 20:20:38 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 20:20:38 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 20:20:38 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 20:20:38 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 20:21:24 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:24:17 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:24:44 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:24:44 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:24:44 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:24:44 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:24:44 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:24:44 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:24:44 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:24:44 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:25:42 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:25:42 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:25:42 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:25:42 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:25:42 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:25:42 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:25:42 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:25:42 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:26:17 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:26:17 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:26:17 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:26:17 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:26:17 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:26:17 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:26:17 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:26:17 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:26:32 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:26:32 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 20:26:32 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 20:26:32 --> upload_no_file_selected
ERROR - 2016-09-04 20:26:32 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 20:26:32 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 20:26:32 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 20:26:32 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 20:26:34 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:26:34 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:26:34 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:26:34 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:26:34 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:26:34 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:26:34 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:26:34 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:26:54 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:26:54 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:26:54 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:26:54 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:26:54 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:26:54 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:26:54 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:26:54 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:26:59 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:26:59 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 20:26:59 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 20:26:59 --> upload_no_file_selected
ERROR - 2016-09-04 20:26:59 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 20:26:59 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 20:26:59 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 20:26:59 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 20:29:16 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:29:16 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 20:29:16 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 20:29:16 --> upload_no_file_selected
ERROR - 2016-09-04 20:29:16 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 20:29:16 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 20:29:16 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 20:29:16 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 20:29:21 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:29:21 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:29:21 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:29:21 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:29:21 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:29:21 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:29:21 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:29:21 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:29:53 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:29:53 --> Severity: Notice  --> Undefined property: CI_Input::$post D:\openserver\domains\ci3\application\modules\products\models\productss.php 311
ERROR - 2016-09-04 20:29:59 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:29:59 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:29:59 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:29:59 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:29:59 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:29:59 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:29:59 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:29:59 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:30:00 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:30:00 --> Severity: Notice  --> Undefined property: CI_Input::$post D:\openserver\domains\ci3\application\modules\products\models\productss.php 311
ERROR - 2016-09-04 20:30:09 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:30:32 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:30:38 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:30:43 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:30:47 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:30:47 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:30:47 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:30:47 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:30:47 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:30:47 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:30:47 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:30:47 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:30:52 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:31:05 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:31:05 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:31:05 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:31:05 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:31:05 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:31:05 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:31:05 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:31:05 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:31:09 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:31:26 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:31:26 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:31:26 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:31:26 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:31:26 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:31:26 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:31:26 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:31:26 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:31:29 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:31:29 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 20:31:29 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 20:31:29 --> upload_no_file_selected
ERROR - 2016-09-04 20:31:29 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 20:31:29 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 20:31:29 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 20:31:29 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 20:31:39 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:31:39 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:31:39 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:31:39 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:31:39 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:31:39 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:31:39 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:31:39 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:31:47 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:31:47 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 20:31:47 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 20:31:47 --> upload_no_file_selected
ERROR - 2016-09-04 20:31:47 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 20:31:47 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 20:31:47 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 20:31:47 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 20:31:56 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:31:56 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 20:31:56 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 20:31:56 --> upload_no_file_selected
ERROR - 2016-09-04 20:31:56 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 20:31:56 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 20:31:56 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 20:31:56 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 20:32:22 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:32:22 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:32:22 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:32:22 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:32:22 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:32:22 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:32:22 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:32:22 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:32:27 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:32:27 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 20:32:27 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 20:32:27 --> upload_no_file_selected
ERROR - 2016-09-04 20:32:27 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 20:32:27 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 20:32:27 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 20:32:27 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 20:32:32 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:32:32 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:32:32 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:32:32 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:32:32 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:32:32 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:32:32 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:32:32 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:32:34 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:32:34 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 20:32:34 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 20:32:34 --> upload_no_file_selected
ERROR - 2016-09-04 20:32:34 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 20:32:34 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 20:32:34 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 20:32:34 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 20:32:52 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:32:52 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 20:32:52 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 20:32:52 --> upload_no_file_selected
ERROR - 2016-09-04 20:32:52 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 20:32:52 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 20:32:52 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 20:32:52 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 20:33:01 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:33:01 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 20:33:01 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 20:33:01 --> upload_no_file_selected
ERROR - 2016-09-04 20:33:01 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 20:33:01 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 20:33:01 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 20:33:01 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 20:33:04 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:33:04 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:33:04 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:33:04 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:33:04 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:33:04 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:33:04 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:33:04 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:33:05 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:33:05 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:33:05 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:33:05 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:33:05 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:33:05 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:33:05 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 149
ERROR - 2016-09-04 20:33:05 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given D:\openserver\domains\ci3\application\modules\products\views\form.php 150
ERROR - 2016-09-04 20:33:07 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:33:07 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 20:33:07 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 20:33:07 --> upload_no_file_selected
ERROR - 2016-09-04 20:33:07 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 20:33:07 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 20:33:07 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 20:33:07 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 20:33:22 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:33:40 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:33:46 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:33:46 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 20:33:46 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 20:33:46 --> upload_no_file_selected
ERROR - 2016-09-04 20:33:46 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 20:33:46 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 20:33:46 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 20:33:46 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 20:33:54 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:33:54 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 20:33:54 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 20:33:54 --> upload_no_file_selected
ERROR - 2016-09-04 20:33:54 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 20:33:54 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 20:33:54 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 20:33:54 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 20:34:11 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:34:11 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 20:34:11 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 20:34:11 --> upload_no_file_selected
ERROR - 2016-09-04 20:34:11 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 20:34:11 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 20:34:11 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 20:34:11 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 20:34:24 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:34:24 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 20:34:24 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 20:34:24 --> upload_no_file_selected
ERROR - 2016-09-04 20:34:24 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 20:34:24 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 20:34:24 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 20:34:24 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 20:34:29 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:34:29 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 20:34:29 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 20:34:29 --> upload_no_file_selected
ERROR - 2016-09-04 20:34:29 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 20:34:29 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 20:34:29 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 20:34:29 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 20:34:39 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:34:49 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:34:49 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 20:34:49 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 20:34:49 --> upload_no_file_selected
ERROR - 2016-09-04 20:34:49 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 20:34:49 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 20:34:49 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 20:34:49 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 20:36:14 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:36:23 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:36:23 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 20:36:23 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 20:36:23 --> upload_no_file_selected
ERROR - 2016-09-04 20:36:23 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 20:36:23 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 20:36:23 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 20:36:23 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 20:36:45 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:37:29 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:38:10 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:39:08 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:39:08 --> Severity: Notice  --> Undefined offset: 0 D:\openserver\domains\ci3\application\modules\products\models\productss.php 312
ERROR - 2016-09-04 20:39:09 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-04 20:39:09 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-04 20:39:28 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:39:28 --> Severity: Notice  --> Undefined offset: 0 D:\openserver\domains\ci3\application\modules\products\models\productss.php 312
ERROR - 2016-09-04 20:39:28 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-04 20:39:28 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-04 20:39:28 --> upload_no_file_selected
ERROR - 2016-09-04 20:39:28 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-04 20:39:28 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-04 20:39:28 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-04 20:39:28 --> imglib_unsupported_imagecreate
ERROR - 2016-09-04 20:39:28 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-04 20:39:28 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-04 20:40:18 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:40:18 --> Severity: Notice  --> Undefined offset: 0 D:\openserver\domains\ci3\application\modules\products\models\productss.php 311
ERROR - 2016-09-04 20:40:31 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:40:31 --> Severity: Notice  --> Undefined index: error D:\openserver\domains\ci3\application\modules\products\models\productss.php 311
ERROR - 2016-09-04 20:40:50 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:41:36 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:41:36 --> Severity: Notice  --> Undefined variable: file_name D:\openserver\domains\ci3\application\modules\products\models\productss.php 350
ERROR - 2016-09-04 20:41:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-04 20:41:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-04 20:41:46 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:41:55 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:41:55 --> Severity: Notice  --> Undefined variable: file_name D:\openserver\domains\ci3\application\modules\products\models\productss.php 350
ERROR - 2016-09-04 20:41:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-04 20:41:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-04 20:43:45 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:45:00 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:45:08 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:45:18 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:45:43 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:45:54 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:49:36 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:49:47 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:49:47 --> Severity: Notice  --> Undefined variable: data D:\openserver\domains\ci3\application\modules\products\models\productss.php 335
ERROR - 2016-09-04 20:49:47 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-04 20:49:47 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-04 20:49:47 --> Could not find the language line "db_must_use_set"
ERROR - 2016-09-04 20:49:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\core\Common.php 441
ERROR - 2016-09-04 20:50:36 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:50:36 --> Severity: Notice  --> Undefined variable: file_name D:\openserver\domains\ci3\application\modules\products\models\productss.php 375
ERROR - 2016-09-04 20:50:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-04 20:50:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-04 20:51:22 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:51:29 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:51:35 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:51:44 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:51:51 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 20:52:00 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-04 21:01:54 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
