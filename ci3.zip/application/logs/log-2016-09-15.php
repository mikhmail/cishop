<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-09-15 18:55:34 --> 404 Page Not Found --> cart_items
ERROR - 2016-09-15 18:55:43 --> Could not find the language line "cart_image"
ERROR - 2016-09-15 18:55:47 --> Could not find the language line "cart_image"
ERROR - 2016-09-15 18:55:48 --> 404 Page Not Found --> blogs/blog
ERROR - 2016-09-15 18:56:11 --> 404 Page Not Found --> blogs/blog
ERROR - 2016-09-15 18:56:20 --> Could not find the language line "cart_image"
