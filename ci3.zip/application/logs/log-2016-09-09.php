<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-09-09 15:20:29 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-09 15:20:43 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-09 15:21:07 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-09 15:21:22 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-09 15:23:16 --> Could not find the language line "cart_image"
ERROR - 2016-09-09 15:23:17 --> Could not find the language line "cart_image"
