<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-09-05 11:28:12 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 11:33:27 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 11:33:27 --> Severity: Warning  --> Illegal string offset 'name' D:\openserver\domains\ci3\application\modules\products\models\productss.php 316
ERROR - 2016-09-05 11:33:27 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-05 11:33:27 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-05 11:33:27 --> upload_no_file_selected
ERROR - 2016-09-05 11:33:27 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-05 11:33:27 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-05 11:33:27 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-05 11:33:27 --> imglib_unsupported_imagecreate
ERROR - 2016-09-05 11:37:16 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 11:37:37 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 11:37:37 --> Severity: Warning  --> Illegal string offset 'name' D:\openserver\domains\ci3\application\modules\products\models\productss.php 316
ERROR - 2016-09-05 11:37:37 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-05 11:37:37 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-05 11:37:37 --> upload_no_file_selected
ERROR - 2016-09-05 11:37:37 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-05 11:37:37 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-05 11:37:37 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-05 11:37:37 --> imglib_unsupported_imagecreate
ERROR - 2016-09-05 11:39:00 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 11:39:00 --> Severity: Warning  --> Illegal string offset 'name' D:\openserver\domains\ci3\application\modules\products\models\productss.php 316
ERROR - 2016-09-05 11:39:00 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-05 11:39:00 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-05 11:39:00 --> upload_no_file_selected
ERROR - 2016-09-05 11:39:00 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-05 11:39:00 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-05 11:39:00 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-05 11:39:00 --> imglib_unsupported_imagecreate
ERROR - 2016-09-05 11:39:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-05 11:39:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-05 11:40:06 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 11:40:06 --> Severity: Warning  --> Illegal string offset 'name' D:\openserver\domains\ci3\application\modules\products\models\productss.php 316
ERROR - 2016-09-05 11:40:06 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-05 11:40:06 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-05 11:40:26 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 11:40:26 --> Severity: Notice  --> Undefined variable: _FILE D:\openserver\domains\ci3\application\modules\products\models\productss.php 313
ERROR - 2016-09-05 11:40:39 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 11:45:31 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 11:45:41 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 11:46:16 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 11:47:00 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 11:47:00 --> Severity: Warning  --> Illegal string offset 'name' D:\openserver\domains\ci3\application\modules\products\models\productss.php 321
ERROR - 2016-09-05 11:47:00 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-05 11:47:00 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-05 11:47:00 --> upload_no_file_selected
ERROR - 2016-09-05 11:47:00 --> Severity: Warning  --> getimagesize(D:/openserver/domains/ci3/images/products): failed to open stream: Permission denied D:\openserver\domains\ci3\system\libraries\Image_lib.php 1338
ERROR - 2016-09-05 11:47:00 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-05 11:47:00 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-05 11:47:00 --> imglib_unsupported_imagecreate
ERROR - 2016-09-05 11:47:34 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 11:47:34 --> Severity: Warning  --> Illegal string offset 'name' D:\openserver\domains\ci3\application\modules\products\models\productss.php 320
ERROR - 2016-09-05 11:48:15 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 11:48:15 --> Severity: Notice  --> Undefined variable: data D:\openserver\domains\ci3\application\modules\products\models\productss.php 327
ERROR - 2016-09-05 11:48:53 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 11:49:19 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 11:49:19 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-05 11:49:19 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-05 11:49:19 --> Could not find the language line "db_must_use_set"
ERROR - 2016-09-05 11:49:25 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 11:49:25 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-05 11:49:25 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-05 11:49:25 --> Could not find the language line "db_must_use_set"
ERROR - 2016-09-05 11:49:33 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 11:49:33 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-05 11:49:33 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-05 11:49:33 --> Could not find the language line "db_must_use_set"
ERROR - 2016-09-05 11:50:17 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 11:50:17 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-05 11:50:17 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-05 11:50:17 --> Could not find the language line "db_must_use_set"
ERROR - 2016-09-05 11:50:29 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 11:50:29 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-05 11:50:29 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-05 11:50:29 --> Could not find the language line "db_must_use_set"
ERROR - 2016-09-05 11:50:57 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 11:51:45 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 11:51:52 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 11:52:02 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 11:52:10 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 11:57:53 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 11:58:08 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 12:06:20 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 12:06:38 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 12:06:49 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 12:07:09 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 12:07:09 --> Severity: Notice  --> Array to string conversion D:\openserver\domains\ci3\application\modules\products\models\productss.php 322
ERROR - 2016-09-05 12:07:09 --> Severity: Notice  --> Array to string conversion D:\openserver\domains\ci3\application\modules\products\models\productss.php 323
ERROR - 2016-09-05 12:07:37 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 12:08:11 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 12:08:29 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 12:09:10 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 12:09:19 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 12:10:10 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 12:10:18 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 12:10:49 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 12:11:44 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 12:11:52 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 12:21:42 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 12:23:57 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 12:23:57 --> Severity: Warning  --> unlink(D:\openserver\domains\ci3\images\products/): Permission denied D:\openserver\domains\ci3\application\modules\products\models\productss.php 326
ERROR - 2016-09-05 12:23:57 --> Severity: Warning  --> unlink(D:\openserver\domains\ci3\images\products/thumbs/): Permission denied D:\openserver\domains\ci3\application\modules\products\models\productss.php 330
ERROR - 2016-09-05 12:23:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-05 12:23:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-05 12:26:29 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 12:28:14 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 12:28:40 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 12:32:35 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 12:34:31 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 12:37:32 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 12:42:59 --> Severity: Warning  --> Missing argument 1 for products::delete_img() D:\openserver\domains\ci3\application\modules\products\controllers\products.php 346
ERROR - 2016-09-05 12:42:59 --> Severity: Warning  --> Missing argument 2 for products::delete_img() D:\openserver\domains\ci3\application\modules\products\controllers\products.php 346
ERROR - 2016-09-05 12:42:59 --> Severity: Notice  --> Undefined variable: id D:\openserver\domains\ci3\application\modules\products\controllers\products.php 349
ERROR - 2016-09-05 12:42:59 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-05 12:42:59 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-05 12:43:35 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 12:52:15 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 12:52:38 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 12:56:25 --> Severity: Warning  --> Missing argument 1 for products::delete_img() D:\openserver\domains\ci3\application\modules\products\controllers\products.php 346
ERROR - 2016-09-05 12:56:25 --> Severity: Warning  --> Missing argument 2 for products::delete_img() D:\openserver\domains\ci3\application\modules\products\controllers\products.php 346
ERROR - 2016-09-05 12:56:25 --> Severity: Notice  --> Undefined variable: id D:\openserver\domains\ci3\application\modules\products\controllers\products.php 349
ERROR - 2016-09-05 12:56:25 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-05 12:56:25 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-05 12:57:56 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:03:52 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:07:16 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:08:46 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:09:30 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:09:50 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:09:57 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:10:06 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:10:33 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:10:37 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:11:04 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:11:06 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:11:06 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:11:07 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:11:08 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:11:43 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:13:15 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:14:52 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:15:39 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:15:49 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:16:08 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:17:27 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:17:53 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:19:30 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:19:44 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:20:01 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:20:12 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:23:19 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:26:28 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:26:58 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:28:24 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:28:36 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:30:40 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:30:44 --> Severity: Warning  --> Missing argument 1 for products::delete_img() D:\openserver\domains\ci3\application\modules\products\controllers\products.php 346
ERROR - 2016-09-05 13:30:44 --> Severity: Warning  --> Missing argument 2 for products::delete_img() D:\openserver\domains\ci3\application\modules\products\controllers\products.php 346
ERROR - 2016-09-05 13:30:44 --> Severity: Notice  --> Undefined variable: id D:\openserver\domains\ci3\application\modules\products\controllers\products.php 349
ERROR - 2016-09-05 13:30:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-05 13:30:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-05 13:32:33 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:32:38 --> Severity: Warning  --> Missing argument 1 for products::delete_img() D:\openserver\domains\ci3\application\modules\products\controllers\products.php 346
ERROR - 2016-09-05 13:32:38 --> Severity: Warning  --> Missing argument 2 for products::delete_img() D:\openserver\domains\ci3\application\modules\products\controllers\products.php 346
ERROR - 2016-09-05 13:32:38 --> Severity: Notice  --> Undefined variable: id D:\openserver\domains\ci3\application\modules\products\controllers\products.php 349
ERROR - 2016-09-05 13:32:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-05 13:32:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-05 13:33:38 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:33:39 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:33:56 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:33:58 --> Severity: Warning  --> Missing argument 1 for products::delete_img() D:\openserver\domains\ci3\application\modules\products\controllers\products.php 346
ERROR - 2016-09-05 13:33:58 --> Severity: Warning  --> Missing argument 2 for products::delete_img() D:\openserver\domains\ci3\application\modules\products\controllers\products.php 346
ERROR - 2016-09-05 13:33:58 --> Severity: Notice  --> Undefined variable: id D:\openserver\domains\ci3\application\modules\products\controllers\products.php 349
ERROR - 2016-09-05 13:33:58 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-05 13:33:58 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-05 13:34:34 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:34:37 --> Severity: Warning  --> Missing argument 1 for products::delete_img() D:\openserver\domains\ci3\application\modules\products\controllers\products.php 346
ERROR - 2016-09-05 13:34:37 --> Severity: Warning  --> Missing argument 2 for products::delete_img() D:\openserver\domains\ci3\application\modules\products\controllers\products.php 346
ERROR - 2016-09-05 13:34:37 --> Severity: Notice  --> Undefined variable: id D:\openserver\domains\ci3\application\modules\products\controllers\products.php 349
ERROR - 2016-09-05 13:34:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-05 13:34:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-05 13:34:55 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:34:59 --> Severity: Warning  --> Missing argument 1 for products::delete_img() D:\openserver\domains\ci3\application\modules\products\controllers\products.php 346
ERROR - 2016-09-05 13:34:59 --> Severity: Warning  --> Missing argument 2 for products::delete_img() D:\openserver\domains\ci3\application\modules\products\controllers\products.php 346
ERROR - 2016-09-05 13:34:59 --> Severity: Notice  --> Undefined variable: id D:\openserver\domains\ci3\application\modules\products\controllers\products.php 349
ERROR - 2016-09-05 13:34:59 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-05 13:34:59 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-05 13:35:49 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:36:15 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:36:21 --> Severity: Notice  --> Undefined variable: _post D:\openserver\domains\ci3\application\modules\products\controllers\products.php 348
ERROR - 2016-09-05 13:36:57 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:37:00 --> Severity: Notice  --> Undefined variable: id D:\openserver\domains\ci3\application\modules\products\controllers\products.php 350
ERROR - 2016-09-05 13:37:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\products\controllers\products.php:348) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-05 13:37:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\products\controllers\products.php:348) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-05 13:37:30 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:42:40 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:44:12 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:44:36 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:44:38 --> Query error: Unknown column '2' in 'field list'
ERROR - 2016-09-05 13:44:38 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-05 13:44:38 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-05 13:46:00 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:46:13 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:52:34 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 13:53:07 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 13:55:06 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:55:38 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:55:55 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 13:59:23 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 14:00:32 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 14:00:34 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 14:04:46 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 14:05:29 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 14:05:36 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 14:05:44 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 14:05:55 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 14:06:02 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 14:06:23 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 14:06:46 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 14:07:24 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 14:07:33 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 14:09:51 --> Severity: Notice  --> Undefined variable: style D:\openserver\domains\ci3\application\modules\products\views\form.php 236
ERROR - 2016-09-05 14:13:00 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 14:15:08 --> Severity: Notice  --> Undefined variable: style D:\openserver\domains\ci3\application\modules\products\views\form.php 300
ERROR - 2016-09-05 14:15:08 --> Severity: Notice  --> Undefined variable: style D:\openserver\domains\ci3\application\modules\products\views\form.php 344
ERROR - 2016-09-05 14:15:08 --> Severity: Notice  --> Undefined variable: style D:\openserver\domains\ci3\application\modules\products\views\form.php 387
ERROR - 2016-09-05 14:15:08 --> Severity: Notice  --> Undefined variable: style D:\openserver\domains\ci3\application\modules\products\views\form.php 430
ERROR - 2016-09-05 14:15:08 --> Severity: Notice  --> Undefined variable: style D:\openserver\domains\ci3\application\modules\products\views\form.php 475
ERROR - 2016-09-05 14:15:08 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 14:15:43 --> Severity: Notice  --> Undefined variable: style D:\openserver\domains\ci3\application\modules\products\views\form.php 344
ERROR - 2016-09-05 14:15:43 --> Severity: Notice  --> Undefined variable: style D:\openserver\domains\ci3\application\modules\products\views\form.php 387
ERROR - 2016-09-05 14:15:43 --> Severity: Notice  --> Undefined variable: style D:\openserver\domains\ci3\application\modules\products\views\form.php 430
ERROR - 2016-09-05 14:15:43 --> Severity: Notice  --> Undefined variable: style D:\openserver\domains\ci3\application\modules\products\views\form.php 475
ERROR - 2016-09-05 14:15:43 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 14:16:07 --> Severity: Notice  --> Undefined variable: style D:\openserver\domains\ci3\application\modules\products\views\form.php 344
ERROR - 2016-09-05 14:16:07 --> Severity: Notice  --> Undefined variable: style D:\openserver\domains\ci3\application\modules\products\views\form.php 387
ERROR - 2016-09-05 14:16:07 --> Severity: Notice  --> Undefined variable: style D:\openserver\domains\ci3\application\modules\products\views\form.php 430
ERROR - 2016-09-05 14:16:07 --> Severity: Notice  --> Undefined variable: style D:\openserver\domains\ci3\application\modules\products\views\form.php 475
ERROR - 2016-09-05 14:16:07 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 14:16:14 --> Severity: Notice  --> Undefined variable: style D:\openserver\domains\ci3\application\modules\products\views\form.php 344
ERROR - 2016-09-05 14:16:14 --> Severity: Notice  --> Undefined variable: style D:\openserver\domains\ci3\application\modules\products\views\form.php 387
ERROR - 2016-09-05 14:16:14 --> Severity: Notice  --> Undefined variable: style D:\openserver\domains\ci3\application\modules\products\views\form.php 430
ERROR - 2016-09-05 14:16:14 --> Severity: Notice  --> Undefined variable: style D:\openserver\domains\ci3\application\modules\products\views\form.php 475
ERROR - 2016-09-05 14:16:14 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 14:20:08 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 14:20:25 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 14:20:53 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 14:21:26 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 14:21:58 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 14:26:50 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 14:27:17 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 14:27:39 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 14:31:50 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 14:32:15 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 14:35:07 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 14:35:18 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 14:35:18 --> Severity: Notice  --> Array to string conversion D:\openserver\domains\ci3\application\models\gallery_model.php 17
ERROR - 2016-09-05 14:35:32 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 14:35:52 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 14:36:04 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 14:37:12 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 14:39:02 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 14:41:04 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 14:42:33 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 14:43:19 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 14:43:31 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 14:45:16 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 14:47:50 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 14:48:12 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 14:50:10 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-05 14:50:26 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 14:50:59 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 14:55:00 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 14:56:02 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 14:56:41 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 14:57:00 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 14:58:37 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 14:59:53 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 15:00:00 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 15:01:48 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 15:02:40 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 15:03:41 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 15:04:50 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 15:07:26 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 15:07:35 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 15:07:44 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 15:10:34 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 15:22:13 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 15:23:17 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 15:26:38 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 15:26:38 --> Severity: Notice  --> Undefined variable: id D:\openserver\domains\ci3\application\modules\products\models\productss.php 254
ERROR - 2016-09-05 15:26:38 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\products\models\productss.php 254
ERROR - 2016-09-05 15:26:38 --> Severity: Notice  --> Undefined variable: id D:\openserver\domains\ci3\application\modules\products\models\productss.php 255
ERROR - 2016-09-05 15:26:38 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\products\models\productss.php 255
ERROR - 2016-09-05 15:26:38 --> Severity: Notice  --> Undefined variable: id D:\openserver\domains\ci3\application\modules\products\models\productss.php 254
ERROR - 2016-09-05 15:26:38 --> Severity: Notice  --> Undefined index: product_image_1 D:\openserver\domains\ci3\application\modules\products\models\productss.php 254
ERROR - 2016-09-05 15:26:38 --> Severity: Notice  --> Undefined variable: id D:\openserver\domains\ci3\application\modules\products\models\productss.php 255
ERROR - 2016-09-05 15:26:38 --> Severity: Notice  --> Undefined index: product_image_1 D:\openserver\domains\ci3\application\modules\products\models\productss.php 255
ERROR - 2016-09-05 15:26:38 --> Severity: Notice  --> Undefined variable: id D:\openserver\domains\ci3\application\modules\products\models\productss.php 273
ERROR - 2016-09-05 15:26:38 --> Severity: Notice  --> Undefined variable: id D:\openserver\domains\ci3\application\modules\products\models\productss.php 318
ERROR - 2016-09-05 15:26:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-05 15:26:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-05 15:30:32 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 15:33:45 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 15:38:15 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 15:38:29 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 16:29:14 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 16:29:14 --> Severity: Warning  --> Illegal offset type D:\openserver\domains\ci3\application\models\gallery_model.php 23
ERROR - 2016-09-05 16:29:14 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-05 16:29:14 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-05 16:29:14 --> upload_no_file_selected
ERROR - 2016-09-05 16:29:14 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-05 16:29:14 --> Could not find the language line "imglib_invalid_path"
ERROR - 2016-09-05 16:29:14 --> imglib_invalid_path
ERROR - 2016-09-05 16:29:14 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-05 16:29:14 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-05 16:29:14 --> imglib_unsupported_imagecreate
ERROR - 2016-09-05 16:29:14 --> Severity: Warning  --> Illegal offset type D:\openserver\domains\ci3\application\models\gallery_model.php 23
ERROR - 2016-09-05 16:29:14 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-05 16:29:14 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-05 16:29:14 --> upload_no_file_selected
ERROR - 2016-09-05 16:29:14 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-05 16:29:14 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-05 16:29:14 --> imglib_unsupported_imagecreate
ERROR - 2016-09-05 16:29:14 --> Severity: Warning  --> Illegal offset type D:\openserver\domains\ci3\application\models\gallery_model.php 23
ERROR - 2016-09-05 16:29:14 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-05 16:29:14 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-05 16:29:14 --> upload_no_file_selected
ERROR - 2016-09-05 16:29:14 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-05 16:29:14 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-05 16:29:14 --> imglib_unsupported_imagecreate
ERROR - 2016-09-05 16:29:14 --> Severity: Warning  --> Illegal offset type D:\openserver\domains\ci3\application\models\gallery_model.php 23
ERROR - 2016-09-05 16:29:14 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-05 16:29:14 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-05 16:29:14 --> upload_no_file_selected
ERROR - 2016-09-05 16:29:14 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-05 16:29:14 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-05 16:29:14 --> imglib_unsupported_imagecreate
ERROR - 2016-09-05 16:29:14 --> Severity: Warning  --> Illegal offset type D:\openserver\domains\ci3\application\models\gallery_model.php 23
ERROR - 2016-09-05 16:29:14 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-05 16:29:14 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-05 16:29:14 --> upload_no_file_selected
ERROR - 2016-09-05 16:29:14 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-05 16:29:14 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-05 16:29:14 --> imglib_unsupported_imagecreate
ERROR - 2016-09-05 16:29:14 --> Severity: Warning  --> Illegal offset type D:\openserver\domains\ci3\application\models\gallery_model.php 23
ERROR - 2016-09-05 16:29:14 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-05 16:29:14 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-05 16:29:14 --> upload_no_file_selected
ERROR - 2016-09-05 16:29:14 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-05 16:29:14 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-05 16:29:14 --> imglib_unsupported_imagecreate
ERROR - 2016-09-05 16:29:47 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 16:32:48 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 16:32:48 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-05 16:32:49 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-05 16:32:49 --> upload_no_file_selected
ERROR - 2016-09-05 16:32:49 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-05 16:32:49 --> Could not find the language line "imglib_invalid_path"
ERROR - 2016-09-05 16:32:49 --> imglib_invalid_path
ERROR - 2016-09-05 16:32:49 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-05 16:32:49 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-05 16:32:49 --> imglib_unsupported_imagecreate
ERROR - 2016-09-05 16:32:49 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-05 16:32:49 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-05 16:32:49 --> upload_no_file_selected
ERROR - 2016-09-05 16:32:49 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-05 16:32:49 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-05 16:32:49 --> imglib_unsupported_imagecreate
ERROR - 2016-09-05 16:33:48 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 16:33:48 --> Severity: Warning  --> Illegal offset type D:\openserver\domains\ci3\application\models\gallery_model.php 27
ERROR - 2016-09-05 16:33:48 --> Severity: Warning  --> Illegal offset type D:\openserver\domains\ci3\application\models\gallery_model.php 27
ERROR - 2016-09-05 16:34:30 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 16:34:30 --> Severity: Warning  --> Illegal offset type D:\openserver\domains\ci3\application\models\gallery_model.php 27
ERROR - 2016-09-05 16:34:30 --> Severity: Warning  --> Illegal offset type D:\openserver\domains\ci3\application\models\gallery_model.php 27
ERROR - 2016-09-05 16:36:34 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 16:36:48 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 16:36:48 --> Severity: Warning  --> Illegal offset type D:\openserver\domains\ci3\application\models\gallery_model.php 28
ERROR - 2016-09-05 16:36:49 --> Severity: Warning  --> Illegal offset type D:\openserver\domains\ci3\application\models\gallery_model.php 28
ERROR - 2016-09-05 16:40:04 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 16:40:04 --> Severity: Warning  --> Illegal offset type D:\openserver\domains\ci3\application\models\gallery_model.php 26
ERROR - 2016-09-05 16:40:04 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-05 16:40:04 --> Could not find the language line "imglib_invalid_path"
ERROR - 2016-09-05 16:40:04 --> imglib_invalid_path
ERROR - 2016-09-05 16:40:04 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-05 16:40:04 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-05 16:40:04 --> imglib_unsupported_imagecreate
ERROR - 2016-09-05 16:40:04 --> Severity: Warning  --> Illegal offset type D:\openserver\domains\ci3\application\models\gallery_model.php 26
ERROR - 2016-09-05 16:40:04 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-05 16:40:04 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-05 16:40:04 --> imglib_unsupported_imagecreate
ERROR - 2016-09-05 18:12:02 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 18:12:02 --> Severity: Warning  --> Illegal offset type D:\openserver\domains\ci3\application\models\gallery_model.php 26
ERROR - 2016-09-05 18:12:02 --> Severity: Warning  --> Illegal offset type D:\openserver\domains\ci3\application\models\gallery_model.php 26
ERROR - 2016-09-05 18:12:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-05 18:12:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-05 18:25:51 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 18:27:38 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 18:27:38 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-05 18:27:38 --> Could not find the language line "imglib_invalid_path"
ERROR - 2016-09-05 18:27:38 --> imglib_invalid_path
ERROR - 2016-09-05 18:27:38 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-05 18:27:38 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-05 18:27:38 --> imglib_unsupported_imagecreate
ERROR - 2016-09-05 18:28:25 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 18:29:06 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 18:29:20 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 18:29:39 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 18:34:44 --> Severity: Warning  --> include_once(base_controller.php): failed to open stream: No such file or directory D:\openserver\domains\ci3\application\controllers\main.php 3
ERROR - 2016-09-05 18:34:44 --> Severity: Warning  --> include_once(): Failed opening 'base_controller.php' for inclusion (include_path='.;d:/openserver/modules/php/PHP-5.5;d:/openserver/modules/php/PHP-5.5/PEAR/pear') D:\openserver\domains\ci3\application\controllers\main.php 3
ERROR - 2016-09-05 18:35:18 --> Severity: Notice  --> Undefined property: Main::$user_model D:\openserver\domains\ci3\application\controllers\main.php 9
ERROR - 2016-09-05 18:35:48 --> Severity: Notice  --> Undefined property: Main::$user_model D:\openserver\domains\ci3\application\controllers\main.php 9
ERROR - 2016-09-05 18:40:10 --> Severity: Notice  --> Undefined property: Main::$user_model D:\openserver\domains\ci3\application\controllers\main.php 9
ERROR - 2016-09-05 18:40:31 --> Severity: Notice  --> Undefined property: Main::$user_model D:\openserver\domains\ci3\application\controllers\main.php 10
ERROR - 2016-09-05 18:41:16 --> Severity: Notice  --> Undefined property: Main::$user_model D:\openserver\domains\ci3\application\controllers\main.php 10
ERROR - 2016-09-05 18:42:52 --> Severity: Notice  --> Undefined property: CI::$user_model D:\openserver\domains\ci3\application\third_party\MX\Controller.php 58
ERROR - 2016-09-05 18:43:04 --> Severity: Notice  --> Undefined property: Main::$user_model D:\openserver\domains\ci3\application\controllers\main.php 10
ERROR - 2016-09-05 18:46:01 --> Severity: Notice  --> Undefined property: Main::$user_model D:\openserver\domains\ci3\application\modules\main\controllers\main.php 10
ERROR - 2016-09-05 18:46:38 --> Severity: Notice  --> Undefined property: Main::$user_model D:\openserver\domains\ci3\application\modules\main\controllers\main.php 10
ERROR - 2016-09-05 18:51:58 --> Severity: Notice  --> Undefined property: Main::$user_model D:\openserver\domains\ci3\application\modules\main\controllers\main.php 10
ERROR - 2016-09-05 18:53:06 --> Severity: Notice  --> Undefined property: Main::$user_model D:\openserver\domains\ci3\application\modules\main\controllers\main.php 10
ERROR - 2016-09-05 18:53:19 --> Severity: Notice  --> Undefined property: Main::$user_model D:\openserver\domains\ci3\application\modules\main\controllers\main.php 10
ERROR - 2016-09-05 18:53:58 --> Severity: Notice  --> Undefined property: Main::$user_model D:\openserver\domains\ci3\application\modules\main\controllers\main.php 10
ERROR - 2016-09-05 19:05:10 --> Severity: Notice  --> Undefined property: Main::$user_model D:\openserver\domains\ci3\application\modules\main\controllers\main.php 10
ERROR - 2016-09-05 19:05:30 --> Severity: Notice  --> Undefined property: Main::$user_model D:\openserver\domains\ci3\application\modules\main\controllers\main.php 10
ERROR - 2016-09-05 19:05:45 --> Severity: Notice  --> Undefined property: Main::$user_model D:\openserver\domains\ci3\application\modules\main\controllers\main.php 10
ERROR - 2016-09-05 19:05:56 --> Severity: Notice  --> Undefined property: Main::$user_model D:\openserver\domains\ci3\application\modules\main\controllers\main.php 10
ERROR - 2016-09-05 19:05:58 --> Severity: Notice  --> Undefined property: Main::$user_model D:\openserver\domains\ci3\application\modules\main\controllers\main.php 10
ERROR - 2016-09-05 19:05:59 --> Severity: Notice  --> Undefined property: Main::$user_model D:\openserver\domains\ci3\application\modules\main\controllers\main.php 10
ERROR - 2016-09-05 19:07:00 --> Severity: Notice  --> Undefined property: Main::$user_model D:\openserver\domains\ci3\application\modules\main\controllers\main.php 11
ERROR - 2016-09-05 19:07:02 --> Severity: Notice  --> Undefined property: Main::$user_model D:\openserver\domains\ci3\application\modules\main\controllers\main.php 11
ERROR - 2016-09-05 19:08:18 --> Severity: Notice  --> Undefined property: Main::$user_model D:\openserver\domains\ci3\application\modules\main\controllers\main.php 10
ERROR - 2016-09-05 19:08:35 --> Could not find the language line "site_name"
ERROR - 2016-09-05 19:08:35 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 19:08:35 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 19:08:35 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:08:35 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 19:08:35 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 19:08:35 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 19:08:35 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 19:12:26 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:12:26 --> Severity: Notice  --> Undefined variable: data D:\openserver\domains\ci3\application\modules\main\views\main\index.php 3
ERROR - 2016-09-05 19:19:26 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:19:26 --> Severity: Notice  --> Undefined variable: data D:\openserver\domains\ci3\application\modules\main\views\main\index.php 3
ERROR - 2016-09-05 19:20:32 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:20:32 --> Severity: Notice  --> Undefined variable: data D:\openserver\domains\ci3\application\modules\main\views\main\index.php 3
ERROR - 2016-09-05 19:21:41 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:21:41 --> Severity: Notice  --> Undefined variable: data D:\openserver\domains\ci3\application\modules\main\views\main\index.php 3
ERROR - 2016-09-05 19:21:44 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:21:44 --> Severity: Notice  --> Undefined variable: data D:\openserver\domains\ci3\application\modules\main\views\main\index.php 3
ERROR - 2016-09-05 19:23:23 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:23:23 --> Severity: Notice  --> Undefined variable: data D:\openserver\domains\ci3\application\modules\main\views\main\index.php 3
ERROR - 2016-09-05 19:26:06 --> Severity: Notice  --> Undefined property: Main::$user_model D:\openserver\domains\ci3\application\controllers\main.php 9
ERROR - 2016-09-05 19:26:58 --> Could not find the language line "site_name"
ERROR - 2016-09-05 19:26:58 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 19:26:58 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 19:26:58 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:26:58 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 19:26:58 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 19:26:58 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 19:26:58 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 19:26:58 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:28:09 --> Could not find the language line "site_name"
ERROR - 2016-09-05 19:28:09 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 19:28:09 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 19:28:09 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:28:09 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 19:28:09 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 19:28:09 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 19:28:09 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 19:28:09 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:28:15 --> Could not find the language line "site_name"
ERROR - 2016-09-05 19:28:15 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 19:28:15 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 19:28:15 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:28:15 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 19:28:15 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 19:28:15 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 19:28:15 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 19:28:15 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:28:40 --> Could not find the language line "site_name"
ERROR - 2016-09-05 19:28:40 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 19:28:40 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 19:28:40 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:28:40 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 19:28:40 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 19:28:40 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 19:28:40 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 19:28:40 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:28:44 --> Could not find the language line "site_name"
ERROR - 2016-09-05 19:28:44 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 19:28:44 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 19:28:44 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:28:44 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 19:28:44 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 19:28:44 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 19:28:44 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 19:28:44 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:31:15 --> Could not find the language line "site_name"
ERROR - 2016-09-05 19:31:15 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 19:31:15 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 19:31:15 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:31:15 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 19:31:15 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 19:31:15 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 19:31:15 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 19:31:15 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:33:53 --> Could not find the language line "site_name"
ERROR - 2016-09-05 19:33:53 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 19:33:53 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 19:33:53 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:33:53 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 19:33:53 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 19:33:53 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 19:33:53 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 19:33:53 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:33:53 --> Could not find the language line "currency"
ERROR - 2016-09-05 19:33:53 --> Could not find the language line "cart_count"
ERROR - 2016-09-05 19:34:14 --> 404 Page Not Found --> product/15
ERROR - 2016-09-05 19:34:16 --> Could not find the language line "site_name"
ERROR - 2016-09-05 19:34:16 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 19:34:16 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 19:34:16 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:34:16 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 19:34:16 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 19:34:16 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 19:34:16 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 19:34:16 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:34:16 --> Could not find the language line "currency"
ERROR - 2016-09-05 19:34:16 --> Could not find the language line "cart_count"
ERROR - 2016-09-05 19:35:46 --> Could not find the language line "site_name"
ERROR - 2016-09-05 19:35:46 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 19:35:46 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 19:35:46 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:35:46 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 19:35:46 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 19:35:46 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 19:35:46 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 19:35:46 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:35:46 --> Could not find the language line "currency"
ERROR - 2016-09-05 19:35:46 --> Could not find the language line "cart_count"
ERROR - 2016-09-05 19:35:52 --> 404 Page Not Found --> product/15
ERROR - 2016-09-05 19:35:55 --> Could not find the language line "site_name"
ERROR - 2016-09-05 19:35:55 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 19:35:55 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 19:35:55 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:35:55 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 19:35:55 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 19:35:55 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 19:35:55 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 19:35:55 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:35:55 --> Could not find the language line "currency"
ERROR - 2016-09-05 19:35:55 --> Could not find the language line "cart_count"
ERROR - 2016-09-05 19:35:59 --> 404 Page Not Found --> post/6
ERROR - 2016-09-05 19:36:00 --> Could not find the language line "site_name"
ERROR - 2016-09-05 19:36:00 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 19:36:00 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 19:36:00 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:36:00 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 19:36:00 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 19:36:00 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 19:36:00 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 19:36:00 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:36:00 --> Could not find the language line "currency"
ERROR - 2016-09-05 19:36:00 --> Could not find the language line "cart_count"
ERROR - 2016-09-05 19:36:02 --> 404 Page Not Found --> category/1
ERROR - 2016-09-05 19:36:06 --> Could not find the language line "site_name"
ERROR - 2016-09-05 19:36:06 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 19:36:06 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 19:36:06 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:36:06 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 19:36:06 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 19:36:06 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 19:36:06 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 19:36:06 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:36:06 --> Could not find the language line "currency"
ERROR - 2016-09-05 19:36:06 --> Could not find the language line "cart_count"
ERROR - 2016-09-05 19:36:48 --> Could not find the language line "site_name"
ERROR - 2016-09-05 19:36:48 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 19:36:48 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 19:36:48 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:36:48 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 19:36:48 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 19:36:48 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 19:36:48 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 19:36:48 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:36:48 --> Could not find the language line "currency"
ERROR - 2016-09-05 19:36:48 --> Could not find the language line "cart_count"
ERROR - 2016-09-05 19:36:51 --> Could not find the language line "site_name"
ERROR - 2016-09-05 19:36:51 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 19:36:51 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 19:36:51 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:36:51 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 19:36:51 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 19:36:51 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 19:36:51 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 19:36:51 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:36:51 --> Could not find the language line "currency"
ERROR - 2016-09-05 19:36:51 --> Could not find the language line "cart_count"
ERROR - 2016-09-05 19:36:53 --> 404 Page Not Found --> category/1
ERROR - 2016-09-05 19:36:56 --> Could not find the language line "site_name"
ERROR - 2016-09-05 19:36:56 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 19:36:56 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 19:36:56 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:36:56 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 19:36:56 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 19:36:56 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 19:36:56 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 19:36:56 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:36:56 --> Could not find the language line "currency"
ERROR - 2016-09-05 19:36:56 --> Could not find the language line "cart_count"
ERROR - 2016-09-05 19:36:57 --> Could not find the language line "site_name"
ERROR - 2016-09-05 19:36:57 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 19:36:57 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 19:36:57 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:36:57 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 19:36:57 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 19:36:57 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 19:36:57 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 19:37:04 --> Could not find the language line "site_name"
ERROR - 2016-09-05 19:37:04 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 19:37:04 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 19:37:04 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:37:04 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 19:37:04 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 19:37:04 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 19:37:04 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 19:37:04 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 19:37:04 --> Could not find the language line "currency"
ERROR - 2016-09-05 19:37:04 --> Could not find the language line "cart_count"
ERROR - 2016-09-05 21:19:49 --> Could not find the language line "site_name"
ERROR - 2016-09-05 21:19:49 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 21:19:49 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 21:19:49 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 21:19:49 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 21:19:49 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 21:19:49 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 21:19:49 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 21:25:43 --> Could not find the language line "site_name"
ERROR - 2016-09-05 21:25:43 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 21:25:43 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 21:25:43 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 21:25:43 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 21:25:43 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 21:25:43 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 21:25:43 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 21:27:51 --> Could not find the language line "site_name"
ERROR - 2016-09-05 21:27:51 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 21:27:51 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 21:27:51 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 21:27:51 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 21:27:51 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 21:27:51 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 21:27:51 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 21:28:54 --> Could not find the language line "site_name"
ERROR - 2016-09-05 21:28:54 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 21:28:54 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 21:28:54 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 21:28:54 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 21:28:54 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 21:28:54 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 21:28:54 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 21:29:39 --> Could not find the language line "site_name"
ERROR - 2016-09-05 21:29:39 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 21:29:39 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 21:29:39 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 21:29:39 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 21:29:39 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 21:29:39 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 21:29:39 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 21:30:25 --> Could not find the language line "site_name"
ERROR - 2016-09-05 21:30:25 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 21:30:25 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 21:30:25 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 21:30:25 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 21:30:25 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 21:30:25 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 21:30:25 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 21:30:27 --> Could not find the language line "site_name"
ERROR - 2016-09-05 21:30:27 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 21:30:27 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 21:30:27 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 21:30:27 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 21:30:27 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 21:30:27 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 21:30:27 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 21:30:28 --> Could not find the language line "site_name"
ERROR - 2016-09-05 21:30:28 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 21:30:28 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 21:30:28 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 21:30:28 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 21:30:28 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 21:30:28 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 21:30:28 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 21:30:29 --> Could not find the language line "site_name"
ERROR - 2016-09-05 21:30:29 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 21:30:29 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 21:30:29 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 21:30:29 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 21:30:29 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 21:30:29 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 21:30:29 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 21:36:26 --> Could not find the language line "site_name"
ERROR - 2016-09-05 21:36:26 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 21:36:26 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 21:36:26 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 21:36:26 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 21:36:26 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 21:36:26 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 21:36:26 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 21:36:26 --> Could not find the language line "cart_price"
ERROR - 2016-09-05 21:36:26 --> Could not find the language line "currency"
ERROR - 2016-09-05 21:36:26 --> Could not find the language line "cart_count"
ERROR - 2016-09-05 21:36:26 --> Could not find the language line "button_add_to_cart"
ERROR - 2016-09-05 21:36:26 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 65
ERROR - 2016-09-05 21:36:26 --> Could not find the language line "site_name"
ERROR - 2016-09-05 21:37:23 --> Could not find the language line "site_name"
ERROR - 2016-09-05 21:37:23 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 21:37:23 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 21:37:23 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 21:37:23 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 21:37:23 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 21:37:23 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 21:37:23 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 21:37:23 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 21:37:23 --> Could not find the language line "currency"
ERROR - 2016-09-05 21:37:23 --> Could not find the language line "site_name"
ERROR - 2016-09-05 21:37:24 --> Could not find the language line "site_name"
ERROR - 2016-09-05 21:37:24 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 21:37:24 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 21:37:24 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 21:37:24 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 21:37:24 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 21:37:24 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 21:37:24 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 21:37:24 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 21:37:24 --> Could not find the language line "currency"
ERROR - 2016-09-05 21:37:24 --> Could not find the language line "site_name"
ERROR - 2016-09-05 21:37:25 --> Could not find the language line "site_name"
ERROR - 2016-09-05 21:37:25 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 21:37:25 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 21:37:25 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 21:37:25 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 21:37:25 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 21:37:25 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 21:37:25 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 21:37:25 --> Could not find the language line "cart_price"
ERROR - 2016-09-05 21:37:25 --> Could not find the language line "currency"
ERROR - 2016-09-05 21:37:25 --> Could not find the language line "cart_count"
ERROR - 2016-09-05 21:37:25 --> Could not find the language line "button_add_to_cart"
ERROR - 2016-09-05 21:37:25 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 65
ERROR - 2016-09-05 21:37:25 --> Could not find the language line "site_name"
ERROR - 2016-09-05 21:37:30 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-05 21:38:19 --> Could not find the language line "site_name"
ERROR - 2016-09-05 21:38:19 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 21:38:19 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 21:38:19 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 21:38:19 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 21:38:19 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 21:38:19 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 21:38:19 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 21:38:19 --> Could not find the language line "cart_price"
ERROR - 2016-09-05 21:38:19 --> Could not find the language line "currency"
ERROR - 2016-09-05 21:38:19 --> Could not find the language line "cart_count"
ERROR - 2016-09-05 21:38:19 --> Could not find the language line "button_add_to_cart"
ERROR - 2016-09-05 21:38:19 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 65
ERROR - 2016-09-05 21:38:19 --> Could not find the language line "site_name"
ERROR - 2016-09-05 21:38:20 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-05 21:38:24 --> Could not find the language line "site_name"
ERROR - 2016-09-05 21:38:24 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 21:38:24 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 21:38:25 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 21:38:25 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 21:38:25 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 21:38:25 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 21:38:25 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 21:38:25 --> Could not find the language line "cart_price"
ERROR - 2016-09-05 21:38:25 --> Could not find the language line "currency"
ERROR - 2016-09-05 21:38:25 --> Could not find the language line "cart_count"
ERROR - 2016-09-05 21:38:25 --> Could not find the language line "button_add_to_cart"
ERROR - 2016-09-05 21:38:25 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 65
ERROR - 2016-09-05 21:38:25 --> Could not find the language line "site_name"
ERROR - 2016-09-05 21:38:25 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-05 21:38:54 --> Could not find the language line "site_name"
ERROR - 2016-09-05 21:38:54 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 21:38:54 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 21:38:54 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 21:38:54 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 21:38:54 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 21:38:54 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 21:38:54 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 21:38:54 --> Could not find the language line "cart_price"
ERROR - 2016-09-05 21:38:54 --> Could not find the language line "currency"
ERROR - 2016-09-05 21:38:54 --> Could not find the language line "cart_count"
ERROR - 2016-09-05 21:38:54 --> Could not find the language line "button_add_to_cart"
ERROR - 2016-09-05 21:38:54 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 65
ERROR - 2016-09-05 21:38:54 --> Could not find the language line "site_name"
ERROR - 2016-09-05 21:38:54 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-05 21:39:22 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 21:39:39 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 21:40:10 --> Could not find the language line "site_name"
ERROR - 2016-09-05 21:40:10 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 21:40:10 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 21:40:10 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 21:40:10 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 21:40:10 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 21:40:10 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 21:40:10 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 21:40:10 --> Could not find the language line "cart_price"
ERROR - 2016-09-05 21:40:10 --> Could not find the language line "currency"
ERROR - 2016-09-05 21:40:10 --> Could not find the language line "cart_count"
ERROR - 2016-09-05 21:40:10 --> Could not find the language line "button_add_to_cart"
ERROR - 2016-09-05 21:40:10 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 65
ERROR - 2016-09-05 21:40:10 --> Could not find the language line "site_name"
ERROR - 2016-09-05 21:40:11 --> Could not find the language line "site_name"
ERROR - 2016-09-05 21:40:11 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 21:40:11 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 21:40:11 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 21:40:11 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 21:40:11 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 21:40:11 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 21:40:11 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 21:40:11 --> Could not find the language line "cart_price"
ERROR - 2016-09-05 21:40:11 --> Could not find the language line "currency"
ERROR - 2016-09-05 21:40:11 --> Could not find the language line "cart_count"
ERROR - 2016-09-05 21:40:11 --> Could not find the language line "button_add_to_cart"
ERROR - 2016-09-05 21:40:11 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 65
ERROR - 2016-09-05 21:40:11 --> Could not find the language line "site_name"
ERROR - 2016-09-05 21:40:12 --> Could not find the language line "site_name"
ERROR - 2016-09-05 21:40:12 --> Could not find the language line "cart_item"
ERROR - 2016-09-05 21:40:12 --> Could not find the language line "cart_total"
ERROR - 2016-09-05 21:40:12 --> Could not find the language line "header_menu_home"
ERROR - 2016-09-05 21:40:12 --> Could not find the language line "header_menu_blog"
ERROR - 2016-09-05 21:40:12 --> Could not find the language line "header_menu_news"
ERROR - 2016-09-05 21:40:12 --> Could not find the language line "header_menu_contact"
ERROR - 2016-09-05 21:40:12 --> Could not find the language line "sidebar_title"
ERROR - 2016-09-05 21:40:12 --> Could not find the language line "cart_price"
ERROR - 2016-09-05 21:40:12 --> Could not find the language line "currency"
ERROR - 2016-09-05 21:40:12 --> Could not find the language line "cart_count"
ERROR - 2016-09-05 21:40:12 --> Could not find the language line "button_add_to_cart"
ERROR - 2016-09-05 21:40:12 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 65
ERROR - 2016-09-05 21:40:12 --> Could not find the language line "site_name"
ERROR - 2016-09-05 21:44:10 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 65
ERROR - 2016-09-05 21:44:23 --> 404 Page Not Found --> category/1
ERROR - 2016-09-05 21:44:26 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 65
ERROR - 2016-09-05 21:45:15 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 21:45:26 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 21:45:36 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-05 21:45:46 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 65
ERROR - 2016-09-05 21:46:05 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 65
ERROR - 2016-09-05 21:46:15 --> 404 Page Not Found --> category/1
ERROR - 2016-09-05 21:46:46 --> Query error: Table 'myshop.categories_products' doesn't exist
ERROR - 2016-09-05 21:46:46 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-05 21:46:46 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-05 21:47:03 --> 404 Page Not Found --> category/1
ERROR - 2016-09-05 21:47:48 --> 404 Page Not Found --> category/1
ERROR - 2016-09-05 21:49:46 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-05 21:50:40 --> 404 Page Not Found --> category/1
ERROR - 2016-09-05 21:50:48 --> 404 Page Not Found --> category/1
ERROR - 2016-09-05 21:50:52 --> 404 Page Not Found --> category/1
ERROR - 2016-09-05 21:51:53 --> 404 Page Not Found --> category/1
ERROR - 2016-09-05 21:51:55 --> 404 Page Not Found --> category/1
ERROR - 2016-09-05 21:51:56 --> 404 Page Not Found --> category/1
ERROR - 2016-09-05 21:51:57 --> 404 Page Not Found --> category/1
ERROR - 2016-09-05 21:52:01 --> 404 Page Not Found --> category/1
ERROR - 2016-09-05 21:52:46 --> 404 Page Not Found --> category/1
ERROR - 2016-09-05 21:52:48 --> 404 Page Not Found --> category/1
ERROR - 2016-09-05 21:53:51 --> Severity: Notice  --> Undefined property: stdClass::$post_comment_status D:\openserver\domains\ci3\application\views\post\index.php 6
ERROR - 2016-09-05 21:54:13 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 65
ERROR - 2016-09-05 21:54:22 --> Could not find the language line "cart_image"
ERROR - 2016-09-05 21:54:24 --> Could not find the language line "cart_image"
ERROR - 2016-09-05 21:54:26 --> Could not find the language line "cart_image"
ERROR - 2016-09-05 21:54:40 --> Query error: Unknown column 'order_message' in 'field list'
ERROR - 2016-09-05 21:54:40 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-05 21:54:40 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-05 21:55:28 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 65
ERROR - 2016-09-05 21:55:32 --> Could not find the language line "cart_image"
ERROR - 2016-09-05 21:55:40 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 65
ERROR - 2016-09-05 21:55:45 --> 404 Page Not Found --> category/1
ERROR - 2016-09-05 21:55:50 --> 404 Page Not Found --> categorys
ERROR - 2016-09-05 21:56:11 --> 404 Page Not Found --> category/1
ERROR - 2016-09-05 21:56:13 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 65
ERROR - 2016-09-05 21:56:44 --> 404 Page Not Found --> category/1
ERROR - 2016-09-05 21:57:25 --> 404 Page Not Found --> category/1
ERROR - 2016-09-05 21:57:45 --> 404 Page Not Found --> category/1
ERROR - 2016-09-05 21:57:49 --> Query error: Table 'myshop.categories_products' doesn't exist
ERROR - 2016-09-05 21:57:49 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-05 21:57:49 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-05 22:01:16 --> 404 Page Not Found --> category/1
ERROR - 2016-09-05 22:01:17 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 65
ERROR - 2016-09-05 22:01:19 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 65
ERROR - 2016-09-05 22:01:21 --> Query error: Table 'myshop.categories_products' doesn't exist
ERROR - 2016-09-05 22:01:21 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-05 22:01:21 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-05 22:06:43 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 65
ERROR - 2016-09-05 22:08:18 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 65
ERROR - 2016-09-05 22:10:17 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 65
ERROR - 2016-09-05 22:10:20 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 65
ERROR - 2016-09-05 22:10:22 --> Severity: Notice  --> Undefined property: stdClass::$category_title D:\openserver\domains\ci3\application\views\widgets\products.php 19
ERROR - 2016-09-05 22:10:22 --> Severity: Notice  --> Undefined property: stdClass::$category_title D:\openserver\domains\ci3\application\views\widgets\products.php 19
ERROR - 2016-09-05 22:11:29 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 65
ERROR - 2016-09-05 22:11:31 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 65
ERROR - 2016-09-05 22:20:30 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 65
ERROR - 2016-09-05 22:23:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '=> (int)16 ORDER BY p.id_product DESC LIMIT 0,9' at line 1
ERROR - 2016-09-05 22:23:37 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-05 22:23:37 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-05 22:24:11 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 3
ERROR - 2016-09-05 22:24:11 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 14
ERROR - 2016-09-05 22:24:11 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 14
ERROR - 2016-09-05 22:24:11 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 15
ERROR - 2016-09-05 22:24:11 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 29
ERROR - 2016-09-05 22:24:11 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 35
ERROR - 2016-09-05 22:24:11 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 42
ERROR - 2016-09-05 22:24:11 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 45
ERROR - 2016-09-05 22:24:11 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 46
ERROR - 2016-09-05 22:24:11 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 47
ERROR - 2016-09-05 22:24:11 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 48
ERROR - 2016-09-05 22:24:11 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 49
ERROR - 2016-09-05 22:24:11 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 65
ERROR - 2016-09-05 22:25:20 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 3
ERROR - 2016-09-05 22:25:20 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 14
ERROR - 2016-09-05 22:25:20 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 14
ERROR - 2016-09-05 22:25:20 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 15
ERROR - 2016-09-05 22:25:20 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 29
ERROR - 2016-09-05 22:25:20 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 35
ERROR - 2016-09-05 22:25:20 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 42
ERROR - 2016-09-05 22:25:20 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 45
ERROR - 2016-09-05 22:25:20 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 46
ERROR - 2016-09-05 22:25:20 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 47
ERROR - 2016-09-05 22:25:20 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 48
ERROR - 2016-09-05 22:25:20 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 49
ERROR - 2016-09-05 22:25:20 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 65
ERROR - 2016-09-05 22:25:23 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 3
ERROR - 2016-09-05 22:25:23 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 14
ERROR - 2016-09-05 22:25:23 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 14
ERROR - 2016-09-05 22:25:23 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 15
ERROR - 2016-09-05 22:25:23 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 29
ERROR - 2016-09-05 22:25:23 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 35
ERROR - 2016-09-05 22:25:23 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 42
ERROR - 2016-09-05 22:25:23 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 45
ERROR - 2016-09-05 22:25:23 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 46
ERROR - 2016-09-05 22:25:23 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 47
ERROR - 2016-09-05 22:25:23 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 48
ERROR - 2016-09-05 22:25:23 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 49
ERROR - 2016-09-05 22:25:23 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 65
ERROR - 2016-09-05 22:27:20 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 65
ERROR - 2016-09-05 22:28:06 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 67
ERROR - 2016-09-05 22:28:20 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 68
ERROR - 2016-09-05 22:28:25 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 68
