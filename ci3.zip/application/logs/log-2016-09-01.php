<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-09-01 13:47:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\openserver\domains\ci3\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-09-01 13:47:30 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-01 13:47:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\openserver\domains\ci3\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-09-01 13:47:36 --> Query error: Table 'ci3.aparat_p' doesn't exist
ERROR - 2016-09-01 16:12:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\openserver\domains\ci3\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-09-01 16:12:33 --> Query error: Table 'ci3.aparaty' doesn't exist
ERROR - 2016-09-01 16:12:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\openserver\domains\ci3\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-09-01 16:12:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\openserver\domains\ci3\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-09-01 16:12:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\openserver\domains\ci3\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-09-01 16:12:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\openserver\domains\ci3\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-09-01 16:13:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\openserver\domains\ci3\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-09-01 16:13:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\openserver\domains\ci3\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-09-01 16:13:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\openserver\domains\ci3\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-09-01 16:17:26 --> Severity: Warning  --> mysqli_connect(): (HY000/1049): Unknown database 'orders' D:\openserver\domains\ci3\system\database\drivers\mysqli\mysqli_driver.php 77
ERROR - 2016-09-01 16:17:26 --> Unable to connect to the database
ERROR - 2016-09-01 16:17:30 --> Severity: Warning  --> mysqli_connect(): (HY000/1049): Unknown database 'orders' D:\openserver\domains\ci3\system\database\drivers\mysqli\mysqli_driver.php 77
ERROR - 2016-09-01 16:17:30 --> Unable to connect to the database
ERROR - 2016-09-01 16:17:37 --> Severity: Warning  --> mysqli_connect(): (HY000/1049): Unknown database 'orders' D:\openserver\domains\ci3\system\database\drivers\mysqli\mysqli_driver.php 77
ERROR - 2016-09-01 16:17:37 --> Unable to connect to the database
