<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-09-16 10:57:49 --> 404 Page Not Found --> ect.min.map
ERROR - 2016-09-16 10:57:54 --> 404 Page Not Found --> blogs/blog
ERROR - 2016-09-16 10:57:59 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 15:11:34 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 15:12:52 --> 404 Page Not Found --> cart_items
ERROR - 2016-09-16 15:13:00 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 15:36:21 --> Severity: Notice  --> Undefined index: img D:\openserver\domains\ci3\application\views\layout\main.php 180
ERROR - 2016-09-16 15:37:30 --> Severity: Notice  --> Undefined index: img D:\openserver\domains\ci3\application\views\layout\main.php 180
ERROR - 2016-09-16 15:40:14 --> Severity: Notice  --> Undefined index: img D:\openserver\domains\ci3\application\views\layout\main.php 180
ERROR - 2016-09-16 15:41:12 --> Severity: Notice  --> Undefined index: img D:\openserver\domains\ci3\application\views\layout\main.php 180
ERROR - 2016-09-16 15:41:28 --> Severity: Notice  --> Undefined index: img D:\openserver\domains\ci3\application\views\layout\main.php 180
ERROR - 2016-09-16 16:01:57 --> Severity: Notice  --> Array to string conversion D:\openserver\domains\ci3\application\views\layout\main.php 181
ERROR - 2016-09-16 16:07:31 --> Severity: Notice  --> Undefined index: href D:\openserver\domains\ci3\application\views\layout\main.php 184
ERROR - 2016-09-16 16:09:01 --> 404 Page Not Found --> 53
ERROR - 2016-09-16 16:13:37 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 16:15:29 --> 404 Page Not Found --> cart_items
ERROR - 2016-09-16 16:15:58 --> 404 Page Not Found --> cart_items
ERROR - 2016-09-16 16:16:14 --> 404 Page Not Found --> cart_items
ERROR - 2016-09-16 16:31:20 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 16:31:26 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 16:31:27 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 16:31:27 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 16:31:28 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 16:31:31 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 16:31:32 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 16:31:51 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 16:31:52 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 16:31:52 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 16:32:12 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 16:32:22 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 16:33:44 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 16:35:50 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 16:36:04 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 16:37:00 --> 404 Page Not Found --> cart_items
ERROR - 2016-09-16 16:47:54 --> 404 Page Not Found --> cart_items
ERROR - 2016-09-16 16:47:58 --> 404 Page Not Found --> cart_items
ERROR - 2016-09-16 16:53:35 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 16:53:37 --> 404 Page Not Found --> catalogs/1
ERROR - 2016-09-16 16:53:49 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 16:54:00 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 16:54:13 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 16:56:11 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:02:10 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:02:44 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:03:15 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:06:54 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:10:04 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:12:37 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:12:47 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:12:54 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:12:59 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:13:22 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:13:41 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:16:20 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:16:27 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:17:07 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:21:41 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:22:44 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:23:30 --> Severity: Notice  --> Array to string conversion D:\openserver\domains\ci3\application\controllers\cart.php 28
ERROR - 2016-09-16 17:23:30 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:27:19 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:30:20 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:30:26 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:30:54 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:30:59 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:31:25 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:31:36 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:31:49 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:32:07 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:32:35 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:38:42 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:38:47 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:38:56 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:40:02 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:40:10 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:40:24 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:40:57 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:41:26 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:41:27 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:41:28 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:42:10 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:42:11 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:42:12 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:42:17 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:42:25 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:47:52 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:47:53 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:47:53 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:47:53 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:47:54 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:47:54 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:47:59 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:47:59 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:47:59 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:48:05 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:48:11 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:48:20 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:48:35 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:48:44 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:49:36 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:49:42 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:56:10 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:56:10 --> Severity: Notice  --> Undefined index: basket D:\openserver\domains\ci3\application\controllers\cart.php 29
ERROR - 2016-09-16 17:57:11 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:57:15 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:57:37 --> Severity: Notice  --> Undefined offset: 53 D:\openserver\domains\ci3\application\controllers\cart.php 29
ERROR - 2016-09-16 17:57:37 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 17:58:01 --> 404 Page Not Found --> cart_items
ERROR - 2016-09-16 17:58:31 --> Severity: Notice  --> Undefined offset: 53 D:\openserver\domains\ci3\application\controllers\cart.php 29
ERROR - 2016-09-16 17:58:31 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 18:04:04 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 18:04:06 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 18:04:30 --> 404 Page Not Found --> cart_items
ERROR - 2016-09-16 18:05:53 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 18:05:55 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 18:06:00 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 18:06:02 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 18:08:35 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 18:08:52 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 18:08:57 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 18:08:59 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 18:09:02 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 18:09:13 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 18:09:14 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 18:09:16 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 18:10:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-16 18:10:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-16 18:10:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-16 18:10:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-16 18:10:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-16 18:10:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-16 18:10:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-16 18:10:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-16 18:10:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-16 18:10:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-16 18:10:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-16 18:10:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-16 18:10:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-16 18:10:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-16 18:10:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-16 18:10:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-16 18:10:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-16 18:10:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-16 18:10:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-16 18:10:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-16 18:10:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-16 18:10:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-16 18:10:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-16 18:10:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-16 18:15:09 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-16 18:15:58 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-16 18:15:58 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-16 18:15:58 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-16 18:15:58 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-16 18:15:58 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-16 18:15:58 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-16 18:15:58 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-16 18:15:58 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-16 18:15:58 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-16 18:15:58 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-16 18:15:58 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-16 18:15:58 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-16 18:15:58 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-16 18:15:58 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-16 18:15:58 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-16 18:15:58 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-16 18:15:58 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-16 18:15:58 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-16 18:15:58 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-16 18:15:58 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-16 18:15:58 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-16 18:15:58 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-16 18:15:58 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-16 18:15:58 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-16 18:19:40 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-16 18:22:18 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-16 18:22:18 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 18:22:18 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 18:22:18 --> upload_no_file_selected
ERROR - 2016-09-16 18:22:18 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 18:22:18 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 18:22:18 --> upload_no_file_selected
ERROR - 2016-09-16 18:22:18 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 18:22:18 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 18:22:18 --> upload_no_file_selected
ERROR - 2016-09-16 18:22:18 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 18:22:18 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 18:22:18 --> upload_no_file_selected
ERROR - 2016-09-16 18:23:32 --> Severity: Notice  --> Undefined offset: 0 D:\openserver\domains\ci3\application\controllers\product.php 28
ERROR - 2016-09-16 18:23:32 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\controllers\product.php 28
ERROR - 2016-09-16 18:23:32 --> Severity: Notice  --> Undefined offset: 0 D:\openserver\domains\ci3\application\controllers\product.php 28
ERROR - 2016-09-16 18:23:32 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\controllers\product.php 28
ERROR - 2016-09-16 18:23:32 --> Severity: Notice  --> Undefined offset: 0 D:\openserver\domains\ci3\application\controllers\product.php 29
ERROR - 2016-09-16 18:23:32 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\controllers\product.php 29
ERROR - 2016-09-16 18:23:32 --> Could not find the language line "product_not_found"
ERROR - 2016-09-16 18:23:42 --> Severity: Notice  --> Undefined offset: 0 D:\openserver\domains\ci3\application\controllers\product.php 28
ERROR - 2016-09-16 18:23:42 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\controllers\product.php 28
ERROR - 2016-09-16 18:23:42 --> Severity: Notice  --> Undefined offset: 0 D:\openserver\domains\ci3\application\controllers\product.php 28
ERROR - 2016-09-16 18:23:42 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\controllers\product.php 28
ERROR - 2016-09-16 18:23:42 --> Severity: Notice  --> Undefined offset: 0 D:\openserver\domains\ci3\application\controllers\product.php 29
ERROR - 2016-09-16 18:23:42 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\controllers\product.php 29
ERROR - 2016-09-16 18:23:42 --> Could not find the language line "product_not_found"
ERROR - 2016-09-16 18:23:55 --> Severity: Notice  --> Undefined offset: 0 D:\openserver\domains\ci3\application\controllers\product.php 28
ERROR - 2016-09-16 18:23:55 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\controllers\product.php 28
ERROR - 2016-09-16 18:23:55 --> Severity: Notice  --> Undefined offset: 0 D:\openserver\domains\ci3\application\controllers\product.php 28
ERROR - 2016-09-16 18:23:55 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\controllers\product.php 28
ERROR - 2016-09-16 18:23:55 --> Severity: Notice  --> Undefined offset: 0 D:\openserver\domains\ci3\application\controllers\product.php 29
ERROR - 2016-09-16 18:23:55 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\controllers\product.php 29
ERROR - 2016-09-16 18:23:55 --> Could not find the language line "product_not_found"
ERROR - 2016-09-16 19:01:59 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-16 19:01:59 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:01:59 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:01:59 --> upload_no_file_selected
ERROR - 2016-09-16 19:01:59 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:01:59 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:01:59 --> upload_no_file_selected
ERROR - 2016-09-16 19:01:59 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:01:59 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:01:59 --> upload_no_file_selected
ERROR - 2016-09-16 19:01:59 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:01:59 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:01:59 --> upload_no_file_selected
ERROR - 2016-09-16 19:01:59 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:01:59 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:01:59 --> upload_no_file_selected
ERROR - 2016-09-16 19:01:59 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:01:59 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:01:59 --> upload_no_file_selected
ERROR - 2016-09-16 19:01:59 --> Severity: Notice  --> Undefined variable: images D:\openserver\domains\ci3\application\models\gallery_model.php 64
ERROR - 2016-09-16 19:01:59 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-16 19:01:59 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-16 19:02:34 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-16 19:02:34 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:02:34 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:02:34 --> upload_no_file_selected
ERROR - 2016-09-16 19:02:34 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:02:34 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:02:34 --> upload_no_file_selected
ERROR - 2016-09-16 19:02:34 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:02:34 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:02:34 --> upload_no_file_selected
ERROR - 2016-09-16 19:02:34 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:02:34 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:02:34 --> upload_no_file_selected
ERROR - 2016-09-16 19:02:34 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:02:34 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:02:34 --> upload_no_file_selected
ERROR - 2016-09-16 19:02:34 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:02:34 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:02:34 --> upload_no_file_selected
ERROR - 2016-09-16 19:02:34 --> Severity: Notice  --> Undefined variable: images D:\openserver\domains\ci3\application\models\gallery_model.php 64
ERROR - 2016-09-16 19:02:34 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-16 19:02:34 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-16 19:06:14 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-16 19:06:14 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:06:14 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:06:14 --> upload_no_file_selected
ERROR - 2016-09-16 19:06:14 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:06:14 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:06:14 --> upload_no_file_selected
ERROR - 2016-09-16 19:06:14 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:06:14 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:06:14 --> upload_no_file_selected
ERROR - 2016-09-16 19:06:14 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:06:14 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:06:14 --> upload_no_file_selected
ERROR - 2016-09-16 19:06:14 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:06:14 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:06:14 --> upload_no_file_selected
ERROR - 2016-09-16 19:06:14 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:06:14 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:06:14 --> upload_no_file_selected
ERROR - 2016-09-16 19:06:30 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-16 19:06:30 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:06:30 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:06:30 --> upload_no_file_selected
ERROR - 2016-09-16 19:06:30 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:06:30 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:06:30 --> upload_no_file_selected
ERROR - 2016-09-16 19:06:30 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:06:30 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:06:30 --> upload_no_file_selected
ERROR - 2016-09-16 19:06:30 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:06:30 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:06:30 --> upload_no_file_selected
ERROR - 2016-09-16 19:06:30 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:06:30 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:06:30 --> upload_no_file_selected
ERROR - 2016-09-16 19:07:54 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-16 19:07:54 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:07:54 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:07:54 --> upload_no_file_selected
ERROR - 2016-09-16 19:07:54 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:07:54 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:07:54 --> upload_no_file_selected
ERROR - 2016-09-16 19:07:54 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:07:54 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:07:54 --> upload_no_file_selected
ERROR - 2016-09-16 19:07:54 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:07:54 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:07:54 --> upload_no_file_selected
ERROR - 2016-09-16 19:07:54 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:07:54 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:07:54 --> upload_no_file_selected
ERROR - 2016-09-16 19:08:24 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-16 19:08:24 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:08:24 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:08:24 --> upload_no_file_selected
ERROR - 2016-09-16 19:08:24 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:08:24 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:08:24 --> upload_no_file_selected
ERROR - 2016-09-16 19:08:24 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:08:24 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:08:24 --> upload_no_file_selected
ERROR - 2016-09-16 19:08:52 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-16 19:08:52 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:08:52 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:08:52 --> upload_no_file_selected
ERROR - 2016-09-16 19:08:52 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:08:52 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:08:52 --> upload_no_file_selected
ERROR - 2016-09-16 19:08:52 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:08:52 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:08:52 --> upload_no_file_selected
ERROR - 2016-09-16 19:08:52 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:08:52 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:08:52 --> upload_no_file_selected
ERROR - 2016-09-16 19:08:52 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:08:52 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:08:52 --> upload_no_file_selected
ERROR - 2016-09-16 19:08:52 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:08:52 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:08:52 --> upload_no_file_selected
ERROR - 2016-09-16 19:09:19 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-16 19:09:20 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:09:20 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:09:20 --> upload_no_file_selected
ERROR - 2016-09-16 19:09:20 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:09:20 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:09:20 --> upload_no_file_selected
ERROR - 2016-09-16 19:09:20 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:09:20 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:09:20 --> upload_no_file_selected
ERROR - 2016-09-16 19:09:20 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:09:20 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:09:20 --> upload_no_file_selected
ERROR - 2016-09-16 19:09:20 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:09:20 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:09:20 --> upload_no_file_selected
ERROR - 2016-09-16 19:09:20 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:09:20 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:09:20 --> upload_no_file_selected
ERROR - 2016-09-16 19:10:24 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-16 19:10:24 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:10:24 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:10:24 --> upload_no_file_selected
ERROR - 2016-09-16 19:10:24 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:10:24 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:10:24 --> upload_no_file_selected
ERROR - 2016-09-16 19:10:24 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:10:24 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:10:24 --> upload_no_file_selected
ERROR - 2016-09-16 19:10:24 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:10:24 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:10:24 --> upload_no_file_selected
ERROR - 2016-09-16 19:10:24 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:10:24 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:10:24 --> upload_no_file_selected
ERROR - 2016-09-16 19:10:24 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:10:24 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:10:24 --> upload_no_file_selected
ERROR - 2016-09-16 19:11:23 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-16 19:11:23 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:11:23 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:11:23 --> upload_no_file_selected
ERROR - 2016-09-16 19:11:23 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:11:23 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:11:23 --> upload_no_file_selected
ERROR - 2016-09-16 19:11:23 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:11:23 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:11:23 --> upload_no_file_selected
ERROR - 2016-09-16 19:11:23 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:11:23 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:11:23 --> upload_no_file_selected
ERROR - 2016-09-16 19:11:23 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:11:23 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:11:23 --> upload_no_file_selected
ERROR - 2016-09-16 19:11:23 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:11:23 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:11:23 --> upload_no_file_selected
ERROR - 2016-09-16 19:13:27 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 19:13:27 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 19:14:05 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-16 19:14:05 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:14:05 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:14:05 --> upload_no_file_selected
ERROR - 2016-09-16 19:14:05 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:14:05 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:14:05 --> upload_no_file_selected
ERROR - 2016-09-16 19:14:05 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:14:05 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:14:05 --> upload_no_file_selected
ERROR - 2016-09-16 19:14:05 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:14:05 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:14:05 --> upload_no_file_selected
ERROR - 2016-09-16 19:14:05 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:14:05 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:14:05 --> upload_no_file_selected
ERROR - 2016-09-16 19:14:05 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-16 19:14:05 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-16 19:14:05 --> upload_no_file_selected
ERROR - 2016-09-16 19:17:40 --> 404 Page Not Found --> blogs/blog
ERROR - 2016-09-16 19:19:23 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 19:19:27 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 19:21:42 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 19:21:54 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 19:27:26 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 19:31:03 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 19:31:19 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 19:31:45 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 19:32:26 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 19:32:45 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 19:33:20 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 19:34:03 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 19:34:51 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 19:35:00 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 19:35:04 --> 404 Page Not Found --> cart_items/85226174
ERROR - 2016-09-16 19:35:08 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 19:35:36 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 19:37:46 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 19:37:51 --> 404 Page Not Found --> cart_items/85226174
ERROR - 2016-09-16 19:38:31 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 19:41:52 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 19:42:34 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 19:42:35 --> 404 Page Not Found --> %D0%91%D0%B5%D0%BB%D1%8B%D0%B5%20%D1%80%D0%BE%D0%B7%D1%8B
ERROR - 2016-09-16 19:42:55 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 19:44:53 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 19:49:28 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 19:50:38 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 19:51:04 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 19:58:06 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 20:01:27 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 20:01:51 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 20:02:00 --> 404 Page Not Found --> cart_items/85226174
ERROR - 2016-09-16 20:02:14 --> 404 Page Not Found --> cart_items/85226174
ERROR - 2016-09-16 20:02:19 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 20:02:33 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 20:04:14 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 20:05:39 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 20:05:39 --> Severity: Notice  --> Undefined index: total D:\openserver\domains\ci3\application\views\cart\cart_form.php 210
ERROR - 2016-09-16 20:08:37 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 20:08:37 --> Severity: Notice  --> Undefined index: total D:\openserver\domains\ci3\application\views\cart\cart_form.php 210
ERROR - 2016-09-16 20:09:11 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 20:09:11 --> Severity: Notice  --> Undefined index: total D:\openserver\domains\ci3\application\views\cart\cart_form.php 210
ERROR - 2016-09-16 20:09:32 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 20:12:53 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 20:12:53 --> Severity: Notice  --> Undefined variable: total D:\openserver\domains\ci3\application\views\cart\cart_form.php 215
ERROR - 2016-09-16 20:13:47 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 20:13:47 --> Severity: Notice  --> Undefined variable: total D:\openserver\domains\ci3\application\views\cart\cart_form.php 216
ERROR - 2016-09-16 20:14:21 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 20:14:38 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 20:14:45 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 20:17:07 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 20:18:18 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 20:19:30 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 20:29:27 --> Severity: Notice  --> Undefined variable: id D:\openserver\domains\ci3\application\views\cart\cart_form.php 54
ERROR - 2016-09-16 20:29:27 --> Severity: Notice  --> Undefined variable: i D:\openserver\domains\ci3\application\views\cart\cart_form.php 55
ERROR - 2016-09-16 20:29:27 --> Severity: Notice  --> Undefined variable: id D:\openserver\domains\ci3\application\views\cart\cart_form.php 64
ERROR - 2016-09-16 20:29:27 --> Severity: Notice  --> Undefined variable: i D:\openserver\domains\ci3\application\views\cart\cart_form.php 65
ERROR - 2016-09-16 20:29:27 --> Severity: Notice  --> Undefined variable: id D:\openserver\domains\ci3\application\views\cart\cart_form.php 84
ERROR - 2016-09-16 20:29:27 --> Severity: Notice  --> Undefined variable: id D:\openserver\domains\ci3\application\views\cart\cart_form.php 85
ERROR - 2016-09-16 20:29:27 --> Severity: Notice  --> Undefined variable: i D:\openserver\domains\ci3\application\views\cart\cart_form.php 88
ERROR - 2016-09-16 20:29:27 --> Severity: Notice  --> Undefined variable: id D:\openserver\domains\ci3\application\views\cart\cart_form.php 91
ERROR - 2016-09-16 20:29:27 --> Severity: Notice  --> Undefined variable: i D:\openserver\domains\ci3\application\views\cart\cart_form.php 91
ERROR - 2016-09-16 20:29:27 --> Severity: Notice  --> Undefined variable: id D:\openserver\domains\ci3\application\views\cart\cart_form.php 92
ERROR - 2016-09-16 20:29:27 --> Severity: Notice  --> Undefined variable: i D:\openserver\domains\ci3\application\views\cart\cart_form.php 92
ERROR - 2016-09-16 20:29:27 --> Severity: Notice  --> Undefined variable: i D:\openserver\domains\ci3\application\views\cart\cart_form.php 109
ERROR - 2016-09-16 20:29:27 --> Severity: Notice  --> Undefined variable: i D:\openserver\domains\ci3\application\views\cart\cart_form.php 120
ERROR - 2016-09-16 20:29:27 --> Severity: Notice  --> Undefined variable: id D:\openserver\domains\ci3\application\views\cart\cart_form.php 127
ERROR - 2016-09-16 20:29:28 --> Severity: Notice  --> Undefined variable: id D:\openserver\domains\ci3\application\views\cart\cart_form.php 54
ERROR - 2016-09-16 20:29:28 --> Severity: Notice  --> Undefined variable: i D:\openserver\domains\ci3\application\views\cart\cart_form.php 55
ERROR - 2016-09-16 20:29:28 --> Severity: Notice  --> Undefined variable: id D:\openserver\domains\ci3\application\views\cart\cart_form.php 64
ERROR - 2016-09-16 20:29:28 --> Severity: Notice  --> Undefined variable: i D:\openserver\domains\ci3\application\views\cart\cart_form.php 65
ERROR - 2016-09-16 20:29:28 --> Severity: Notice  --> Undefined variable: id D:\openserver\domains\ci3\application\views\cart\cart_form.php 84
ERROR - 2016-09-16 20:29:28 --> Severity: Notice  --> Undefined variable: id D:\openserver\domains\ci3\application\views\cart\cart_form.php 85
ERROR - 2016-09-16 20:29:28 --> Severity: Notice  --> Undefined variable: i D:\openserver\domains\ci3\application\views\cart\cart_form.php 88
ERROR - 2016-09-16 20:29:28 --> Severity: Notice  --> Undefined variable: id D:\openserver\domains\ci3\application\views\cart\cart_form.php 91
ERROR - 2016-09-16 20:29:28 --> Severity: Notice  --> Undefined variable: i D:\openserver\domains\ci3\application\views\cart\cart_form.php 91
ERROR - 2016-09-16 20:29:28 --> Severity: Notice  --> Undefined variable: id D:\openserver\domains\ci3\application\views\cart\cart_form.php 92
ERROR - 2016-09-16 20:29:28 --> Severity: Notice  --> Undefined variable: i D:\openserver\domains\ci3\application\views\cart\cart_form.php 92
ERROR - 2016-09-16 20:29:28 --> Severity: Notice  --> Undefined variable: i D:\openserver\domains\ci3\application\views\cart\cart_form.php 109
ERROR - 2016-09-16 20:29:28 --> Severity: Notice  --> Undefined variable: i D:\openserver\domains\ci3\application\views\cart\cart_form.php 120
ERROR - 2016-09-16 20:29:28 --> Severity: Notice  --> Undefined variable: id D:\openserver\domains\ci3\application\views\cart\cart_form.php 127
ERROR - 2016-09-16 20:34:51 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 20:35:19 --> 404 Page Not Found --> cart_items
ERROR - 2016-09-16 20:40:57 --> Could not find the language line "cart_image"
ERROR - 2016-09-16 20:49:41 --> 404 Page Not Found --> page/contacts
