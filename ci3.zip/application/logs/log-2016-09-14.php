<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-09-14 13:04:30 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 13:04:31 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 13:04:33 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 13:04:37 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 16:25:00 --> 404 Page Not Found --> ect.min.map
ERROR - 2016-09-14 16:32:45 --> 404 Page Not Found --> collection/svitshoty
ERROR - 2016-09-14 16:33:06 --> 404 Page Not Found --> ect.min.map
ERROR - 2016-09-14 16:35:29 --> 404 Page Not Found --> ect.min.map
ERROR - 2016-09-14 16:36:13 --> 404 Page Not Found --> ect.min.map
ERROR - 2016-09-14 16:43:13 --> 404 Page Not Found --> ect.min.map
ERROR - 2016-09-14 16:43:22 --> 404 Page Not Found --> catalogs/1
ERROR - 2016-09-14 16:43:28 --> 404 Page Not Found --> catalogs/1
ERROR - 2016-09-14 16:44:00 --> 404 Page Not Found --> ect.min.map
ERROR - 2016-09-14 16:44:45 --> 404 Page Not Found --> ect.min.map
ERROR - 2016-09-14 16:45:01 --> 404 Page Not Found --> ect.min.map
ERROR - 2016-09-14 16:45:45 --> 404 Page Not Found --> ect.min.map
ERROR - 2016-09-14 16:46:18 --> 404 Page Not Found --> ect.min.map
ERROR - 2016-09-14 16:46:30 --> 404 Page Not Found --> ect.min.map
ERROR - 2016-09-14 16:46:46 --> 404 Page Not Found --> ect.min.map
ERROR - 2016-09-14 16:47:32 --> 404 Page Not Found --> ect.min.map
ERROR - 2016-09-14 16:47:37 --> 404 Page Not Found --> ect.min.map
ERROR - 2016-09-14 16:48:45 --> 404 Page Not Found --> ect.min.map
ERROR - 2016-09-14 16:50:48 --> 404 Page Not Found --> ect.min.map
ERROR - 2016-09-14 16:54:04 --> 404 Page Not Found --> blogs/blog
ERROR - 2016-09-14 16:55:44 --> 404 Page Not Found --> catalogs/1
ERROR - 2016-09-14 16:55:57 --> 404 Page Not Found --> ect.min.map
ERROR - 2016-09-14 16:57:32 --> 404 Page Not Found --> ect.min.map
ERROR - 2016-09-14 16:57:57 --> 404 Page Not Found --> ect.min.map
ERROR - 2016-09-14 16:58:35 --> 404 Page Not Found --> ect.min.map
ERROR - 2016-09-14 16:59:31 --> 404 Page Not Found --> ect.min.map
ERROR - 2016-09-14 17:01:45 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-14 17:05:25 --> 404 Page Not Found --> ect.min.map
ERROR - 2016-09-14 17:07:10 --> 404 Page Not Found --> ect.min.map
ERROR - 2016-09-14 17:12:34 --> 404 Page Not Found --> ect.min.map
ERROR - 2016-09-14 17:13:14 --> 404 Page Not Found --> ect.min.map
ERROR - 2016-09-14 17:13:50 --> 404 Page Not Found --> ect.min.map
ERROR - 2016-09-14 17:54:14 --> 404 Page Not Found --> cart_items.json
ERROR - 2016-09-14 17:54:15 --> 404 Page Not Found --> cart_items.json
ERROR - 2016-09-14 17:54:17 --> 404 Page Not Found --> cart_items.json
ERROR - 2016-09-14 18:04:36 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 17
ERROR - 2016-09-14 18:04:36 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 17
ERROR - 2016-09-14 18:04:36 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 17
ERROR - 2016-09-14 18:04:36 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 23
ERROR - 2016-09-14 18:04:36 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 23
ERROR - 2016-09-14 18:04:36 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\product\index.php 23
ERROR - 2016-09-14 18:18:39 --> 404 Page Not Found --> ect.min.map
ERROR - 2016-09-14 18:20:09 --> 404 Page Not Found --> ect.min.map
ERROR - 2016-09-14 18:21:16 --> 404 Page Not Found --> ect.min.map
ERROR - 2016-09-14 18:22:08 --> 404 Page Not Found --> ect.min.map
ERROR - 2016-09-14 18:45:37 --> 404 Page Not Found --> ect.min.map
ERROR - 2016-09-14 18:46:34 --> 404 Page Not Found --> ect.min.map
ERROR - 2016-09-14 19:04:43 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:16:56 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:17:00 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:20:12 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:20:20 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:20:25 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:20:43 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:21:27 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:21:35 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:23:38 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:23:43 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:28:06 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:31:04 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:31:14 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:32:12 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:32:15 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:32:20 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:32:21 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:32:27 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:34:12 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:34:19 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:34:22 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:34:24 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:34:24 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:35:23 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:35:25 --> 404 Page Not Found --> catalogs/1
ERROR - 2016-09-14 19:35:32 --> 404 Page Not Found --> catalogs/1
ERROR - 2016-09-14 19:36:06 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:36:20 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:39:42 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:42:53 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:42:55 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:42:56 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:43:17 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:44:24 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:50:21 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:51:37 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:53:51 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:53:55 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 19:54:25 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 20:04:55 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 20:08:23 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 20:08:26 --> Could not find the language line "cart_image"
ERROR - 2016-09-14 20:08:33 --> 404 Page Not Found --> cart_items
ERROR - 2016-09-14 20:08:50 --> Could not find the language line "cart_image"
