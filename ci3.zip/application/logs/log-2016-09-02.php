<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-09-02 11:36:49 --> 404 Page Not Found --> catalog
ERROR - 2016-09-02 11:37:32 --> 404 Page Not Found --> catalog___
ERROR - 2016-09-02 11:56:20 --> Severity: Notice  --> Undefined variable: lang D:\openserver\domains\ci3\application\modules\catalog\views\view.php 31
ERROR - 2016-09-02 12:08:16 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 12:10:34 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 12:10:40 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 12:10:42 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 12:15:25 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-02 12:16:32 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-02 12:17:08 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 12:18:05 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 12:19:09 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 12:19:55 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 12:20:00 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 12:20:39 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 12:20:44 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 12:20:46 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 12:21:15 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-02 12:21:28 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-02 12:22:43 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-02 12:34:19 --> 404 Page Not Found --> catalog/show/5
ERROR - 2016-09-02 12:35:15 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-02 12:56:01 --> 404 Page Not Found --> catalog/add
ERROR - 2016-09-02 13:06:10 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-02 13:09:19 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-02 13:12:31 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-02 13:12:46 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-02 13:12:52 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-02 13:13:46 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-02 13:19:11 --> 404 Page Not Found --> catalog
ERROR - 2016-09-02 13:22:01 --> 404 Page Not Found --> catalog
ERROR - 2016-09-02 13:42:53 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-02 13:43:56 --> Severity: Notice  --> Undefined index: catalog_title D:\openserver\domains\ci3\application\modules\categories\views\view.php 75
ERROR - 2016-09-02 13:58:07 --> Severity: Notice  --> Undefined variable: result D:\openserver\domains\ci3\application\modules\categories\models\categoriess.php 38
ERROR - 2016-09-02 14:00:03 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 14:05:14 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-02 14:09:03 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-02 14:09:09 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-02 14:10:13 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 14:12:05 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 14:12:06 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 14:12:08 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 14:14:04 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 14:14:11 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-02 14:14:16 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-02 14:14:22 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-02 14:18:23 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-02 14:39:12 --> Severity: Notice  --> Undefined variable: category D:\openserver\domains\ci3\application\modules\products\views\form.php 25
ERROR - 2016-09-02 14:39:12 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\system\helpers\form_helper.php 332
ERROR - 2016-09-02 14:43:32 --> Severity: Notice  --> Undefined index: category_title D:\openserver\domains\ci3\application\modules\products\views\form.php 26
ERROR - 2016-09-02 14:45:37 --> Severity: Notice  --> Undefined index: category_title D:\openserver\domains\ci3\application\modules\products\views\form.php 26
ERROR - 2016-09-02 14:53:40 --> Severity: Notice  --> Undefined variable: delivery D:\openserver\domains\ci3\application\modules\orders\views\form.php 101
ERROR - 2016-09-02 14:53:40 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\system\helpers\form_helper.php 332
ERROR - 2016-09-02 14:53:40 --> Severity: Notice  --> Undefined variable: payment D:\openserver\domains\ci3\application\modules\orders\views\form.php 116
ERROR - 2016-09-02 14:53:40 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\system\helpers\form_helper.php 332
ERROR - 2016-09-02 14:55:38 --> Severity: Notice  --> Undefined variable: delivery D:\openserver\domains\ci3\application\modules\orders\views\form.php 101
ERROR - 2016-09-02 14:55:38 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\system\helpers\form_helper.php 332
ERROR - 2016-09-02 14:55:38 --> Severity: Notice  --> Undefined variable: payment D:\openserver\domains\ci3\application\modules\orders\views\form.php 116
ERROR - 2016-09-02 14:55:38 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\system\helpers\form_helper.php 332
ERROR - 2016-09-02 14:58:18 --> Severity: Notice  --> Undefined variable: delivery D:\openserver\domains\ci3\application\modules\orders\views\form.php 101
ERROR - 2016-09-02 14:58:18 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\system\helpers\form_helper.php 332
ERROR - 2016-09-02 14:58:18 --> Severity: Notice  --> Undefined variable: payment D:\openserver\domains\ci3\application\modules\orders\views\form.php 116
ERROR - 2016-09-02 14:58:18 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\system\helpers\form_helper.php 332
ERROR - 2016-09-02 15:02:21 --> Severity: Notice  --> Undefined index: paid D:\openserver\domains\ci3\application\modules\orders\views\form.php 139
ERROR - 2016-09-02 15:02:21 --> Severity: Notice  --> Undefined index: paid D:\openserver\domains\ci3\application\modules\orders\views\form.php 140
ERROR - 2016-09-02 15:02:35 --> Severity: Notice  --> Undefined index: paid D:\openserver\domains\ci3\application\modules\orders\views\form.php 131
ERROR - 2016-09-02 15:02:35 --> Severity: Notice  --> Undefined index: paid D:\openserver\domains\ci3\application\modules\orders\views\form.php 132
ERROR - 2016-09-02 15:03:32 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-02 15:21:03 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-02 15:21:28 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-02 15:27:15 --> Query error: Unknown column 'categories.catalog_id' in 'on clause'
ERROR - 2016-09-02 15:27:47 --> Query error: Unknown column 'categories.catalog_id' in 'on clause'
ERROR - 2016-09-02 15:27:47 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-02 15:27:47 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-02 15:32:51 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:33:25 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:35:32 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:35:33 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:36:33 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:37:03 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:39:15 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:39:34 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-02 15:39:43 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:40:04 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:40:22 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:40:38 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:40:50 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:41:04 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:41:10 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:42:02 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:42:47 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:42:52 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:42:55 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:42:59 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-02 15:43:00 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:43:04 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:44:00 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:46:16 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:47:33 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:48:17 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:48:19 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:48:27 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-02 15:48:28 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:48:32 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:48:34 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:48:36 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:48:43 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:48:52 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:49:04 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:49:26 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:49:28 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:49:35 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-02 15:49:35 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:49:39 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:49:41 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:49:43 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:51:36 --> Severity: Notice  --> Undefined index: payment_name D:\openserver\domains\ci3\application\modules\orders\views\view.php 96
ERROR - 2016-09-02 15:54:49 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:55:10 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-02 15:55:18 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 15:55:40 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-02 15:57:49 --> Severity: Notice  --> Undefined variable: status D:\openserver\domains\ci3\application\modules\orders\views\form.php 131
ERROR - 2016-09-02 15:57:49 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\system\helpers\form_helper.php 332
ERROR - 2016-09-02 16:00:16 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-02 16:02:23 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 16:02:32 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-02 16:02:33 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-02 16:02:43 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-02 16:03:17 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-02 16:19:37 --> Severity: Notice  --> Undefined index: order_adres D:\openserver\domains\ci3\application\modules\orders\views\view.php 88
ERROR - 2016-09-02 20:56:32 --> Severity: Warning  --> scandir(): Directory name cannot be empty D:\openserver\domains\ci3\application\models\gallery_model.php 50
ERROR - 2016-09-02 20:56:32 --> Severity: Warning  --> array_diff(): Argument #1 is not an array D:\openserver\domains\ci3\application\models\gallery_model.php 51
ERROR - 2016-09-02 20:56:32 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\models\gallery_model.php 55
ERROR - 2016-09-02 20:57:00 --> Severity: Warning  --> scandir(): Directory name cannot be empty D:\openserver\domains\ci3\application\models\gallery_model.php 50
ERROR - 2016-09-02 20:57:00 --> Severity: Warning  --> array_diff(): Argument #1 is not an array D:\openserver\domains\ci3\application\models\gallery_model.php 51
ERROR - 2016-09-02 20:57:00 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\models\gallery_model.php 55
ERROR - 2016-09-02 21:12:31 --> Severity: Warning  --> scandir(): Directory name cannot be empty D:\openserver\domains\ci3\application\models\gallery_model.php 50
ERROR - 2016-09-02 21:12:31 --> Severity: Warning  --> array_diff(): Argument #1 is not an array D:\openserver\domains\ci3\application\models\gallery_model.php 51
ERROR - 2016-09-02 21:12:31 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\models\gallery_model.php 55
