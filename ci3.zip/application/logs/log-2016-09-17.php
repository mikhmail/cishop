<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-09-17 10:40:58 --> Severity: Notice  --> Undefined index: cart D:\openserver\domains\ci3\application\views\layout\main.php 177
ERROR - 2016-09-17 10:40:58 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\views\layout\main.php 177
ERROR - 2016-09-17 10:42:19 --> Severity: Notice  --> Undefined index: cart D:\openserver\domains\ci3\application\views\layout\main.php 177
ERROR - 2016-09-17 10:42:19 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\views\layout\main.php 177
ERROR - 2016-09-17 10:43:36 --> Severity: Notice  --> Undefined index: cart D:\openserver\domains\ci3\application\views\layout\main.php 177
ERROR - 2016-09-17 10:43:36 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\views\layout\main.php 177
ERROR - 2016-09-17 10:49:56 --> Severity: Notice  --> Undefined index: cart D:\openserver\domains\ci3\application\views\layout\main.php 178
ERROR - 2016-09-17 10:49:56 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\views\layout\main.php 178
ERROR - 2016-09-17 10:50:04 --> 404 Page Not Found --> cart_items
ERROR - 2016-09-17 10:50:06 --> Severity: Notice  --> Undefined index: cart D:\openserver\domains\ci3\application\views\layout\main.php 178
ERROR - 2016-09-17 10:50:06 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\views\layout\main.php 178
ERROR - 2016-09-17 10:50:07 --> Severity: Notice  --> Undefined index: cart D:\openserver\domains\ci3\application\views\layout\main.php 178
ERROR - 2016-09-17 10:50:07 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\views\layout\main.php 178
ERROR - 2016-09-17 10:53:30 --> 404 Page Not Found --> checkoup
ERROR - 2016-09-17 10:53:50 --> 404 Page Not Found --> checkout
ERROR - 2016-09-17 10:53:52 --> 404 Page Not Found --> checkout
ERROR - 2016-09-17 11:41:10 --> Severity: Notice  --> Undefined index: cart D:\openserver\domains\ci3\application\views\layout\main.php 178
ERROR - 2016-09-17 11:41:10 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\views\layout\main.php 178
ERROR - 2016-09-17 11:41:11 --> Severity: Notice  --> Undefined index: cart D:\openserver\domains\ci3\application\views\layout\main.php 178
ERROR - 2016-09-17 11:41:11 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\views\layout\main.php 178
ERROR - 2016-09-17 11:41:29 --> Severity: Notice  --> Undefined index: cart D:\openserver\domains\ci3\application\views\layout\main.php 178
ERROR - 2016-09-17 11:41:29 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\views\layout\main.php 178
ERROR - 2016-09-17 12:41:28 --> 404 Page Not Found --> blogs/blog
ERROR - 2016-09-17 13:29:44 --> Severity: Notice  --> Undefined index: address D:\openserver\domains\ci3\application\controllers\cart.php 85
ERROR - 2016-09-17 13:29:44 --> Language file contains no data: language/russian/email_lang.php
ERROR - 2016-09-17 13:29:44 --> Could not find the language line "email_sent"
ERROR - 2016-09-17 13:36:08 --> Language file contains no data: language/russian/email_lang.php
ERROR - 2016-09-17 13:36:08 --> Could not find the language line "email_sent"
ERROR - 2016-09-17 13:41:50 --> Language file contains no data: language/russian/email_lang.php
ERROR - 2016-09-17 13:41:50 --> Could not find the language line "email_sent"
ERROR - 2016-09-17 13:48:16 --> Severity: Notice  --> Undefined variable: id D:\openserver\domains\ci3\application\controllers\cart.php 112
ERROR - 2016-09-17 13:48:16 --> Severity: Notice  --> Use of undefined constant order_id - assumed 'order_id' D:\openserver\domains\ci3\application\views\cart\complete.php 2
ERROR - 2016-09-17 13:48:33 --> Severity: Notice  --> Undefined variable: id D:\openserver\domains\ci3\application\controllers\cart.php 112
ERROR - 2016-09-17 13:49:15 --> Severity: Notice  --> Undefined variable: order_id D:\openserver\domains\ci3\application\views\cart\complete.php 2
ERROR - 2016-09-17 13:50:16 --> Severity: Notice  --> Undefined variable: id D:\openserver\domains\ci3\application\controllers\cart.php 110
ERROR - 2016-09-17 13:50:38 --> 404 Page Not Found --> cart_items
ERROR - 2016-09-17 13:50:58 --> Language file contains no data: language/russian/email_lang.php
ERROR - 2016-09-17 13:50:58 --> Could not find the language line "email_sent"
ERROR - 2016-09-17 14:25:46 --> 404 Page Not Found --> page/contacts
ERROR - 2016-09-17 14:25:55 --> 404 Page Not Found --> page/about
ERROR - 2016-09-17 14:26:26 --> 404 Page Not Found --> page/about
ERROR - 2016-09-17 14:26:27 --> 404 Page Not Found --> page/about
ERROR - 2016-09-17 14:26:55 --> 404 Page Not Found --> page/about
ERROR - 2016-09-17 14:28:06 --> 404 Page Not Found --> page/about
ERROR - 2016-09-17 14:28:27 --> 404 Page Not Found --> page/about
ERROR - 2016-09-17 14:28:28 --> 404 Page Not Found --> page/about
ERROR - 2016-09-17 14:35:47 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\posts\views\form.php 81
ERROR - 2016-09-17 14:35:47 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\posts\views\form.php 82
ERROR - 2016-09-17 14:36:21 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\posts\views\form.php 81
ERROR - 2016-09-17 14:36:21 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\posts\views\form.php 82
ERROR - 2016-09-17 14:37:33 --> Severity: Notice  --> Undefined index: title D:\openserver\domains\ci3\application\views\layout\main.php 9
ERROR - 2016-09-17 14:37:33 --> Severity: Notice  --> Undefined index: description D:\openserver\domains\ci3\application\views\layout\main.php 10
ERROR - 2016-09-17 14:37:33 --> Severity: Notice  --> Undefined index: keywords D:\openserver\domains\ci3\application\views\layout\main.php 11
ERROR - 2016-09-17 14:38:45 --> Severity: Notice  --> Undefined index: title D:\openserver\domains\ci3\application\views\layout\main.php 9
ERROR - 2016-09-17 14:38:45 --> Severity: Notice  --> Undefined index: description D:\openserver\domains\ci3\application\views\layout\main.php 10
ERROR - 2016-09-17 14:38:45 --> Severity: Notice  --> Undefined index: keywords D:\openserver\domains\ci3\application\views\layout\main.php 11
ERROR - 2016-09-17 14:38:50 --> 404 Page Not Found --> %D1%84%D1%8B%D0%B2%D1%84%D1%8B%D0%B2
ERROR - 2016-09-17 14:39:44 --> 404 Page Not Found --> blogs/blog
ERROR - 2016-09-17 14:39:54 --> 404 Page Not Found --> blogs/blog
ERROR - 2016-09-17 14:44:23 --> Severity: Notice  --> Undefined variable: postss D:\openserver\domains\ci3\application\modules\posts\views\view.php 43
ERROR - 2016-09-17 14:44:57 --> Severity: Notice  --> Undefined variable: postss D:\openserver\domains\ci3\application\modules\posts\views\view.php 43
ERROR - 2016-09-17 14:48:32 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-17 14:52:40 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-17 14:56:31 --> Severity: Notice  --> Undefined variable: postss D:\openserver\domains\ci3\application\modules\pages\views\view.php 43
ERROR - 2016-09-17 14:57:13 --> Severity: Notice  --> Undefined variable: posts D:\openserver\domains\ci3\application\modules\pages\views\form.php 31
ERROR - 2016-09-17 14:57:13 --> Severity: Notice  --> Undefined variable: posts D:\openserver\domains\ci3\application\modules\pages\views\form.php 50
ERROR - 2016-09-17 14:57:13 --> Severity: Notice  --> Undefined variable: posts D:\openserver\domains\ci3\application\modules\pages\views\form.php 69
ERROR - 2016-09-17 14:57:13 --> Severity: Notice  --> Undefined variable: posts D:\openserver\domains\ci3\application\modules\pages\views\form.php 81
ERROR - 2016-09-17 14:57:13 --> Severity: Notice  --> Undefined variable: posts D:\openserver\domains\ci3\application\modules\pages\views\form.php 82
ERROR - 2016-09-17 14:57:20 --> Severity: Notice  --> Undefined variable: posts D:\openserver\domains\ci3\application\modules\pages\views\form.php 31
ERROR - 2016-09-17 14:57:20 --> Severity: Notice  --> Undefined variable: posts D:\openserver\domains\ci3\application\modules\pages\views\form.php 50
ERROR - 2016-09-17 14:57:20 --> Severity: Notice  --> Undefined variable: posts D:\openserver\domains\ci3\application\modules\pages\views\form.php 69
ERROR - 2016-09-17 14:57:20 --> Severity: Notice  --> Undefined variable: posts D:\openserver\domains\ci3\application\modules\pages\views\form.php 81
ERROR - 2016-09-17 14:57:20 --> Severity: Notice  --> Undefined variable: posts D:\openserver\domains\ci3\application\modules\pages\views\form.php 82
ERROR - 2016-09-17 14:57:23 --> Severity: Notice  --> Undefined variable: posts D:\openserver\domains\ci3\application\modules\pages\views\form.php 31
ERROR - 2016-09-17 14:57:23 --> Severity: Notice  --> Undefined variable: posts D:\openserver\domains\ci3\application\modules\pages\views\form.php 50
ERROR - 2016-09-17 14:57:23 --> Severity: Notice  --> Undefined variable: posts D:\openserver\domains\ci3\application\modules\pages\views\form.php 69
ERROR - 2016-09-17 14:57:23 --> Severity: Notice  --> Undefined variable: posts D:\openserver\domains\ci3\application\modules\pages\views\form.php 81
ERROR - 2016-09-17 14:57:23 --> Severity: Notice  --> Undefined variable: posts D:\openserver\domains\ci3\application\modules\pages\views\form.php 82
ERROR - 2016-09-17 14:58:08 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-17 14:58:20 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-17 14:59:37 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-17 14:59:58 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-17 15:01:02 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\pages\views\form.php 81
ERROR - 2016-09-17 15:01:02 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\pages\views\form.php 82
ERROR - 2016-09-17 15:03:24 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\pages\views\form.php 103
ERROR - 2016-09-17 15:03:24 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\pages\views\form.php 104
ERROR - 2016-09-17 15:09:52 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\pages\views\form.php 104
ERROR - 2016-09-17 15:09:52 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\pages\views\form.php 105
ERROR - 2016-09-17 15:10:09 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\pages\views\form.php 104
ERROR - 2016-09-17 15:10:09 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\pages\views\form.php 105
ERROR - 2016-09-17 15:10:57 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\pages\views\form.php 104
ERROR - 2016-09-17 15:10:57 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\pages\views\form.php 105
ERROR - 2016-09-17 15:11:32 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\pages\views\form.php 104
ERROR - 2016-09-17 15:11:32 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\pages\views\form.php 105
ERROR - 2016-09-17 15:11:36 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-17 15:11:53 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-17 15:11:55 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-17 15:12:12 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-17 15:12:14 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-17 15:12:16 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\pages\views\form.php 104
ERROR - 2016-09-17 15:12:16 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\pages\views\form.php 105
ERROR - 2016-09-17 15:12:16 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-17 15:13:29 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\pages\views\form.php 104
ERROR - 2016-09-17 15:13:29 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\pages\views\form.php 105
ERROR - 2016-09-17 15:13:29 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-17 15:14:28 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\pages\views\form.php 104
ERROR - 2016-09-17 15:14:28 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\pages\views\form.php 105
ERROR - 2016-09-17 15:14:29 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-17 15:14:51 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\pages\views\form.php 104
ERROR - 2016-09-17 15:14:51 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\pages\views\form.php 105
ERROR - 2016-09-17 15:14:51 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-17 15:15:11 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\pages\views\form.php 104
ERROR - 2016-09-17 15:15:11 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\pages\views\form.php 105
ERROR - 2016-09-17 15:15:11 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-17 15:15:23 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-17 15:15:34 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-17 15:15:57 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-17 15:16:04 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\pages\views\form.php 104
ERROR - 2016-09-17 15:16:04 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\pages\views\form.php 105
ERROR - 2016-09-17 15:16:31 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\pages\views\form.php 104
ERROR - 2016-09-17 15:16:31 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\pages\views\form.php 105
ERROR - 2016-09-17 15:16:41 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\pages\views\form.php 104
ERROR - 2016-09-17 15:16:41 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\pages\views\form.php 105
ERROR - 2016-09-17 15:16:56 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-17 15:21:03 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\pages\views\form.php 104
ERROR - 2016-09-17 15:21:03 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\pages\views\form.php 105
ERROR - 2016-09-17 15:21:25 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-17 15:21:38 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-17 15:21:55 --> Severity: Notice  --> Undefined index: title D:\openserver\domains\ci3\application\views\layout\main.php 9
ERROR - 2016-09-17 15:21:55 --> Severity: Notice  --> Undefined index: description D:\openserver\domains\ci3\application\views\layout\main.php 10
ERROR - 2016-09-17 15:21:55 --> Severity: Notice  --> Undefined index: keywords D:\openserver\domains\ci3\application\views\layout\main.php 11
ERROR - 2016-09-17 15:22:07 --> 404 Page Not Found --> delivery
ERROR - 2016-09-17 15:22:41 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\pages\views\form.php 104
ERROR - 2016-09-17 15:22:41 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\pages\views\form.php 105
ERROR - 2016-09-17 15:26:11 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-17 15:26:48 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-17 15:27:42 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-17 15:31:26 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\posts\views\form.php 81
ERROR - 2016-09-17 15:31:26 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\posts\views\form.php 82
ERROR - 2016-09-17 15:31:49 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-17 15:31:55 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-17 15:32:07 --> 404 Page Not Found --> blogs/blog
ERROR - 2016-09-17 15:32:29 --> 404 Page Not Found --> delivery
ERROR - 2016-09-17 15:34:47 --> 404 Page Not Found --> pages/delivery
ERROR - 2016-09-17 15:35:07 --> Severity: Notice  --> Undefined index: title D:\openserver\domains\ci3\application\views\layout\main.php 9
ERROR - 2016-09-17 15:35:07 --> Severity: Notice  --> Undefined index: description D:\openserver\domains\ci3\application\views\layout\main.php 10
ERROR - 2016-09-17 15:35:07 --> Severity: Notice  --> Undefined index: keywords D:\openserver\domains\ci3\application\views\layout\main.php 11
ERROR - 2016-09-17 15:35:24 --> Severity: Notice  --> Undefined index: title D:\openserver\domains\ci3\application\views\layout\main.php 9
ERROR - 2016-09-17 15:35:24 --> Severity: Notice  --> Undefined index: description D:\openserver\domains\ci3\application\views\layout\main.php 10
ERROR - 2016-09-17 15:35:24 --> Severity: Notice  --> Undefined index: keywords D:\openserver\domains\ci3\application\views\layout\main.php 11
ERROR - 2016-09-17 15:36:59 --> Severity: Notice  --> Undefined index: title D:\openserver\domains\ci3\application\views\layout\main.php 9
ERROR - 2016-09-17 15:36:59 --> Severity: Notice  --> Undefined index: description D:\openserver\domains\ci3\application\views\layout\main.php 10
ERROR - 2016-09-17 15:36:59 --> Severity: Notice  --> Undefined index: keywords D:\openserver\domains\ci3\application\views\layout\main.php 11
ERROR - 2016-09-17 15:37:34 --> Severity: Notice  --> Undefined index: title D:\openserver\domains\ci3\application\views\layout\main.php 9
ERROR - 2016-09-17 15:37:34 --> Severity: Notice  --> Undefined index: description D:\openserver\domains\ci3\application\views\layout\main.php 10
ERROR - 2016-09-17 15:37:34 --> Severity: Notice  --> Undefined index: keywords D:\openserver\domains\ci3\application\views\layout\main.php 11
ERROR - 2016-09-17 15:38:12 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-17 15:38:41 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-17 16:07:00 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 12
ERROR - 2016-09-17 16:07:00 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 12
ERROR - 2016-09-17 16:07:00 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 12
ERROR - 2016-09-17 16:07:00 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 12
ERROR - 2016-09-17 16:07:00 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 12
ERROR - 2016-09-17 16:07:00 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 12
ERROR - 2016-09-17 16:07:00 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 18
ERROR - 2016-09-17 16:07:00 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 18
ERROR - 2016-09-17 16:07:00 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 18
ERROR - 2016-09-17 16:07:00 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 18
ERROR - 2016-09-17 16:07:00 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 18
ERROR - 2016-09-17 16:07:00 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 18
ERROR - 2016-09-17 16:07:02 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 12
ERROR - 2016-09-17 16:07:02 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 12
ERROR - 2016-09-17 16:07:02 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 12
ERROR - 2016-09-17 16:07:02 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 12
ERROR - 2016-09-17 16:07:02 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 12
ERROR - 2016-09-17 16:07:02 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 12
ERROR - 2016-09-17 16:07:02 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 18
ERROR - 2016-09-17 16:07:02 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 18
ERROR - 2016-09-17 16:07:02 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 18
ERROR - 2016-09-17 16:07:02 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 18
ERROR - 2016-09-17 16:07:02 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 18
ERROR - 2016-09-17 16:07:02 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 18
ERROR - 2016-09-17 16:07:30 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 19
ERROR - 2016-09-17 16:07:30 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 19
ERROR - 2016-09-17 16:07:30 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 19
ERROR - 2016-09-17 16:07:30 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 19
ERROR - 2016-09-17 16:07:30 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 25
ERROR - 2016-09-17 16:07:30 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 25
ERROR - 2016-09-17 16:07:30 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 25
ERROR - 2016-09-17 16:07:30 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 25
ERROR - 2016-09-17 16:12:27 --> Severity: Notice  --> Undefined variable: category D:\openserver\domains\ci3\application\views\widgets\products_cat.php 17
ERROR - 2016-09-17 16:12:27 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products_cat.php 17
ERROR - 2016-09-17 16:12:27 --> Severity: Notice  --> Undefined variable: category D:\openserver\domains\ci3\application\views\widgets\products_cat.php 17
ERROR - 2016-09-17 16:12:27 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products_cat.php 17
ERROR - 2016-09-17 16:12:27 --> Severity: Notice  --> Undefined variable: category D:\openserver\domains\ci3\application\views\widgets\products_cat.php 17
ERROR - 2016-09-17 16:12:27 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products_cat.php 17
ERROR - 2016-09-17 16:23:34 --> 404 Page Not Found --> cart_items
ERROR - 2016-09-17 16:39:36 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-17 16:39:36 --> Could not find the language line "required"
ERROR - 2016-09-17 16:41:14 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-17 16:41:14 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 16:41:14 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 16:41:14 --> upload_no_file_selected
ERROR - 2016-09-17 16:41:14 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 16:41:14 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 16:41:14 --> upload_no_file_selected
ERROR - 2016-09-17 16:41:14 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 16:41:14 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 16:41:14 --> upload_no_file_selected
ERROR - 2016-09-17 16:41:14 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 16:41:14 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 16:41:14 --> upload_no_file_selected
ERROR - 2016-09-17 16:41:14 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 16:41:14 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 16:41:14 --> upload_no_file_selected
ERROR - 2016-09-17 16:41:34 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-17 16:41:34 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 16:41:34 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 16:41:34 --> upload_no_file_selected
ERROR - 2016-09-17 16:41:34 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 16:41:34 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 16:41:34 --> upload_no_file_selected
ERROR - 2016-09-17 16:41:34 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 16:41:34 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 16:41:34 --> upload_no_file_selected
ERROR - 2016-09-17 16:41:34 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 16:41:34 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 16:41:34 --> upload_no_file_selected
ERROR - 2016-09-17 16:41:34 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 16:41:34 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 16:41:34 --> upload_no_file_selected
ERROR - 2016-09-17 16:41:53 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-17 16:41:53 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 16:41:53 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 16:41:53 --> upload_no_file_selected
ERROR - 2016-09-17 16:41:53 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 16:41:53 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 16:41:53 --> upload_no_file_selected
ERROR - 2016-09-17 16:41:53 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 16:41:53 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 16:41:53 --> upload_no_file_selected
ERROR - 2016-09-17 16:41:53 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 16:41:53 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 16:41:53 --> upload_no_file_selected
ERROR - 2016-09-17 16:41:53 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 16:41:53 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 16:41:53 --> upload_no_file_selected
ERROR - 2016-09-17 16:41:53 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 16:41:53 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 16:41:53 --> upload_no_file_selected
ERROR - 2016-09-17 16:56:52 --> 404 Page Not Found --> catalogs/2
ERROR - 2016-09-17 17:16:32 --> Query error: Unknown column 'c.catalog_id' in 'where clause'
ERROR - 2016-09-17 17:16:32 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-17 17:16:32 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-17 17:16:42 --> Query error: Unknown column 'p.catalog_id' in 'where clause'
ERROR - 2016-09-17 17:16:42 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-17 17:16:42 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-17 17:38:25 --> Severity: Notice  --> Undefined index: par_page D:\openserver\domains\ci3\application\controllers\catalogs.php 46
ERROR - 2016-09-17 17:38:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 12
ERROR - 2016-09-17 17:38:25 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-17 17:38:25 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-17 17:38:25 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\core\Common.php 441
ERROR - 2016-09-17 17:43:48 --> 404 Page Not Found --> catalogs/1
ERROR - 2016-09-17 17:44:11 --> 404 Page Not Found --> catalogs/1
ERROR - 2016-09-17 17:44:20 --> 404 Page Not Found --> catalogs/1
ERROR - 2016-09-17 17:44:22 --> 404 Page Not Found --> catalogs/1
ERROR - 2016-09-17 18:02:32 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-17 18:02:32 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-17 18:02:32 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-17 18:02:32 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-17 18:02:32 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-17 18:02:32 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-17 18:28:43 --> Severity: Notice  --> Undefined property: Main::$product_model D:\openserver\domains\ci3\application\third_party\MX\Loader.php 279
ERROR - 2016-09-17 18:32:07 --> Query error: Unknown column 'p.product_view' in 'order clause'
ERROR - 2016-09-17 18:32:07 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-17 18:32:07 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-17 18:32:17 --> Query error: Unknown column 'p.product_view' in 'order clause'
ERROR - 2016-09-17 18:32:17 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-17 18:32:17 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-17 18:32:29 --> Query error: Unknown column 'p.product_view' in 'order clause'
ERROR - 2016-09-17 18:32:29 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-17 18:32:29 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-17 18:32:45 --> Query error: Unknown column 'p.product_view' in 'order clause'
ERROR - 2016-09-17 18:32:45 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-17 18:32:45 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-17 18:36:04 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-17 18:36:05 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 18:36:05 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 18:36:05 --> upload_no_file_selected
ERROR - 2016-09-17 18:36:05 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 18:36:05 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 18:36:05 --> upload_no_file_selected
ERROR - 2016-09-17 18:36:05 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 18:36:05 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 18:36:05 --> upload_no_file_selected
ERROR - 2016-09-17 18:36:05 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 18:36:05 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 18:36:05 --> upload_no_file_selected
ERROR - 2016-09-17 18:36:05 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 18:36:05 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 18:36:05 --> upload_no_file_selected
ERROR - 2016-09-17 18:36:36 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-17 18:36:36 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 18:36:36 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 18:36:36 --> upload_no_file_selected
ERROR - 2016-09-17 18:36:36 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 18:36:36 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 18:36:36 --> upload_no_file_selected
ERROR - 2016-09-17 18:36:36 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 18:36:36 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 18:36:36 --> upload_no_file_selected
ERROR - 2016-09-17 18:36:36 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 18:36:36 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 18:36:36 --> upload_no_file_selected
ERROR - 2016-09-17 18:36:36 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 18:36:36 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 18:36:36 --> upload_no_file_selected
ERROR - 2016-09-17 18:36:36 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 18:36:36 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 18:36:36 --> upload_no_file_selected
ERROR - 2016-09-17 18:45:05 --> Severity: Notice  --> Undefined index: cart D:\openserver\domains\ci3\application\views\layout\main.php 180
ERROR - 2016-09-17 18:45:05 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\views\layout\main.php 180
ERROR - 2016-09-17 18:55:20 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-17 18:55:20 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 18:55:20 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 18:55:20 --> upload_no_file_selected
ERROR - 2016-09-17 18:55:20 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 18:55:20 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 18:55:20 --> upload_no_file_selected
ERROR - 2016-09-17 18:55:20 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 18:55:20 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 18:55:20 --> upload_no_file_selected
ERROR - 2016-09-17 18:57:10 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-17 18:57:10 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 18:57:10 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 18:57:10 --> upload_no_file_selected
ERROR - 2016-09-17 18:57:10 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 18:57:10 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 18:57:10 --> upload_no_file_selected
ERROR - 2016-09-17 18:57:10 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 18:57:10 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 18:57:10 --> upload_no_file_selected
ERROR - 2016-09-17 18:57:10 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 18:57:10 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 18:57:10 --> upload_no_file_selected
ERROR - 2016-09-17 18:58:55 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-17 18:58:55 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 18:58:55 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 18:58:55 --> upload_no_file_selected
ERROR - 2016-09-17 18:58:55 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 18:58:55 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 18:58:55 --> upload_no_file_selected
ERROR - 2016-09-17 18:58:55 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 18:58:55 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 18:58:55 --> upload_no_file_selected
ERROR - 2016-09-17 18:58:55 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 18:58:55 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 18:58:55 --> upload_no_file_selected
ERROR - 2016-09-17 18:59:07 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-17 18:59:07 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 18:59:07 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 18:59:07 --> upload_no_file_selected
ERROR - 2016-09-17 18:59:07 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 18:59:07 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 18:59:07 --> upload_no_file_selected
ERROR - 2016-09-17 18:59:07 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 18:59:07 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 18:59:07 --> upload_no_file_selected
ERROR - 2016-09-17 18:59:07 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 18:59:07 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 18:59:07 --> upload_no_file_selected
ERROR - 2016-09-17 18:59:07 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 18:59:07 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 18:59:07 --> upload_no_file_selected
ERROR - 2016-09-17 18:59:17 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-17 18:59:17 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 18:59:17 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 18:59:17 --> upload_no_file_selected
ERROR - 2016-09-17 18:59:17 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 18:59:17 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 18:59:17 --> upload_no_file_selected
ERROR - 2016-09-17 18:59:17 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 18:59:17 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 18:59:17 --> upload_no_file_selected
ERROR - 2016-09-17 18:59:17 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 18:59:17 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 18:59:17 --> upload_no_file_selected
ERROR - 2016-09-17 18:59:17 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 18:59:17 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 18:59:17 --> upload_no_file_selected
ERROR - 2016-09-17 19:02:01 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-17 19:02:01 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 19:02:01 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 19:02:01 --> upload_no_file_selected
ERROR - 2016-09-17 19:02:01 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 19:02:01 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 19:02:01 --> upload_no_file_selected
ERROR - 2016-09-17 19:02:01 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 19:02:01 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 19:02:01 --> upload_no_file_selected
ERROR - 2016-09-17 19:02:01 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 19:02:01 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 19:02:01 --> upload_no_file_selected
ERROR - 2016-09-17 19:11:04 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-17 19:11:04 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-17 19:11:04 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-17 19:11:04 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-17 19:11:04 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-17 19:11:04 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-17 19:11:04 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-17 19:11:04 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-17 19:11:04 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-17 19:11:04 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-17 19:11:04 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-17 19:11:04 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-17 19:11:10 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-17 19:11:10 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-17 19:11:10 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-17 19:11:10 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-17 19:11:13 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-17 19:11:13 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-17 19:13:08 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-17 19:13:08 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 19:13:08 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 19:13:08 --> upload_no_file_selected
ERROR - 2016-09-17 19:13:08 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 19:13:08 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 19:13:08 --> upload_no_file_selected
ERROR - 2016-09-17 19:13:08 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 19:13:08 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 19:13:08 --> upload_no_file_selected
ERROR - 2016-09-17 19:13:08 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 19:13:08 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 19:13:08 --> upload_no_file_selected
ERROR - 2016-09-17 19:13:08 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 19:13:08 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 19:13:08 --> upload_no_file_selected
ERROR - 2016-09-17 19:13:58 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-17 19:13:58 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 19:13:58 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 19:13:58 --> upload_no_file_selected
ERROR - 2016-09-17 19:13:58 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 19:13:58 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 19:13:58 --> upload_no_file_selected
ERROR - 2016-09-17 19:13:58 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 19:13:58 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 19:13:58 --> upload_no_file_selected
ERROR - 2016-09-17 19:13:58 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 19:13:58 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 19:13:58 --> upload_no_file_selected
ERROR - 2016-09-17 19:13:58 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 19:13:58 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 19:13:58 --> upload_no_file_selected
ERROR - 2016-09-17 19:14:11 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-17 19:14:11 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 19:14:11 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 19:14:11 --> upload_no_file_selected
ERROR - 2016-09-17 19:14:11 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 19:14:11 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 19:14:11 --> upload_no_file_selected
ERROR - 2016-09-17 19:14:11 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 19:14:11 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 19:14:11 --> upload_no_file_selected
ERROR - 2016-09-17 19:14:11 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 19:14:11 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 19:14:11 --> upload_no_file_selected
ERROR - 2016-09-17 19:14:11 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 19:14:11 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 19:14:11 --> upload_no_file_selected
ERROR - 2016-09-17 19:14:26 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-17 19:14:26 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 19:14:26 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 19:14:26 --> upload_no_file_selected
ERROR - 2016-09-17 19:14:26 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 19:14:26 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 19:14:26 --> upload_no_file_selected
ERROR - 2016-09-17 19:14:26 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 19:14:26 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 19:14:26 --> upload_no_file_selected
ERROR - 2016-09-17 19:14:26 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 19:14:26 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 19:14:26 --> upload_no_file_selected
ERROR - 2016-09-17 19:14:26 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 19:14:26 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 19:14:26 --> upload_no_file_selected
ERROR - 2016-09-17 19:14:26 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 19:14:26 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 19:14:26 --> upload_no_file_selected
ERROR - 2016-09-17 19:14:34 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-17 19:14:34 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 19:14:34 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 19:14:34 --> upload_no_file_selected
ERROR - 2016-09-17 19:14:34 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 19:14:34 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 19:14:34 --> upload_no_file_selected
ERROR - 2016-09-17 19:14:34 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 19:14:34 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 19:14:34 --> upload_no_file_selected
ERROR - 2016-09-17 19:14:34 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 19:14:34 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 19:14:34 --> upload_no_file_selected
ERROR - 2016-09-17 19:14:34 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 19:14:34 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 19:14:34 --> upload_no_file_selected
ERROR - 2016-09-17 19:14:34 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-17 19:14:34 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-17 19:14:34 --> upload_no_file_selected
