<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-09-13 12:07:42 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 12:07:58 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 12:09:43 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 12:10:14 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 12:11:57 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 12:11:57 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-13 12:11:57 --> Could not find the language line "imglib_invalid_path"
ERROR - 2016-09-13 12:11:57 --> imglib_invalid_path
ERROR - 2016-09-13 12:11:57 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-13 12:11:57 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-13 12:11:57 --> imglib_unsupported_imagecreate
ERROR - 2016-09-13 12:11:57 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-13 12:11:57 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-13 12:11:57 --> imglib_unsupported_imagecreate
ERROR - 2016-09-13 12:11:57 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-13 12:11:57 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-13 12:11:57 --> imglib_unsupported_imagecreate
ERROR - 2016-09-13 12:11:57 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-13 12:11:57 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-13 12:11:57 --> imglib_unsupported_imagecreate
ERROR - 2016-09-13 12:11:57 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-13 12:11:57 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-13 12:11:57 --> imglib_unsupported_imagecreate
ERROR - 2016-09-13 12:11:57 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-13 12:11:57 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-13 12:11:57 --> imglib_unsupported_imagecreate
ERROR - 2016-09-13 12:14:23 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 12:17:45 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 12:19:27 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 12:21:08 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 12:21:08 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-13 12:21:08 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-13 12:21:08 --> imglib_unsupported_imagecreate
ERROR - 2016-09-13 12:21:08 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-13 12:21:08 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-13 12:21:08 --> imglib_unsupported_imagecreate
ERROR - 2016-09-13 12:21:08 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-13 12:21:08 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-13 12:21:08 --> imglib_unsupported_imagecreate
ERROR - 2016-09-13 12:21:08 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-13 12:21:08 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-13 12:21:08 --> imglib_unsupported_imagecreate
ERROR - 2016-09-13 12:21:08 --> Language file contains no data: language/russian/imglib_lang.php
ERROR - 2016-09-13 12:21:08 --> Could not find the language line "imglib_unsupported_imagecreate"
ERROR - 2016-09-13 12:21:08 --> imglib_unsupported_imagecreate
ERROR - 2016-09-13 12:27:59 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 12:28:49 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 12:28:49 --> Severity: Notice  --> Undefined property: products::$Thumb D:\openserver\domains\ci3\system\core\Model.php 52
ERROR - 2016-09-13 12:29:58 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 12:30:19 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 12:33:22 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 12:35:28 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 12:35:28 --> Severity: Warning  --> imagecreatefromjpeg(D:\openserver\domains\ci3\images\products/D:/openserver/domains/ci3/images/products/bosch1-LaHIe8gmwu.jpg): failed to open stream: Invalid argument D:\openserver\domains\ci3\application\libraries\Thumb.php 19
ERROR - 2016-09-13 12:35:28 --> Severity: Warning  --> getimagesize(D:\openserver\domains\ci3\images\products/D:/openserver/domains/ci3/images/products/bosch1-LaHIe8gmwu.jpg): failed to open stream: Invalid argument D:\openserver\domains\ci3\application\libraries\Thumb.php 49
ERROR - 2016-09-13 12:35:28 --> Severity: Warning  --> Division by zero D:\openserver\domains\ci3\application\libraries\Thumb.php 50
ERROR - 2016-09-13 12:35:28 --> Severity: Warning  --> Division by zero D:\openserver\domains\ci3\application\libraries\Thumb.php 53
ERROR - 2016-09-13 12:35:28 --> Severity: Warning  --> imagecreatetruecolor(): Invalid image dimensions D:\openserver\domains\ci3\application\libraries\Thumb.php 63
ERROR - 2016-09-13 12:35:28 --> Severity: Warning  --> imagecopyresampled() expects parameter 1 to be resource, boolean given D:\openserver\domains\ci3\application\libraries\Thumb.php 65
ERROR - 2016-09-13 12:35:28 --> Severity: Warning  --> imagecopyresampled() expects parameter 2 to be resource, boolean given D:\openserver\domains\ci3\application\libraries\Thumb.php 67
ERROR - 2016-09-13 12:35:28 --> Severity: Warning  --> imagejpeg(D:\openserver\domains\ci3\images\products/thumbs/D:/openserver/domains/ci3/images/products/bosch1-LaHIe8gmwu.jpg): failed to open stream: Invalid argument D:\openserver\domains\ci3\application\libraries\Thumb.php 71
ERROR - 2016-09-13 12:35:28 --> Severity: Warning  --> imagecreatefromjpeg(D:\openserver\domains\ci3\images\products/D:/openserver/domains/ci3/images/products/bosch1-LaHIe8gmwu1.jpg): failed to open stream: Invalid argument D:\openserver\domains\ci3\application\libraries\Thumb.php 19
ERROR - 2016-09-13 12:35:28 --> Severity: Warning  --> getimagesize(D:\openserver\domains\ci3\images\products/D:/openserver/domains/ci3/images/products/bosch1-LaHIe8gmwu1.jpg): failed to open stream: Invalid argument D:\openserver\domains\ci3\application\libraries\Thumb.php 49
ERROR - 2016-09-13 12:35:28 --> Severity: Warning  --> Division by zero D:\openserver\domains\ci3\application\libraries\Thumb.php 50
ERROR - 2016-09-13 12:35:28 --> Severity: Warning  --> Division by zero D:\openserver\domains\ci3\application\libraries\Thumb.php 53
ERROR - 2016-09-13 12:35:28 --> Severity: Warning  --> imagecreatetruecolor(): Invalid image dimensions D:\openserver\domains\ci3\application\libraries\Thumb.php 63
ERROR - 2016-09-13 12:35:28 --> Severity: Warning  --> imagecopyresampled() expects parameter 1 to be resource, boolean given D:\openserver\domains\ci3\application\libraries\Thumb.php 65
ERROR - 2016-09-13 12:35:28 --> Severity: Warning  --> imagecopyresampled() expects parameter 2 to be resource, boolean given D:\openserver\domains\ci3\application\libraries\Thumb.php 67
ERROR - 2016-09-13 12:35:28 --> Severity: Warning  --> imagejpeg(D:\openserver\domains\ci3\images\products/thumbs/D:/openserver/domains/ci3/images/products/bosch1-LaHIe8gmwu1.jpg): failed to open stream: Invalid argument D:\openserver\domains\ci3\application\libraries\Thumb.php 71
ERROR - 2016-09-13 12:35:28 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-13 12:35:28 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-13 12:36:43 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 12:36:43 --> Severity: Warning  --> getimagesize(D:\openserver\domains\ci3\images\products/bosch1-VHIvV2aHbR): failed to open stream: No such file or directory D:\openserver\domains\ci3\application\libraries\Thumb.php 49
ERROR - 2016-09-13 12:36:43 --> Severity: Warning  --> Division by zero D:\openserver\domains\ci3\application\libraries\Thumb.php 50
ERROR - 2016-09-13 12:36:43 --> Severity: Warning  --> Division by zero D:\openserver\domains\ci3\application\libraries\Thumb.php 53
ERROR - 2016-09-13 12:36:43 --> Severity: Warning  --> imagecreatetruecolor(): Invalid image dimensions D:\openserver\domains\ci3\application\libraries\Thumb.php 63
ERROR - 2016-09-13 12:36:43 --> Severity: Notice  --> Undefined variable: src D:\openserver\domains\ci3\application\libraries\Thumb.php 65
ERROR - 2016-09-13 12:36:43 --> Severity: Warning  --> imagecopyresampled() expects parameter 1 to be resource, boolean given D:\openserver\domains\ci3\application\libraries\Thumb.php 65
ERROR - 2016-09-13 12:36:43 --> Severity: Warning  --> imagecopyresampled() expects parameter 2 to be resource, boolean given D:\openserver\domains\ci3\application\libraries\Thumb.php 67
ERROR - 2016-09-13 12:36:43 --> Severity: Warning  --> getimagesize(D:\openserver\domains\ci3\images\products/delonghi1-ZAJl4S7Iua): failed to open stream: No such file or directory D:\openserver\domains\ci3\application\libraries\Thumb.php 49
ERROR - 2016-09-13 12:36:43 --> Severity: Warning  --> Division by zero D:\openserver\domains\ci3\application\libraries\Thumb.php 50
ERROR - 2016-09-13 12:36:43 --> Severity: Warning  --> Division by zero D:\openserver\domains\ci3\application\libraries\Thumb.php 53
ERROR - 2016-09-13 12:36:43 --> Severity: Warning  --> imagecreatetruecolor(): Invalid image dimensions D:\openserver\domains\ci3\application\libraries\Thumb.php 63
ERROR - 2016-09-13 12:36:43 --> Severity: Notice  --> Undefined variable: src D:\openserver\domains\ci3\application\libraries\Thumb.php 65
ERROR - 2016-09-13 12:36:43 --> Severity: Warning  --> imagecopyresampled() expects parameter 1 to be resource, boolean given D:\openserver\domains\ci3\application\libraries\Thumb.php 65
ERROR - 2016-09-13 12:36:43 --> Severity: Warning  --> imagecopyresampled() expects parameter 2 to be resource, boolean given D:\openserver\domains\ci3\application\libraries\Thumb.php 67
ERROR - 2016-09-13 12:36:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-13 12:36:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-13 12:38:06 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 12:41:16 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 12:41:16 --> Severity: Warning  --> getimagesize(D:\openserver\domains\ci3\images\products/bosch1-JVqc5P5atb): failed to open stream: No such file or directory D:\openserver\domains\ci3\application\libraries\Thumb.php 49
ERROR - 2016-09-13 12:41:16 --> Severity: Warning  --> Division by zero D:\openserver\domains\ci3\application\libraries\Thumb.php 50
ERROR - 2016-09-13 12:41:16 --> Severity: Warning  --> Division by zero D:\openserver\domains\ci3\application\libraries\Thumb.php 53
ERROR - 2016-09-13 12:41:16 --> Severity: Warning  --> imagecreatetruecolor(): Invalid image dimensions D:\openserver\domains\ci3\application\libraries\Thumb.php 63
ERROR - 2016-09-13 12:41:16 --> Severity: Notice  --> Undefined variable: src D:\openserver\domains\ci3\application\libraries\Thumb.php 65
ERROR - 2016-09-13 12:41:16 --> Severity: Warning  --> imagecopyresampled() expects parameter 1 to be resource, boolean given D:\openserver\domains\ci3\application\libraries\Thumb.php 65
ERROR - 2016-09-13 12:41:16 --> Severity: Warning  --> imagecopyresampled() expects parameter 2 to be resource, boolean given D:\openserver\domains\ci3\application\libraries\Thumb.php 67
ERROR - 2016-09-13 12:41:16 --> Severity: Warning  --> getimagesize(D:\openserver\domains\ci3\images\products/delonghi1-lzxJm8nOgp): failed to open stream: No such file or directory D:\openserver\domains\ci3\application\libraries\Thumb.php 49
ERROR - 2016-09-13 12:41:16 --> Severity: Warning  --> Division by zero D:\openserver\domains\ci3\application\libraries\Thumb.php 50
ERROR - 2016-09-13 12:41:16 --> Severity: Warning  --> Division by zero D:\openserver\domains\ci3\application\libraries\Thumb.php 53
ERROR - 2016-09-13 12:41:16 --> Severity: Warning  --> imagecreatetruecolor(): Invalid image dimensions D:\openserver\domains\ci3\application\libraries\Thumb.php 63
ERROR - 2016-09-13 12:41:16 --> Severity: Notice  --> Undefined variable: src D:\openserver\domains\ci3\application\libraries\Thumb.php 65
ERROR - 2016-09-13 12:41:16 --> Severity: Warning  --> imagecopyresampled() expects parameter 1 to be resource, boolean given D:\openserver\domains\ci3\application\libraries\Thumb.php 65
ERROR - 2016-09-13 12:41:16 --> Severity: Warning  --> imagecopyresampled() expects parameter 2 to be resource, boolean given D:\openserver\domains\ci3\application\libraries\Thumb.php 67
ERROR - 2016-09-13 12:41:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-13 12:41:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-13 12:42:27 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 12:42:27 --> Severity: Warning  --> getimagesize(D:\openserver\domains\ci3\images\products/bosch-NABSlQYByM): failed to open stream: No such file or directory D:\openserver\domains\ci3\application\libraries\Thumb.php 49
ERROR - 2016-09-13 12:42:27 --> Severity: Warning  --> Division by zero D:\openserver\domains\ci3\application\libraries\Thumb.php 50
ERROR - 2016-09-13 12:42:27 --> Severity: Warning  --> Division by zero D:\openserver\domains\ci3\application\libraries\Thumb.php 53
ERROR - 2016-09-13 12:42:27 --> Severity: Warning  --> imagecreatetruecolor(): Invalid image dimensions D:\openserver\domains\ci3\application\libraries\Thumb.php 63
ERROR - 2016-09-13 12:42:27 --> Severity: Notice  --> Undefined variable: src D:\openserver\domains\ci3\application\libraries\Thumb.php 65
ERROR - 2016-09-13 12:42:27 --> Severity: Warning  --> imagecopyresampled() expects parameter 1 to be resource, boolean given D:\openserver\domains\ci3\application\libraries\Thumb.php 65
ERROR - 2016-09-13 12:42:27 --> Severity: Warning  --> imagecopyresampled() expects parameter 2 to be resource, boolean given D:\openserver\domains\ci3\application\libraries\Thumb.php 67
ERROR - 2016-09-13 12:42:27 --> Severity: Warning  --> getimagesize(D:\openserver\domains\ci3\images\products/20000091648-000-00-20000091648-bNBduqVtga): failed to open stream: No such file or directory D:\openserver\domains\ci3\application\libraries\Thumb.php 49
ERROR - 2016-09-13 12:42:27 --> Severity: Warning  --> Division by zero D:\openserver\domains\ci3\application\libraries\Thumb.php 50
ERROR - 2016-09-13 12:42:27 --> Severity: Warning  --> Division by zero D:\openserver\domains\ci3\application\libraries\Thumb.php 53
ERROR - 2016-09-13 12:42:27 --> Severity: Warning  --> imagecreatetruecolor(): Invalid image dimensions D:\openserver\domains\ci3\application\libraries\Thumb.php 63
ERROR - 2016-09-13 12:42:27 --> Severity: Notice  --> Undefined variable: src D:\openserver\domains\ci3\application\libraries\Thumb.php 65
ERROR - 2016-09-13 12:42:27 --> Severity: Warning  --> imagecopyresampled() expects parameter 1 to be resource, boolean given D:\openserver\domains\ci3\application\libraries\Thumb.php 65
ERROR - 2016-09-13 12:42:27 --> Severity: Warning  --> imagecopyresampled() expects parameter 2 to be resource, boolean given D:\openserver\domains\ci3\application\libraries\Thumb.php 67
ERROR - 2016-09-13 12:42:27 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-13 12:42:27 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-13 12:43:02 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 12:44:44 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 12:44:44 --> Severity: Warning  --> imagecreatefromjpeg(D:\openserver\domains\ci3\images\products/20000091648-000-00-20000091648-7qRkRMowb2.jpg): failed to open stream: No such file or directory D:\openserver\domains\ci3\application\libraries\Thumb.php 19
ERROR - 2016-09-13 12:44:44 --> Severity: Warning  --> getimagesize(D:\openserver\domains\ci3\images\products/20000091648-000-00-20000091648-7qRkRMowb2.jpg): failed to open stream: No such file or directory D:\openserver\domains\ci3\application\libraries\Thumb.php 49
ERROR - 2016-09-13 12:44:44 --> Severity: Warning  --> Division by zero D:\openserver\domains\ci3\application\libraries\Thumb.php 50
ERROR - 2016-09-13 12:44:44 --> Severity: Warning  --> Division by zero D:\openserver\domains\ci3\application\libraries\Thumb.php 53
ERROR - 2016-09-13 12:44:44 --> Severity: Warning  --> imagecreatetruecolor(): Invalid image dimensions D:\openserver\domains\ci3\application\libraries\Thumb.php 63
ERROR - 2016-09-13 12:44:44 --> Severity: Warning  --> imagecopyresampled() expects parameter 1 to be resource, boolean given D:\openserver\domains\ci3\application\libraries\Thumb.php 65
ERROR - 2016-09-13 12:44:44 --> Severity: Warning  --> imagecopyresampled() expects parameter 2 to be resource, boolean given D:\openserver\domains\ci3\application\libraries\Thumb.php 67
ERROR - 2016-09-13 12:44:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-13 12:44:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-13 12:45:42 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 12:45:42 --> Severity: Warning  --> imagecreatefromjpeg(D:\openserver\domains\ci3\images\products\20000091648-000-00-20000091648-uDKXQ4VSZJ.jpg): failed to open stream: No such file or directory D:\openserver\domains\ci3\application\libraries\Thumb.php 19
ERROR - 2016-09-13 12:45:42 --> Severity: Warning  --> getimagesize(D:\openserver\domains\ci3\images\products\20000091648-000-00-20000091648-uDKXQ4VSZJ.jpg): failed to open stream: No such file or directory D:\openserver\domains\ci3\application\libraries\Thumb.php 49
ERROR - 2016-09-13 12:45:42 --> Severity: Warning  --> Division by zero D:\openserver\domains\ci3\application\libraries\Thumb.php 50
ERROR - 2016-09-13 12:45:42 --> Severity: Warning  --> Division by zero D:\openserver\domains\ci3\application\libraries\Thumb.php 53
ERROR - 2016-09-13 12:45:42 --> Severity: Warning  --> imagecreatetruecolor(): Invalid image dimensions D:\openserver\domains\ci3\application\libraries\Thumb.php 63
ERROR - 2016-09-13 12:45:42 --> Severity: Warning  --> imagecopyresampled() expects parameter 1 to be resource, boolean given D:\openserver\domains\ci3\application\libraries\Thumb.php 65
ERROR - 2016-09-13 12:45:42 --> Severity: Warning  --> imagecopyresampled() expects parameter 2 to be resource, boolean given D:\openserver\domains\ci3\application\libraries\Thumb.php 67
ERROR - 2016-09-13 12:45:42 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-13 12:45:42 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-13 12:47:56 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 12:47:56 --> Severity: Warning  --> imagecreatefromjpeg(D:\openserver\domains\ci3\images\products\20000091648-000-00-20000091648-GzoKtvjE5Z.jpg): failed to open stream: No such file or directory D:\openserver\domains\ci3\application\libraries\Thumb.php 19
ERROR - 2016-09-13 12:47:56 --> Severity: Warning  --> getimagesize(D:\openserver\domains\ci3\images\products\20000091648-000-00-20000091648-GzoKtvjE5Z.jpg): failed to open stream: No such file or directory D:\openserver\domains\ci3\application\libraries\Thumb.php 49
ERROR - 2016-09-13 12:47:56 --> Severity: Warning  --> Division by zero D:\openserver\domains\ci3\application\libraries\Thumb.php 50
ERROR - 2016-09-13 12:47:56 --> Severity: Warning  --> Division by zero D:\openserver\domains\ci3\application\libraries\Thumb.php 53
ERROR - 2016-09-13 12:47:56 --> Severity: Warning  --> imagecreatetruecolor(): Invalid image dimensions D:\openserver\domains\ci3\application\libraries\Thumb.php 63
ERROR - 2016-09-13 12:47:56 --> Severity: Warning  --> imagecopyresampled() expects parameter 1 to be resource, boolean given D:\openserver\domains\ci3\application\libraries\Thumb.php 65
ERROR - 2016-09-13 12:47:56 --> Severity: Warning  --> imagecopyresampled() expects parameter 2 to be resource, boolean given D:\openserver\domains\ci3\application\libraries\Thumb.php 67
ERROR - 2016-09-13 12:47:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-13 12:47:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-13 12:54:59 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 12:54:59 --> Severity: Warning  --> imagecreatefromjpeg(D:\openserver\domains\ci3\images\products\20000091648-000-00-20000091648-vMYpwsQH8q.jpg): failed to open stream: No such file or directory D:\openserver\domains\ci3\application\libraries\Thumb.php 19
ERROR - 2016-09-13 12:54:59 --> Severity: Warning  --> getimagesize(D:\openserver\domains\ci3\images\products\20000091648-000-00-20000091648-vMYpwsQH8q.jpg): failed to open stream: No such file or directory D:\openserver\domains\ci3\application\libraries\Thumb.php 49
ERROR - 2016-09-13 12:54:59 --> Severity: Warning  --> Division by zero D:\openserver\domains\ci3\application\libraries\Thumb.php 50
ERROR - 2016-09-13 12:54:59 --> Severity: Warning  --> Division by zero D:\openserver\domains\ci3\application\libraries\Thumb.php 53
ERROR - 2016-09-13 12:54:59 --> Severity: Warning  --> imagecreatetruecolor(): Invalid image dimensions D:\openserver\domains\ci3\application\libraries\Thumb.php 63
ERROR - 2016-09-13 12:54:59 --> Severity: Warning  --> imagecopyresampled() expects parameter 1 to be resource, boolean given D:\openserver\domains\ci3\application\libraries\Thumb.php 65
ERROR - 2016-09-13 12:54:59 --> Severity: Warning  --> imagecopyresampled() expects parameter 2 to be resource, boolean given D:\openserver\domains\ci3\application\libraries\Thumb.php 67
ERROR - 2016-09-13 12:54:59 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-13 12:54:59 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-13 12:55:27 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 12:55:27 --> Severity: Warning  --> imagecreatefromjpeg(D:\openserver\domains\ci3\images\products\20000091648-000-00-20000091648-9dsPIz0J03.jpg): failed to open stream: No such file or directory D:\openserver\domains\ci3\application\libraries\Thumb.php 19
ERROR - 2016-09-13 12:55:27 --> Severity: Warning  --> getimagesize(D:\openserver\domains\ci3\images\products\20000091648-000-00-20000091648-9dsPIz0J03.jpg): failed to open stream: No such file or directory D:\openserver\domains\ci3\application\libraries\Thumb.php 49
ERROR - 2016-09-13 12:55:27 --> Severity: Warning  --> Division by zero D:\openserver\domains\ci3\application\libraries\Thumb.php 50
ERROR - 2016-09-13 12:55:27 --> Severity: Warning  --> Division by zero D:\openserver\domains\ci3\application\libraries\Thumb.php 53
ERROR - 2016-09-13 12:55:27 --> Severity: Warning  --> imagecreatetruecolor(): Invalid image dimensions D:\openserver\domains\ci3\application\libraries\Thumb.php 63
ERROR - 2016-09-13 12:55:27 --> Severity: Warning  --> imagecopyresampled() expects parameter 1 to be resource, boolean given D:\openserver\domains\ci3\application\libraries\Thumb.php 65
ERROR - 2016-09-13 12:55:27 --> Severity: Warning  --> imagecopyresampled() expects parameter 2 to be resource, boolean given D:\openserver\domains\ci3\application\libraries\Thumb.php 67
ERROR - 2016-09-13 12:55:27 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-13 12:55:27 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-13 12:56:24 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 12:58:18 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 12:58:53 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 12:58:53 --> Severity: Notice  --> Undefined variable: files D:\openserver\domains\ci3\application\modules\products\models\productss.php 291
ERROR - 2016-09-13 12:58:53 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\models\gallery_model.php 28
ERROR - 2016-09-13 12:59:31 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 13:09:28 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 13:09:28 --> Severity: Notice  --> Undefined index: name D:\openserver\domains\ci3\application\models\gallery_model.php 28
ERROR - 2016-09-13 13:09:28 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\models\gallery_model.php 28
ERROR - 2016-09-13 13:31:23 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 13:32:15 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 13:32:16 --> Severity: Notice  --> Undefined index: name D:\openserver\domains\ci3\application\models\gallery_model.php 28
ERROR - 2016-09-13 13:32:16 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\models\gallery_model.php 28
ERROR - 2016-09-13 13:32:51 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 13:32:51 --> Severity: Notice  --> Undefined index: name D:\openserver\domains\ci3\application\models\gallery_model.php 29
ERROR - 2016-09-13 13:32:51 --> Severity: Notice  --> Undefined index: type D:\openserver\domains\ci3\application\models\gallery_model.php 30
ERROR - 2016-09-13 13:32:51 --> Severity: Notice  --> Undefined index: tmp_name D:\openserver\domains\ci3\application\models\gallery_model.php 31
ERROR - 2016-09-13 13:32:51 --> Severity: Notice  --> Undefined index: error D:\openserver\domains\ci3\application\models\gallery_model.php 32
ERROR - 2016-09-13 13:32:51 --> Severity: Notice  --> Undefined index: size D:\openserver\domains\ci3\application\models\gallery_model.php 33
ERROR - 2016-09-13 13:32:51 --> Severity: Warning  --> strtr() expects parameter 1 to be string, array given D:\openserver\domains\ci3\application\models\gallery_model.php 159
ERROR - 2016-09-13 13:32:51 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 13:32:51 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 13:32:51 --> upload_no_file_selected
ERROR - 2016-09-13 14:24:15 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 14:24:15 --> Severity: Notice  --> Undefined index: name D:\openserver\domains\ci3\application\models\gallery_model.php 29
ERROR - 2016-09-13 14:24:15 --> Severity: Notice  --> Undefined index: type D:\openserver\domains\ci3\application\models\gallery_model.php 30
ERROR - 2016-09-13 14:24:15 --> Severity: Notice  --> Undefined index: tmp_name D:\openserver\domains\ci3\application\models\gallery_model.php 31
ERROR - 2016-09-13 14:24:15 --> Severity: Notice  --> Undefined index: error D:\openserver\domains\ci3\application\models\gallery_model.php 32
ERROR - 2016-09-13 14:24:15 --> Severity: Notice  --> Undefined index: size D:\openserver\domains\ci3\application\models\gallery_model.php 33
ERROR - 2016-09-13 14:24:15 --> Severity: Warning  --> strtr() expects parameter 1 to be string, array given D:\openserver\domains\ci3\application\models\gallery_model.php 159
ERROR - 2016-09-13 14:24:15 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 14:24:15 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 14:24:15 --> upload_no_file_selected
ERROR - 2016-09-13 14:24:53 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 14:26:53 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 14:26:53 --> Severity: Warning  --> strtr() expects parameter 1 to be string, array given D:\openserver\domains\ci3\application\models\gallery_model.php 159
ERROR - 2016-09-13 14:26:53 --> Severity: Warning  --> strtr() expects parameter 1 to be string, array given D:\openserver\domains\ci3\application\models\gallery_model.php 159
ERROR - 2016-09-13 14:26:53 --> Severity: Warning  --> strtr() expects parameter 1 to be string, array given D:\openserver\domains\ci3\application\models\gallery_model.php 159
ERROR - 2016-09-13 14:26:53 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 14:26:53 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 14:26:53 --> upload_no_file_selected
ERROR - 2016-09-13 14:27:27 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 14:27:27 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 14:27:27 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 14:27:27 --> upload_no_file_selected
ERROR - 2016-09-13 14:31:15 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 14:31:15 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 14:31:15 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 14:31:15 --> upload_no_file_selected
ERROR - 2016-09-13 14:33:17 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 14:33:17 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 14:33:17 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 14:33:17 --> upload_no_file_selected
ERROR - 2016-09-13 14:33:46 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 14:35:01 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 14:35:01 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 14:35:01 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 14:35:01 --> upload_no_file_selected
ERROR - 2016-09-13 14:35:10 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 14:35:11 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 14:35:11 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 14:35:11 --> upload_no_file_selected
ERROR - 2016-09-13 14:43:15 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 14:43:15 --> Severity: Warning  --> Illegal offset type in isset or empty D:\openserver\domains\ci3\system\libraries\Upload.php 148
ERROR - 2016-09-13 14:43:15 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 14:43:15 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 14:43:15 --> upload_no_file_selected
ERROR - 2016-09-13 14:48:15 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 14:48:15 --> Severity: Notice  --> Undefined variable: img_name D:\openserver\domains\ci3\application\models\gallery_model.php 58
ERROR - 2016-09-13 14:48:15 --> Severity: Warning  --> imagecreatefromjpeg(D:\openserver\domains\ci3\images\products\.jpg): failed to open stream: No such file or directory D:\openserver\domains\ci3\application\libraries\Thumb.php 19
ERROR - 2016-09-13 14:48:15 --> Severity: Warning  --> getimagesize(D:\openserver\domains\ci3\images\products\.jpg): failed to open stream: No such file or directory D:\openserver\domains\ci3\application\libraries\Thumb.php 49
ERROR - 2016-09-13 14:48:15 --> Severity: Warning  --> Division by zero D:\openserver\domains\ci3\application\libraries\Thumb.php 50
ERROR - 2016-09-13 14:48:15 --> Severity: Warning  --> Division by zero D:\openserver\domains\ci3\application\libraries\Thumb.php 53
ERROR - 2016-09-13 14:48:15 --> Severity: Warning  --> imagecreatetruecolor(): Invalid image dimensions D:\openserver\domains\ci3\application\libraries\Thumb.php 63
ERROR - 2016-09-13 14:48:15 --> Severity: Warning  --> imagecopyresampled() expects parameter 1 to be resource, boolean given D:\openserver\domains\ci3\application\libraries\Thumb.php 65
ERROR - 2016-09-13 14:48:15 --> Severity: Warning  --> imagecopyresampled() expects parameter 2 to be resource, boolean given D:\openserver\domains\ci3\application\libraries\Thumb.php 67
ERROR - 2016-09-13 14:48:15 --> Severity: Notice  --> Undefined variable: img_name D:\openserver\domains\ci3\application\models\gallery_model.php 58
ERROR - 2016-09-13 14:48:15 --> Severity: Warning  --> imagecreatefromjpeg(D:\openserver\domains\ci3\images\products\.jpg): failed to open stream: No such file or directory D:\openserver\domains\ci3\application\libraries\Thumb.php 19
ERROR - 2016-09-13 14:48:15 --> Severity: Warning  --> getimagesize(D:\openserver\domains\ci3\images\products\.jpg): failed to open stream: No such file or directory D:\openserver\domains\ci3\application\libraries\Thumb.php 49
ERROR - 2016-09-13 14:48:15 --> Severity: Warning  --> Division by zero D:\openserver\domains\ci3\application\libraries\Thumb.php 50
ERROR - 2016-09-13 14:48:15 --> Severity: Warning  --> Division by zero D:\openserver\domains\ci3\application\libraries\Thumb.php 53
ERROR - 2016-09-13 14:48:15 --> Severity: Warning  --> imagecreatetruecolor(): Invalid image dimensions D:\openserver\domains\ci3\application\libraries\Thumb.php 63
ERROR - 2016-09-13 14:48:15 --> Severity: Warning  --> imagecopyresampled() expects parameter 1 to be resource, boolean given D:\openserver\domains\ci3\application\libraries\Thumb.php 65
ERROR - 2016-09-13 14:48:15 --> Severity: Warning  --> imagecopyresampled() expects parameter 2 to be resource, boolean given D:\openserver\domains\ci3\application\libraries\Thumb.php 67
ERROR - 2016-09-13 14:48:15 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 14:48:15 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 14:48:15 --> upload_no_file_selected
ERROR - 2016-09-13 14:49:02 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 14:49:03 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 14:49:03 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 14:49:03 --> upload_no_file_selected
ERROR - 2016-09-13 14:52:05 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 14:52:06 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 14:52:06 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 14:52:06 --> upload_no_file_selected
ERROR - 2016-09-13 14:52:06 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 14:52:06 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 14:52:06 --> upload_no_file_selected
ERROR - 2016-09-13 14:52:06 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 14:52:06 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 14:52:06 --> upload_no_file_selected
ERROR - 2016-09-13 14:52:06 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 14:52:06 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 14:52:06 --> upload_no_file_selected
ERROR - 2016-09-13 14:53:24 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 14:53:25 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 14:53:25 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 14:53:25 --> upload_no_file_selected
ERROR - 2016-09-13 14:53:25 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 14:53:25 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 14:53:25 --> upload_no_file_selected
ERROR - 2016-09-13 14:53:25 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 14:53:25 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 14:53:25 --> upload_no_file_selected
ERROR - 2016-09-13 14:53:25 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 14:53:25 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 14:53:25 --> upload_no_file_selected
ERROR - 2016-09-13 14:54:21 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 14:54:21 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 14:54:21 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 14:54:21 --> upload_no_file_selected
ERROR - 2016-09-13 14:54:21 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 14:54:21 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 14:54:21 --> upload_no_file_selected
ERROR - 2016-09-13 14:54:21 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 14:54:21 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 14:54:21 --> upload_no_file_selected
ERROR - 2016-09-13 14:54:21 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 14:54:21 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 14:54:21 --> upload_no_file_selected
ERROR - 2016-09-13 14:55:03 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 14:55:46 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 14:55:46 --> Severity: Warning  --> imagecreatefromjpeg(D:\openserver\domains\ci3\images\products\imgp0015jpg-b3Qi4ddmlV.jpg): failed to open stream: No such file or directory D:\openserver\domains\ci3\application\libraries\Thumb.php 19
ERROR - 2016-09-13 14:55:46 --> Severity: Warning  --> getimagesize(D:\openserver\domains\ci3\images\products\imgp0015jpg-b3Qi4ddmlV.jpg): failed to open stream: No such file or directory D:\openserver\domains\ci3\application\libraries\Thumb.php 49
ERROR - 2016-09-13 14:55:46 --> Severity: Warning  --> Division by zero D:\openserver\domains\ci3\application\libraries\Thumb.php 50
ERROR - 2016-09-13 14:55:46 --> Severity: Warning  --> Division by zero D:\openserver\domains\ci3\application\libraries\Thumb.php 53
ERROR - 2016-09-13 14:55:46 --> Severity: Warning  --> imagecreatetruecolor(): Invalid image dimensions D:\openserver\domains\ci3\application\libraries\Thumb.php 63
ERROR - 2016-09-13 14:55:46 --> Severity: Warning  --> imagecopyresampled() expects parameter 1 to be resource, boolean given D:\openserver\domains\ci3\application\libraries\Thumb.php 65
ERROR - 2016-09-13 14:55:46 --> Severity: Warning  --> imagecopyresampled() expects parameter 2 to be resource, boolean given D:\openserver\domains\ci3\application\libraries\Thumb.php 67
ERROR - 2016-09-13 14:55:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-13 14:55:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-13 14:57:57 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 14:58:00 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 14:58:00 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 14:58:00 --> upload_no_file_selected
ERROR - 2016-09-13 14:58:00 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 14:58:00 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 14:58:00 --> upload_no_file_selected
ERROR - 2016-09-13 14:58:03 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 14:58:03 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 14:58:03 --> upload_no_file_selected
ERROR - 2016-09-13 14:58:03 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 14:58:03 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 14:58:03 --> upload_no_file_selected
ERROR - 2016-09-13 14:58:03 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 14:58:03 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 14:58:03 --> upload_no_file_selected
ERROR - 2016-09-13 14:58:06 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 14:58:06 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 14:58:06 --> upload_no_file_selected
ERROR - 2016-09-13 14:58:06 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 14:58:06 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 14:58:06 --> upload_no_file_selected
ERROR - 2016-09-13 14:58:06 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 14:58:06 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 14:58:06 --> upload_no_file_selected
ERROR - 2016-09-13 14:58:10 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 14:58:10 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 14:58:10 --> upload_no_file_selected
ERROR - 2016-09-13 14:58:10 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 14:58:10 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 14:58:10 --> upload_no_file_selected
ERROR - 2016-09-13 14:58:10 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 14:58:10 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 14:58:10 --> upload_no_file_selected
ERROR - 2016-09-13 15:00:47 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 15:00:49 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 15:00:49 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 15:00:49 --> upload_no_file_selected
ERROR - 2016-09-13 15:00:49 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 15:00:49 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 15:00:49 --> upload_no_file_selected
ERROR - 2016-09-13 15:00:49 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 15:00:49 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 15:00:49 --> upload_no_file_selected
ERROR - 2016-09-13 15:02:35 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-13 15:03:32 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 15:03:34 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 15:03:34 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 15:03:34 --> upload_no_file_selected
ERROR - 2016-09-13 15:03:34 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 15:03:34 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 15:03:34 --> upload_no_file_selected
ERROR - 2016-09-13 15:03:34 --> Language file contains no data: language/russian/upload_lang.php
ERROR - 2016-09-13 15:03:34 --> Could not find the language line "upload_no_file_selected"
ERROR - 2016-09-13 15:03:34 --> upload_no_file_selected
ERROR - 2016-09-13 15:54:23 --> 404 Page Not Found --> catalog/1
ERROR - 2016-09-13 15:55:05 --> 404 Page Not Found --> catalog/1
ERROR - 2016-09-13 15:55:14 --> 404 Page Not Found --> catalog/1
ERROR - 2016-09-13 15:55:20 --> 404 Page Not Found --> catalog/1
ERROR - 2016-09-13 15:57:57 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 16:10:58 --> Could not find the language line "cart_image"
ERROR - 2016-09-13 16:10:59 --> Could not find the language line "cart_image"
ERROR - 2016-09-13 16:11:00 --> Could not find the language line "cart_image"
ERROR - 2016-09-13 16:16:39 --> Could not find the language line "cart_image"
ERROR - 2016-09-13 16:18:08 --> Could not find the language line "cart_image"
ERROR - 2016-09-13 16:18:09 --> Could not find the language line "cart_image"
ERROR - 2016-09-13 16:19:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-13 16:19:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-13 16:19:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-13 16:19:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-13 16:19:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-13 16:19:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-13 16:19:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-13 16:19:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-13 16:19:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-13 16:19:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-13 16:19:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-13 16:19:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-13 16:19:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-13 16:19:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-13 16:19:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-13 16:19:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-13 16:19:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-13 16:19:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-13 16:19:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-13 16:19:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-13 16:19:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-13 16:19:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-13 16:19:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-13 16:19:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-13 16:19:35 --> Could not find the language line "cart_image"
ERROR - 2016-09-13 16:19:36 --> Could not find the language line "cart_image"
ERROR - 2016-09-13 16:19:37 --> Could not find the language line "cart_image"
ERROR - 2016-09-13 16:19:42 --> Could not find the language line "cart_image"
ERROR - 2016-09-13 16:19:44 --> Could not find the language line "cart_image"
ERROR - 2016-09-13 16:19:46 --> Could not find the language line "cart_image"
ERROR - 2016-09-13 16:20:00 --> Language file contains no data: language/russian/email_lang.php
ERROR - 2016-09-13 16:20:00 --> Could not find the language line "email_sent"
ERROR - 2016-09-13 16:20:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-13 16:20:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-13 16:20:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-13 16:20:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-13 16:20:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-13 16:20:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-13 16:20:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-13 16:20:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-13 16:20:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-13 16:20:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-13 16:20:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-13 16:20:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-13 16:20:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-13 16:20:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-13 16:20:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-13 16:20:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-13 16:20:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-13 16:20:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-13 16:20:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-13 16:20:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-13 16:20:06 --> Severity: Notice  --> Undefined index: product_image_front D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-13 16:20:06 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-13 17:12:12 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\posts\views\form.php 81
ERROR - 2016-09-13 17:12:12 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\posts\views\form.php 82
ERROR - 2016-09-13 17:12:59 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\posts\views\form.php 81
ERROR - 2016-09-13 17:12:59 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\posts\views\form.php 82
ERROR - 2016-09-13 17:13:37 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\posts\views\form.php 81
ERROR - 2016-09-13 17:13:37 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\posts\views\form.php 82
ERROR - 2016-09-13 17:13:46 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 17:31:02 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 17:33:09 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-13 17:36:46 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-13 17:37:33 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-13 17:37:34 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-13 17:37:36 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-13 17:38:30 --> Language file contains no data: language/russian/form_validation_lang.php
