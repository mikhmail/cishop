<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-09-07 11:22:16 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 68
ERROR - 2016-09-07 11:22:23 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 68
ERROR - 2016-09-07 11:36:43 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 68
ERROR - 2016-09-07 11:37:54 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 68
ERROR - 2016-09-07 11:41:02 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 68
ERROR - 2016-09-07 11:41:36 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 68
ERROR - 2016-09-07 11:45:11 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 11:46:47 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 11:47:29 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 11:49:33 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 11:49:38 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 11:49:56 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 11:50:03 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-07 11:50:55 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 11:50:55 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-07 11:51:16 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 11:51:17 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-07 11:52:01 --> Query error: Column 'category_id' in where clause is ambiguous
ERROR - 2016-09-07 11:52:01 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 11:52:01 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 11:56:56 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 11:56:57 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-07 11:56:57 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 11:56:58 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-07 11:57:06 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 11:58:42 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 11:59:18 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 11:59:57 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 12:00:00 --> Query error: Column 'category_id' in where clause is ambiguous
ERROR - 2016-09-07 12:00:00 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:00:00 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:00:01 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 12:01:01 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 12:01:23 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 12:01:27 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 12:01:31 --> Query error: Unknown column 'post_id' in 'where clause'
ERROR - 2016-09-07 12:01:31 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:01:31 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:01:34 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 12:02:15 --> Query error: Column 'category_id' in where clause is ambiguous
ERROR - 2016-09-07 12:02:15 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:02:15 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:09:35 --> Query error: Column 'category_id' in where clause is ambiguous
ERROR - 2016-09-07 12:09:35 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:09:35 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:09:42 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 12:09:43 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 12:09:48 --> Query error: Column 'category_id' in where clause is ambiguous
ERROR - 2016-09-07 12:09:48 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:09:48 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:11:01 --> Query error: Column 'category_id' in where clause is ambiguous
ERROR - 2016-09-07 12:11:01 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:11:01 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:12:52 --> Query error: Column 'category_id' in where clause is ambiguous
ERROR - 2016-09-07 12:12:52 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:12:52 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:13:49 --> Query error: Unknown column 'products.id_product' in 'field list'
ERROR - 2016-09-07 12:13:49 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:13:49 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:16:35 --> Query error: Unknown column 'products.id_product' in 'field list'
ERROR - 2016-09-07 12:16:35 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:16:35 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:16:38 --> Query error: Unknown column 'products.id_product' in 'field list'
ERROR - 2016-09-07 12:16:38 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:16:38 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:16:40 --> Query error: Column 'category_id' in where clause is ambiguous
ERROR - 2016-09-07 12:16:40 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:16:40 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:16:41 --> Query error: Unknown column 'products.id_product' in 'field list'
ERROR - 2016-09-07 12:16:41 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:16:41 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:16:42 --> Query error: Unknown column 'products.id_product' in 'field list'
ERROR - 2016-09-07 12:16:42 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:16:42 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:17:58 --> Query error: Unknown column 'products.id_product' in 'field list'
ERROR - 2016-09-07 12:17:58 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:17:58 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:18:00 --> Query error: Unknown column 'products.id_product' in 'field list'
ERROR - 2016-09-07 12:18:00 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:18:00 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:19:48 --> Query error: Unknown column 'products.category_id' in 'field list'
ERROR - 2016-09-07 12:19:48 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:19:48 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:20:13 --> Query error: Unknown column 'products.id_product' in 'field list'
ERROR - 2016-09-07 12:20:13 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:20:13 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:20:15 --> Query error: Unknown column 'products.id_product' in 'field list'
ERROR - 2016-09-07 12:20:15 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:20:15 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:24:21 --> Query error: Column 'category_id' in where clause is ambiguous
ERROR - 2016-09-07 12:24:21 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:24:21 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:24:22 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 12:24:23 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 12:25:15 --> Query error: Column 'category_id' in where clause is ambiguous
ERROR - 2016-09-07 12:25:15 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:25:15 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:28:17 --> Query error: Column 'category_id' in where clause is ambiguous
ERROR - 2016-09-07 12:28:17 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:28:17 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:29:19 --> Query error: Column 'category_id' in where clause is ambiguous
ERROR - 2016-09-07 12:29:19 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:29:19 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:29:21 --> Query error: Column 'category_id' in where clause is ambiguous
ERROR - 2016-09-07 12:29:21 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:29:21 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:29:28 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 12:29:29 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 12:30:40 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 12:30:45 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 12:30:47 --> Query error: Column 'category_id' in where clause is ambiguous
ERROR - 2016-09-07 12:30:47 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:30:47 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:30:49 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 12:30:51 --> Query error: Column 'category_id' in where clause is ambiguous
ERROR - 2016-09-07 12:30:51 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:30:51 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:32:48 --> Query error: Column 'category_id' in where clause is ambiguous
ERROR - 2016-09-07 12:32:48 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:32:48 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:33:03 --> Query error: Column 'category_id' in where clause is ambiguous
ERROR - 2016-09-07 12:33:03 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:33:03 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:33:26 --> Query error: Unknown column 'p.product_active' in 'where clause'
ERROR - 2016-09-07 12:33:26 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:33:26 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:34:48 --> Query error: Column 'category_id' in where clause is ambiguous
ERROR - 2016-09-07 12:34:48 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:34:48 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:35:04 --> Query error: Column 'category_id' in where clause is ambiguous
ERROR - 2016-09-07 12:35:04 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:35:04 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:35:05 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 12:35:06 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 12:35:15 --> Query error: Column 'category_id' in where clause is ambiguous
ERROR - 2016-09-07 12:35:15 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:35:15 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:35:30 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 12:35:31 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 12:48:43 --> Query error: Column 'category_id' in where clause is ambiguous
ERROR - 2016-09-07 12:48:43 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:48:43 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:49:37 --> Severity: Notice  --> Undefined variable: offset D:\openserver\domains\ci3\application\models\user_model.php 61
ERROR - 2016-09-07 12:49:37 --> Severity: Notice  --> Undefined variable: limit D:\openserver\domains\ci3\application\models\user_model.php 61
ERROR - 2016-09-07 12:49:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 9
ERROR - 2016-09-07 12:49:37 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:49:37 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:49:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\core\Common.php 441
ERROR - 2016-09-07 12:50:38 --> Severity: Notice  --> Undefined variable: offset D:\openserver\domains\ci3\application\models\user_model.php 61
ERROR - 2016-09-07 12:50:38 --> Severity: Notice  --> Undefined variable: limit D:\openserver\domains\ci3\application\models\user_model.php 61
ERROR - 2016-09-07 12:50:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 9
ERROR - 2016-09-07 12:50:38 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:50:38 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:50:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\core\Common.php 441
ERROR - 2016-09-07 12:50:39 --> Severity: Notice  --> Undefined variable: offset D:\openserver\domains\ci3\application\models\user_model.php 61
ERROR - 2016-09-07 12:50:39 --> Severity: Notice  --> Undefined variable: limit D:\openserver\domains\ci3\application\models\user_model.php 61
ERROR - 2016-09-07 12:50:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 9
ERROR - 2016-09-07 12:50:39 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 12:50:39 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 12:50:39 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\core\Common.php 441
ERROR - 2016-09-07 12:51:09 --> Severity: Notice  --> Undefined variable: category D:\openserver\domains\ci3\application\controllers\category.php 35
ERROR - 2016-09-07 12:51:09 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\controllers\category.php 35
ERROR - 2016-09-07 12:51:40 --> Severity: Notice  --> Undefined variable: category D:\openserver\domains\ci3\application\controllers\category.php 35
ERROR - 2016-09-07 12:51:40 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\controllers\category.php 35
ERROR - 2016-09-07 12:51:47 --> Severity: Notice  --> Undefined variable: category D:\openserver\domains\ci3\application\controllers\category.php 35
ERROR - 2016-09-07 12:51:47 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\controllers\category.php 35
ERROR - 2016-09-07 12:52:35 --> Severity: Notice  --> Undefined variable: title D:\openserver\domains\ci3\application\views\category\index.php 1
ERROR - 2016-09-07 12:52:55 --> Severity: Notice  --> Undefined variable: title D:\openserver\domains\ci3\application\views\category\index.php 1
ERROR - 2016-09-07 12:53:57 --> Severity: Notice  --> Undefined variable: title D:\openserver\domains\ci3\application\views\category\index.php 1
ERROR - 2016-09-07 12:55:06 --> Severity: Notice  --> Undefined variable: title D:\openserver\domains\ci3\application\views\category\index.php 1
ERROR - 2016-09-07 12:55:21 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 12:55:29 --> Severity: Notice  --> Undefined variable: title D:\openserver\domains\ci3\application\views\category\index.php 1
ERROR - 2016-09-07 12:55:30 --> Severity: Notice  --> Undefined variable: title D:\openserver\domains\ci3\application\views\category\index.php 1
ERROR - 2016-09-07 12:55:32 --> Severity: Notice  --> Undefined variable: title D:\openserver\domains\ci3\application\views\category\index.php 1
ERROR - 2016-09-07 12:55:36 --> Severity: Notice  --> Undefined variable: title D:\openserver\domains\ci3\application\views\category\index.php 1
ERROR - 2016-09-07 12:56:06 --> Severity: Notice  --> Undefined variable: title D:\openserver\domains\ci3\application\views\category\index.php 1
ERROR - 2016-09-07 12:56:19 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 12:56:21 --> Severity: Notice  --> Undefined variable: title D:\openserver\domains\ci3\application\views\category\index.php 1
ERROR - 2016-09-07 12:56:22 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 12:56:26 --> Severity: Notice  --> Undefined variable: title D:\openserver\domains\ci3\application\views\category\index.php 1
ERROR - 2016-09-07 12:59:53 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 13:00:02 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 13:00:07 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 13:09:23 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 13:09:55 --> 404 Page Not Found --> catalogs
ERROR - 2016-09-07 13:10:08 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 13:10:20 --> 404 Page Not Found --> catalogs/1/flowers/0
ERROR - 2016-09-07 13:10:26 --> 404 Page Not Found --> catalogs/1/aa/0
ERROR - 2016-09-07 13:12:23 --> 404 Page Not Found --> catalogs/index/1/aa/0
ERROR - 2016-09-07 13:12:43 --> 404 Page Not Found --> catalogs/index/1/almaznaya_vyshivka/0
ERROR - 2016-09-07 13:13:35 --> Query error: Unknown column 'ck.category_id' in 'on clause'
ERROR - 2016-09-07 13:13:35 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 13:13:35 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 13:14:44 --> Query error: Unknown column 'ck.category_id' in 'on clause'
ERROR - 2016-09-07 13:14:44 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 13:14:44 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 13:16:21 --> Query error: Unknown column 'ck.category_id' in 'on clause'
ERROR - 2016-09-07 13:16:21 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 13:16:21 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 13:17:44 --> Severity: Notice  --> Undefined variable: title D:\openserver\domains\ci3\application\views\category\index.php 1
ERROR - 2016-09-07 13:18:27 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\controllers\catalogs.php 35
ERROR - 2016-09-07 13:19:11 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\controllers\catalogs.php 35
ERROR - 2016-09-07 13:20:14 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 13:20:38 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 13:20:53 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 13:29:48 --> Query error: Unknown column 'category_priority' in 'order clause'
ERROR - 2016-09-07 13:29:48 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 13:29:48 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 13:36:08 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-07 13:38:04 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-07 13:38:14 --> Query error: Unknown column 'post_id' in 'where clause'
ERROR - 2016-09-07 13:38:14 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 13:38:14 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 13:40:40 --> Severity: Notice  --> Undefined property: stdClass::$post_comment_status D:\openserver\domains\ci3\application\views\post\index.php 6
ERROR - 2016-09-07 13:44:42 --> Severity: Notice  --> Undefined property: stdClass::$catalog_url D:\openserver\domains\ci3\application\views\blocks\sidebar.php 15
ERROR - 2016-09-07 13:44:42 --> Severity: Notice  --> Undefined property: stdClass::$catalog_title D:\openserver\domains\ci3\application\views\blocks\sidebar.php 15
ERROR - 2016-09-07 13:46:16 --> Severity: Notice  --> Undefined property: stdClass::$catalog_url D:\openserver\domains\ci3\application\views\blocks\sidebar.php 15
ERROR - 2016-09-07 13:46:16 --> Severity: Notice  --> Undefined property: stdClass::$catalog_title D:\openserver\domains\ci3\application\views\blocks\sidebar.php 15
ERROR - 2016-09-07 13:50:07 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-07 13:53:58 --> Query error: Unknown column 'catalog_priority' in 'order clause'
ERROR - 2016-09-07 13:53:58 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 13:53:58 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 13:55:31 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 13:59:12 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 14:00:29 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 14:03:17 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 14:09:29 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 14:13:17 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 14:15:46 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 14:15:54 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 14:16:10 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 14:17:03 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 14:17:35 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 14:41:02 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 14:42:30 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 14:42:31 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 14:42:37 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 14:43:16 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 14:43:25 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-07 14:43:58 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 14:43:59 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-07 14:44:06 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 14:44:25 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 14:44:35 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 14:44:48 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 14:45:46 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-07 14:46:03 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:46:03 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:46:03 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:46:03 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:46:03 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:46:03 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:46:03 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 14:46:03 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 14:46:03 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 14:46:03 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 14:46:03 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 14:46:03 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 14:46:03 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 6
ERROR - 2016-09-07 14:46:03 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 6
ERROR - 2016-09-07 14:46:34 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:46:34 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:46:34 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:46:34 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:46:34 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:46:34 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:46:34 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 14:46:34 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 14:46:34 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 14:46:34 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 14:46:34 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 14:46:34 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 14:46:34 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 6
ERROR - 2016-09-07 14:46:34 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 6
ERROR - 2016-09-07 14:48:44 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:48:44 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:48:44 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:48:44 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:48:44 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:48:44 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:48:44 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 6
ERROR - 2016-09-07 14:48:44 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 6
ERROR - 2016-09-07 14:50:45 --> Severity: Notice  --> Undefined property: Category::$catalog_model D:\openserver\domains\ci3\application\controllers\category.php 38
ERROR - 2016-09-07 14:51:21 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\views\widgets\products.php 6
ERROR - 2016-09-07 14:51:21 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 6
ERROR - 2016-09-07 14:54:08 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:54:08 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:54:08 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:54:15 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:54:15 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:54:15 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:56:45 --> Severity: Notice  --> Undefined variable: category D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 14:56:45 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 14:56:45 --> Severity: Notice  --> Undefined variable: category D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 14:56:45 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 14:56:45 --> Severity: Notice  --> Undefined variable: category D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 14:56:45 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 14:58:42 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:58:42 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:58:42 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:59:02 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:59:02 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:59:02 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:59:35 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:59:35 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:59:35 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:59:37 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:59:37 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 14:59:37 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 15:00:22 --> Severity: Notice  --> Undefined variable: catalog D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 15:00:22 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 15:00:22 --> Severity: Notice  --> Undefined variable: catalog D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 15:00:22 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 15:00:22 --> Severity: Notice  --> Undefined variable: catalog D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 15:00:22 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 15:00:22 --> Severity: Notice  --> Undefined variable: category D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 15:00:22 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 15:00:22 --> Severity: Notice  --> Undefined variable: category D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 15:00:22 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 15:00:22 --> Severity: Notice  --> Undefined variable: category D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 15:00:22 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 15:00:34 --> Severity: Notice  --> Undefined variable: catalog D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 15:00:34 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 15:00:34 --> Severity: Notice  --> Undefined variable: catalog D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 15:00:34 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 15:00:34 --> Severity: Notice  --> Undefined variable: catalog D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 15:00:34 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 15:00:34 --> Severity: Notice  --> Undefined variable: category D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 15:00:34 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 15:00:34 --> Severity: Notice  --> Undefined variable: category D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 15:00:34 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 15:00:34 --> Severity: Notice  --> Undefined variable: category D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 15:00:34 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 15:00:47 --> Severity: Notice  --> Undefined variable: catalog D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 15:00:47 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 15:00:47 --> Severity: Notice  --> Undefined variable: catalog D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 15:00:47 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 15:00:47 --> Severity: Notice  --> Undefined variable: catalog D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 15:00:47 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 4
ERROR - 2016-09-07 15:00:47 --> Severity: Notice  --> Undefined variable: category D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 15:00:47 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 15:00:47 --> Severity: Notice  --> Undefined variable: category D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 15:00:47 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 15:00:47 --> Severity: Notice  --> Undefined variable: category D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 15:00:47 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\views\widgets\products.php 5
ERROR - 2016-09-07 15:02:56 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 15:03:15 --> Severity: Notice  --> Undefined property: stdClass::$product_comment_status D:\openserver\domains\ci3\application\views\product\index.php 77
ERROR - 2016-09-07 15:13:40 --> Severity: Notice  --> Undefined index: description D:\openserver\domains\ci3\application\views\layout\main.php 7
ERROR - 2016-09-07 15:13:40 --> Severity: Notice  --> Undefined index: keywords D:\openserver\domains\ci3\application\views\layout\main.php 8
ERROR - 2016-09-07 15:14:09 --> Severity: Notice  --> Undefined index: description D:\openserver\domains\ci3\application\views\layout\main.php 7
ERROR - 2016-09-07 15:14:09 --> Severity: Notice  --> Undefined index: keywords D:\openserver\domains\ci3\application\views\layout\main.php 8
ERROR - 2016-09-07 15:15:20 --> Severity: Notice  --> Undefined index: description D:\openserver\domains\ci3\application\views\layout\main.php 7
ERROR - 2016-09-07 15:15:20 --> Severity: Notice  --> Undefined index: keywords D:\openserver\domains\ci3\application\views\layout\main.php 8
ERROR - 2016-09-07 15:16:44 --> Severity: Notice  --> Undefined index: title D:\openserver\domains\ci3\application\views\layout\main.php 6
ERROR - 2016-09-07 15:16:44 --> Severity: Notice  --> Undefined index: description D:\openserver\domains\ci3\application\views\layout\main.php 7
ERROR - 2016-09-07 15:16:44 --> Severity: Notice  --> Undefined index: keywords D:\openserver\domains\ci3\application\views\layout\main.php 8
ERROR - 2016-09-07 15:18:28 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\controllers\product.php 13
ERROR - 2016-09-07 15:18:28 --> Severity: Notice  --> Undefined variable: category D:\openserver\domains\ci3\application\controllers\product.php 14
ERROR - 2016-09-07 15:18:28 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\controllers\product.php 14
ERROR - 2016-09-07 15:18:28 --> Severity: Notice  --> Undefined variable: category D:\openserver\domains\ci3\application\controllers\product.php 15
ERROR - 2016-09-07 15:18:28 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\controllers\product.php 15
ERROR - 2016-09-07 15:19:22 --> Severity: Notice  --> Undefined variable: category D:\openserver\domains\ci3\application\controllers\product.php 16
ERROR - 2016-09-07 15:19:22 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\controllers\product.php 16
ERROR - 2016-09-07 15:19:22 --> Severity: Notice  --> Undefined variable: category D:\openserver\domains\ci3\application\controllers\product.php 17
ERROR - 2016-09-07 15:19:22 --> Severity: Notice  --> Trying to get property of non-object D:\openserver\domains\ci3\application\controllers\product.php 17
ERROR - 2016-09-07 15:21:24 --> Severity: Notice  --> Undefined index: title D:\openserver\domains\ci3\application\views\layout\main.php 6
ERROR - 2016-09-07 15:21:24 --> Severity: Notice  --> Undefined index: description D:\openserver\domains\ci3\application\views\layout\main.php 7
ERROR - 2016-09-07 15:21:24 --> Severity: Notice  --> Undefined index: keywords D:\openserver\domains\ci3\application\views\layout\main.php 8
ERROR - 2016-09-07 15:21:24 --> Severity: Notice  --> Undefined property: stdClass::$post_comment_status D:\openserver\domains\ci3\application\views\post\index.php 6
ERROR - 2016-09-07 15:21:31 --> Severity: Notice  --> Undefined index: title D:\openserver\domains\ci3\application\views\layout\main.php 6
ERROR - 2016-09-07 15:21:31 --> Severity: Notice  --> Undefined index: description D:\openserver\domains\ci3\application\views\layout\main.php 7
ERROR - 2016-09-07 15:21:31 --> Severity: Notice  --> Undefined index: keywords D:\openserver\domains\ci3\application\views\layout\main.php 8
ERROR - 2016-09-07 15:23:41 --> Severity: Notice  --> Undefined index: title D:\openserver\domains\ci3\application\views\layout\main.php 6
ERROR - 2016-09-07 15:23:41 --> Severity: Notice  --> Undefined index: description D:\openserver\domains\ci3\application\views\layout\main.php 7
ERROR - 2016-09-07 15:23:41 --> Severity: Notice  --> Undefined index: keywords D:\openserver\domains\ci3\application\views\layout\main.php 8
ERROR - 2016-09-07 15:24:09 --> Severity: Notice  --> Undefined index: title D:\openserver\domains\ci3\application\views\layout\main.php 6
ERROR - 2016-09-07 15:24:09 --> Severity: Notice  --> Undefined index: description D:\openserver\domains\ci3\application\views\layout\main.php 7
ERROR - 2016-09-07 15:24:09 --> Severity: Notice  --> Undefined index: keywords D:\openserver\domains\ci3\application\views\layout\main.php 8
ERROR - 2016-09-07 15:24:22 --> Severity: Notice  --> Undefined index: title D:\openserver\domains\ci3\application\views\layout\main.php 6
ERROR - 2016-09-07 15:24:22 --> Severity: Notice  --> Undefined index: description D:\openserver\domains\ci3\application\views\layout\main.php 7
ERROR - 2016-09-07 15:24:22 --> Severity: Notice  --> Undefined index: keywords D:\openserver\domains\ci3\application\views\layout\main.php 8
ERROR - 2016-09-07 15:24:24 --> Severity: Notice  --> Undefined index: title D:\openserver\domains\ci3\application\views\layout\main.php 6
ERROR - 2016-09-07 15:24:24 --> Severity: Notice  --> Undefined index: description D:\openserver\domains\ci3\application\views\layout\main.php 7
ERROR - 2016-09-07 15:24:24 --> Severity: Notice  --> Undefined index: keywords D:\openserver\domains\ci3\application\views\layout\main.php 8
ERROR - 2016-09-07 15:24:59 --> Severity: Notice  --> Undefined property: stdClass::$post_comment_status D:\openserver\domains\ci3\application\views\post\index.php 6
ERROR - 2016-09-07 15:25:46 --> Severity: Notice  --> Undefined property: stdClass::$post_comment_status D:\openserver\domains\ci3\application\views\post\index.php 6
ERROR - 2016-09-07 15:25:52 --> Severity: Notice  --> Undefined property: stdClass::$post_comment_status D:\openserver\domains\ci3\application\views\post\index.php 6
ERROR - 2016-09-07 15:25:59 --> Severity: Notice  --> Undefined property: stdClass::$post_comment_status D:\openserver\domains\ci3\application\views\post\index.php 6
ERROR - 2016-09-07 15:26:46 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 15:26:48 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 15:26:56 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 15:26:58 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 15:26:59 --> Severity: Notice  --> Undefined index: title D:\openserver\domains\ci3\application\views\layout\main.php 6
ERROR - 2016-09-07 15:26:59 --> Severity: Notice  --> Undefined index: description D:\openserver\domains\ci3\application\views\layout\main.php 7
ERROR - 2016-09-07 15:26:59 --> Severity: Notice  --> Undefined index: keywords D:\openserver\domains\ci3\application\views\layout\main.php 8
ERROR - 2016-09-07 15:26:59 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 15:28:02 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 15:28:05 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 15:28:07 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 15:28:11 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 15:28:19 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 15:28:20 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 15:28:23 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 15:28:32 --> Query error: Unknown column 'order_message' in 'field list'
ERROR - 2016-09-07 15:28:32 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-07 15:28:32 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-07 15:34:41 --> Language file contains no data: language/russian/email_lang.php
ERROR - 2016-09-07 15:34:41 --> Could not find the language line "email_sent"
ERROR - 2016-09-07 15:43:27 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 15:43:28 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 15:43:30 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 15:43:44 --> Language file contains no data: language/russian/email_lang.php
ERROR - 2016-09-07 15:43:44 --> Could not find the language line "email_sent"
ERROR - 2016-09-07 15:47:51 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 15:47:52 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 15:48:18 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 15:54:30 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 15:54:35 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 15:54:36 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 15:54:40 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 15:54:53 --> Language file contains no data: language/russian/email_lang.php
ERROR - 2016-09-07 15:54:53 --> Could not find the language line "email_sent"
ERROR - 2016-09-07 16:02:54 --> Severity: Notice  --> Undefined index: total  D:\openserver\domains\ci3\application\modules\orders\views\view.php 94
ERROR - 2016-09-07 16:02:54 --> Severity: Notice  --> Undefined index: total  D:\openserver\domains\ci3\application\modules\orders\views\view.php 94
ERROR - 2016-09-07 16:02:54 --> Severity: Notice  --> Undefined index: total  D:\openserver\domains\ci3\application\modules\orders\views\view.php 94
ERROR - 2016-09-07 16:04:09 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 16:06:10 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 16:08:35 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 16:08:46 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 16:09:08 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 16:09:31 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 16:10:19 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 16:10:50 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 16:11:13 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 16:11:55 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 16:12:44 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 16:12:56 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 16:13:01 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 16:20:19 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 16:22:45 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 16:23:54 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 16:24:43 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 16:24:50 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 16:26:09 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 16:41:41 --> Severity: Warning  --> Missing argument 1 for productss::get_all(), called in D:\openserver\domains\ci3\application\modules\orders\views\form.php on line 81 and defined D:\openserver\domains\ci3\application\modules\products\models\productss.php 29
ERROR - 2016-09-07 16:41:41 --> Severity: Warning  --> Missing argument 2 for productss::get_all(), called in D:\openserver\domains\ci3\application\modules\orders\views\form.php on line 81 and defined D:\openserver\domains\ci3\application\modules\products\models\productss.php 29
ERROR - 2016-09-07 16:41:41 --> Severity: Notice  --> Undefined variable: limit D:\openserver\domains\ci3\application\modules\products\models\productss.php 41
ERROR - 2016-09-07 16:41:41 --> Severity: Notice  --> Undefined variable: offset D:\openserver\domains\ci3\application\modules\products\models\productss.php 41
ERROR - 2016-09-07 16:47:17 --> Severity: Warning  --> Illegal offset type in isset or empty D:\openserver\domains\ci3\system\helpers\form_helper.php 320
ERROR - 2016-09-07 16:47:17 --> Severity: Notice  --> Array to string conversion D:\openserver\domains\ci3\system\helpers\form_helper.php 330
ERROR - 2016-09-07 16:47:17 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\system\helpers\form_helper.php 332
ERROR - 2016-09-07 16:47:17 --> Severity: Warning  --> Illegal offset type in isset or empty D:\openserver\domains\ci3\system\helpers\form_helper.php 320
ERROR - 2016-09-07 16:47:17 --> Severity: Notice  --> Array to string conversion D:\openserver\domains\ci3\system\helpers\form_helper.php 330
ERROR - 2016-09-07 16:47:17 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\system\helpers\form_helper.php 332
ERROR - 2016-09-07 16:48:33 --> Severity: Warning  --> Illegal offset type in isset or empty D:\openserver\domains\ci3\system\helpers\form_helper.php 320
ERROR - 2016-09-07 16:48:33 --> Severity: Notice  --> Array to string conversion D:\openserver\domains\ci3\system\helpers\form_helper.php 330
ERROR - 2016-09-07 16:48:33 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\system\helpers\form_helper.php 332
ERROR - 2016-09-07 16:48:33 --> Severity: Warning  --> Illegal offset type in isset or empty D:\openserver\domains\ci3\system\helpers\form_helper.php 320
ERROR - 2016-09-07 16:48:33 --> Severity: Notice  --> Array to string conversion D:\openserver\domains\ci3\system\helpers\form_helper.php 330
ERROR - 2016-09-07 16:48:33 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\system\helpers\form_helper.php 332
ERROR - 2016-09-07 16:48:46 --> Severity: Warning  --> Illegal offset type in isset or empty D:\openserver\domains\ci3\system\helpers\form_helper.php 320
ERROR - 2016-09-07 16:48:46 --> Severity: Notice  --> Array to string conversion D:\openserver\domains\ci3\system\helpers\form_helper.php 330
ERROR - 2016-09-07 16:48:46 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\system\helpers\form_helper.php 332
ERROR - 2016-09-07 16:48:46 --> Severity: Warning  --> Illegal offset type in isset or empty D:\openserver\domains\ci3\system\helpers\form_helper.php 320
ERROR - 2016-09-07 16:48:46 --> Severity: Notice  --> Array to string conversion D:\openserver\domains\ci3\system\helpers\form_helper.php 330
ERROR - 2016-09-07 16:48:46 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\system\helpers\form_helper.php 332
ERROR - 2016-09-07 16:49:49 --> Severity: Notice  --> Undefined index: id_product D:\openserver\domains\ci3\application\modules\orders\views\form.php 96
ERROR - 2016-09-07 16:49:49 --> Severity: Warning  --> Illegal offset type in isset or empty D:\openserver\domains\ci3\system\helpers\form_helper.php 320
ERROR - 2016-09-07 16:49:49 --> Severity: Notice  --> Array to string conversion D:\openserver\domains\ci3\system\helpers\form_helper.php 330
ERROR - 2016-09-07 16:49:49 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\system\helpers\form_helper.php 332
ERROR - 2016-09-07 16:49:49 --> Severity: Notice  --> Undefined index: id_product D:\openserver\domains\ci3\application\modules\orders\views\form.php 96
ERROR - 2016-09-07 16:49:49 --> Severity: Warning  --> Illegal offset type in isset or empty D:\openserver\domains\ci3\system\helpers\form_helper.php 320
ERROR - 2016-09-07 16:49:49 --> Severity: Notice  --> Array to string conversion D:\openserver\domains\ci3\system\helpers\form_helper.php 330
ERROR - 2016-09-07 16:49:49 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\system\helpers\form_helper.php 332
ERROR - 2016-09-07 16:50:05 --> Severity: Warning  --> Illegal offset type in isset or empty D:\openserver\domains\ci3\system\helpers\form_helper.php 320
ERROR - 2016-09-07 16:50:05 --> Severity: Notice  --> Array to string conversion D:\openserver\domains\ci3\system\helpers\form_helper.php 330
ERROR - 2016-09-07 16:50:05 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\system\helpers\form_helper.php 332
ERROR - 2016-09-07 16:50:05 --> Severity: Warning  --> Illegal offset type in isset or empty D:\openserver\domains\ci3\system\helpers\form_helper.php 320
ERROR - 2016-09-07 16:50:05 --> Severity: Notice  --> Array to string conversion D:\openserver\domains\ci3\system\helpers\form_helper.php 330
ERROR - 2016-09-07 16:50:05 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\system\helpers\form_helper.php 332
ERROR - 2016-09-07 16:59:37 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\modules\orders\views\form.php 85
ERROR - 2016-09-07 16:59:37 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\modules\orders\views\form.php 85
ERROR - 2016-09-07 16:59:37 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\modules\orders\views\form.php 85
ERROR - 2016-09-07 16:59:37 --> Severity: Notice  --> Undefined index: id_product D:\openserver\domains\ci3\application\modules\orders\views\form.php 85
ERROR - 2016-09-07 16:59:37 --> Severity: Notice  --> Undefined index: category_title D:\openserver\domains\ci3\application\modules\orders\views\form.php 85
ERROR - 2016-09-07 16:59:37 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\form.php 85
ERROR - 2016-09-07 17:00:03 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\modules\orders\views\form.php 85
ERROR - 2016-09-07 17:00:03 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\modules\orders\views\form.php 85
ERROR - 2016-09-07 17:00:03 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\modules\orders\views\form.php 85
ERROR - 2016-09-07 17:00:03 --> Severity: Notice  --> Undefined index: id_product D:\openserver\domains\ci3\application\modules\orders\views\form.php 85
ERROR - 2016-09-07 17:00:03 --> Severity: Notice  --> Undefined index: category_title D:\openserver\domains\ci3\application\modules\orders\views\form.php 85
ERROR - 2016-09-07 17:00:03 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\form.php 85
ERROR - 2016-09-07 17:00:22 --> Severity: Notice  --> Undefined index: id_product D:\openserver\domains\ci3\application\modules\orders\views\form.php 85
ERROR - 2016-09-07 17:00:22 --> Severity: Notice  --> Undefined index: category_title D:\openserver\domains\ci3\application\modules\orders\views\form.php 85
ERROR - 2016-09-07 17:00:22 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\form.php 85
ERROR - 2016-09-07 17:00:22 --> Severity: Notice  --> Undefined index: id_product D:\openserver\domains\ci3\application\modules\orders\views\form.php 85
ERROR - 2016-09-07 17:00:22 --> Severity: Notice  --> Undefined index: category_title D:\openserver\domains\ci3\application\modules\orders\views\form.php 85
ERROR - 2016-09-07 17:00:22 --> Severity: Notice  --> Undefined index: product_title D:\openserver\domains\ci3\application\modules\orders\views\form.php 85
ERROR - 2016-09-07 17:00:46 --> Severity: Notice  --> Undefined variable: product D:\openserver\domains\ci3\application\modules\orders\views\form.php 85
ERROR - 2016-09-07 17:00:46 --> Severity: Notice  --> Undefined index: id_product D:\openserver\domains\ci3\application\modules\orders\views\form.php 85
ERROR - 2016-09-07 17:00:54 --> Severity: Notice  --> Undefined index: id_product D:\openserver\domains\ci3\application\modules\orders\views\form.php 85
ERROR - 2016-09-07 17:00:54 --> Severity: Notice  --> Undefined index: id_product D:\openserver\domains\ci3\application\modules\orders\views\form.php 85
ERROR - 2016-09-07 17:01:00 --> Severity: Notice  --> Undefined index: id_product D:\openserver\domains\ci3\application\modules\orders\views\form.php 85
ERROR - 2016-09-07 17:01:00 --> Severity: Notice  --> Undefined index: id_product D:\openserver\domains\ci3\application\modules\orders\views\form.php 85
ERROR - 2016-09-07 17:02:13 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 17:02:24 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 17:02:50 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 17:02:57 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 17:12:38 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 17:12:38 --> Could not find the language line "required"
ERROR - 2016-09-07 17:12:49 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 17:12:49 --> Could not find the language line "required"
ERROR - 2016-09-07 17:12:57 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 17:13:31 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 17:13:31 --> Could not find the language line "required"
ERROR - 2016-09-07 17:15:54 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 17:18:16 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 17:18:22 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 17:18:29 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 17:18:39 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 17:21:02 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 17:21:07 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 17:21:08 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 17:21:15 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 17:23:00 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 17:28:48 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 17:39:29 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 17:39:39 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 17:39:39 --> Severity: Notice  --> Undefined variable: order_content D:\openserver\domains\ci3\application\modules\orders\models\orderss.php 268
ERROR - 2016-09-07 17:39:39 --> Severity: Notice  --> Undefined variable: order_content D:\openserver\domains\ci3\application\modules\orders\models\orderss.php 278
ERROR - 2016-09-07 17:39:39 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-07 17:39:39 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-07 17:43:35 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 17:43:35 --> Severity: Notice  --> Undefined variable: order_content D:\openserver\domains\ci3\application\modules\orders\models\orderss.php 269
ERROR - 2016-09-07 17:43:35 --> Severity: Notice  --> Undefined variable: order_content D:\openserver\domains\ci3\application\modules\orders\models\orderss.php 279
ERROR - 2016-09-07 17:43:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-07 17:43:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-07 17:43:44 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 17:44:35 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 17:44:54 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 17:44:54 --> Severity: Notice  --> Undefined variable: order_content D:\openserver\domains\ci3\application\modules\orders\models\orderss.php 269
ERROR - 2016-09-07 17:44:54 --> Severity: Notice  --> Undefined variable: order_content D:\openserver\domains\ci3\application\modules\orders\models\orderss.php 279
ERROR - 2016-09-07 17:44:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-07 17:44:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-07 17:46:10 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 17:46:10 --> Severity: Notice  --> Undefined variable: order_content D:\openserver\domains\ci3\application\modules\orders\models\orderss.php 271
ERROR - 2016-09-07 17:46:10 --> Severity: Notice  --> Undefined variable: order_content D:\openserver\domains\ci3\application\modules\orders\models\orderss.php 281
ERROR - 2016-09-07 17:46:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-07 17:46:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-07 17:48:01 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 17:48:08 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 17:48:08 --> Severity: Notice  --> Undefined variable: order_content D:\openserver\domains\ci3\application\modules\orders\models\orderss.php 271
ERROR - 2016-09-07 17:48:08 --> Severity: Notice  --> Undefined variable: order_content D:\openserver\domains\ci3\application\modules\orders\models\orderss.php 281
ERROR - 2016-09-07 17:48:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-07 17:48:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-07 17:48:20 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 17:48:26 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 17:48:26 --> Severity: Warning  --> addslashes() expects parameter 1 to be string, array given D:\openserver\domains\ci3\application\modules\orders\models\orderss.php 281
ERROR - 2016-09-07 17:48:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\orders\models\orderss.php:271) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-07 17:48:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\orders\models\orderss.php:271) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-07 17:49:08 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 17:49:08 --> Severity: Warning  --> addslashes() expects parameter 1 to be string, array given D:\openserver\domains\ci3\application\modules\orders\models\orderss.php 281
ERROR - 2016-09-07 17:49:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\orders\models\orderss.php:271) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-07 17:49:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\orders\models\orderss.php:271) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-07 17:49:22 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 17:49:22 --> Severity: Warning  --> addslashes() expects parameter 1 to be string, array given D:\openserver\domains\ci3\application\modules\orders\models\orderss.php 281
ERROR - 2016-09-07 17:49:22 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\orders\models\orderss.php:271) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-07 17:49:22 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\orders\models\orderss.php:271) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-07 17:50:00 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 17:50:00 --> Severity: Warning  --> addslashes() expects parameter 1 to be string, array given D:\openserver\domains\ci3\application\modules\orders\models\orderss.php 281
ERROR - 2016-09-07 17:50:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\orders\models\orderss.php:271) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-07 17:50:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\orders\models\orderss.php:271) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-07 17:50:49 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\modules\orders\views\form.php 91
ERROR - 2016-09-07 17:51:18 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\modules\orders\views\view.php 93
ERROR - 2016-09-07 17:52:26 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 17:52:26 --> Severity: Warning  --> addslashes() expects parameter 1 to be string, array given D:\openserver\domains\ci3\application\modules\orders\models\orderss.php 283
ERROR - 2016-09-07 17:52:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-07 17:52:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-07 17:52:51 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 17:52:52 --> Severity: Notice  --> Undefined index: img D:\openserver\domains\ci3\application\modules\orders\views\view.php 95
ERROR - 2016-09-07 17:52:52 --> Severity: Notice  --> Undefined index: name D:\openserver\domains\ci3\application\modules\orders\views\view.php 96
ERROR - 2016-09-07 17:52:52 --> Severity: Notice  --> Undefined index: count D:\openserver\domains\ci3\application\modules\orders\views\view.php 96
ERROR - 2016-09-07 17:52:52 --> Severity: Notice  --> Undefined index: total D:\openserver\domains\ci3\application\modules\orders\views\view.php 96
ERROR - 2016-09-07 17:52:52 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\modules\orders\views\view.php 93
ERROR - 2016-09-07 17:53:10 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\modules\orders\views\view.php 93
ERROR - 2016-09-07 17:53:17 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 17:53:18 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 17:53:20 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 17:53:28 --> Language file contains no data: language/russian/email_lang.php
ERROR - 2016-09-07 17:53:28 --> Could not find the language line "email_sent"
ERROR - 2016-09-07 17:56:30 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 17:56:59 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 17:57:33 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 17:57:39 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 17:57:40 --> Severity: Notice  --> Undefined index: name D:\openserver\domains\ci3\application\modules\orders\views\view.php 96
ERROR - 2016-09-07 17:57:40 --> Severity: Notice  --> Undefined index: count D:\openserver\domains\ci3\application\modules\orders\views\view.php 96
ERROR - 2016-09-07 17:57:40 --> Severity: Notice  --> Undefined index: price D:\openserver\domains\ci3\application\modules\orders\views\view.php 96
ERROR - 2016-09-07 17:57:40 --> Severity: Notice  --> Undefined index: total D:\openserver\domains\ci3\application\modules\orders\views\view.php 96
ERROR - 2016-09-07 17:57:49 --> Severity: Notice  --> Undefined index: count D:\openserver\domains\ci3\application\modules\orders\views\form.php 108
ERROR - 2016-09-07 17:57:49 --> Severity: Notice  --> Undefined index: price D:\openserver\domains\ci3\application\modules\orders\views\form.php 118
ERROR - 2016-09-07 17:57:49 --> Severity: Notice  --> Undefined index: name D:\openserver\domains\ci3\application\modules\orders\views\form.php 128
ERROR - 2016-09-07 17:58:17 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 17:58:56 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 17:58:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\orders\models\orderss.php:276) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-07 17:58:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\orders\models\orderss.php:276) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-07 17:59:09 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 18:00:24 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 18:00:42 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 18:01:39 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 18:01:49 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 18:01:52 --> Severity: Notice  --> Undefined index: count D:\openserver\domains\ci3\application\modules\orders\views\form.php 108
ERROR - 2016-09-07 18:01:52 --> Severity: Notice  --> Undefined index: price D:\openserver\domains\ci3\application\modules\orders\views\form.php 118
ERROR - 2016-09-07 18:01:52 --> Severity: Notice  --> Undefined index: name D:\openserver\domains\ci3\application\modules\orders\views\form.php 128
ERROR - 2016-09-07 18:02:03 --> Severity: Notice  --> Undefined index: name D:\openserver\domains\ci3\application\modules\orders\views\view.php 96
ERROR - 2016-09-07 18:02:03 --> Severity: Notice  --> Undefined index: count D:\openserver\domains\ci3\application\modules\orders\views\view.php 96
ERROR - 2016-09-07 18:02:03 --> Severity: Notice  --> Undefined index: price D:\openserver\domains\ci3\application\modules\orders\views\view.php 96
ERROR - 2016-09-07 18:02:03 --> Severity: Notice  --> Undefined index: total D:\openserver\domains\ci3\application\modules\orders\views\view.php 96
ERROR - 2016-09-07 18:02:12 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 18:02:14 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 18:02:16 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 18:02:26 --> Language file contains no data: language/russian/email_lang.php
ERROR - 2016-09-07 18:02:26 --> Could not find the language line "email_sent"
ERROR - 2016-09-07 18:02:39 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 18:03:27 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 18:03:55 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 18:04:05 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 18:04:25 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 18:05:16 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 18:05:38 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 18:05:47 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 18:06:05 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 18:08:06 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 18:09:04 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 18:09:18 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 18:11:57 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 18:25:10 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 18:25:34 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 18:27:12 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 18:28:16 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 18:28:16 --> Severity: Notice  --> Use of undefined constant product_image_front - assumed 'product_image_front' D:\openserver\domains\ci3\application\modules\orders\models\orderss.php 275
ERROR - 2016-09-07 18:28:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-07 18:28:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-07 18:28:38 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 18:28:45 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 18:29:05 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 18:29:07 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 18:29:09 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 18:29:20 --> Language file contains no data: language/russian/email_lang.php
ERROR - 2016-09-07 18:29:20 --> Could not find the language line "email_sent"
ERROR - 2016-09-07 18:29:32 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 18:30:35 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 18:32:23 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 18:32:38 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 18:39:28 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 18:41:25 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 18:42:41 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 18:43:10 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 18:47:46 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 18:52:16 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 18:52:42 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 18:53:32 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 18:54:04 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 18:54:37 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 18:55:19 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 18:56:26 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 18:56:28 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 18:56:31 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 18:56:33 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 18:56:34 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 18:57:32 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 18:58:12 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 18:58:37 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 18:59:23 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 18:59:50 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 18:59:52 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:01:50 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:02:13 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:02:19 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 19:02:41 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:02:58 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:05:10 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:05:24 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:06:37 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:07:23 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:09:07 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:09:15 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:10:56 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:11:27 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:12:32 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:13:26 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:14:19 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:14:37 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:16:14 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:16:55 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:17:34 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:17:58 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:18:17 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:18:38 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:18:56 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:19:35 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:20:37 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:20:56 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:22:52 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:27:39 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:28:04 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:28:34 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:29:42 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:32:11 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:33:01 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:33:05 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-07 19:33:10 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:33:18 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 19:33:27 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:35:08 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:38:00 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:39:39 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:40:10 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:40:46 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:41:41 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:43:21 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:45:29 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:46:02 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:47:08 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:47:38 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:47:58 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:48:08 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:50:01 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:55:11 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:55:15 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 19:55:22 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 19:55:28 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 19:55:39 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 19:55:46 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 19:56:46 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 19:56:58 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:57:33 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:58:16 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:58:25 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:59:04 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:59:20 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:59:33 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 19:59:47 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 20:00:32 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 20:00:51 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 20:03:34 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 20:03:58 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 21:13:21 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 21:14:37 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 21:14:53 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 21:16:00 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 21:19:41 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 21:20:38 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 21:21:40 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 21:22:29 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 21:23:18 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 21:25:04 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 21:26:26 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 21:27:00 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 21:27:26 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 21:27:34 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 21:28:17 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 21:28:31 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 21:29:26 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 21:29:54 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 21:30:23 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 21:30:54 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 21:31:22 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 21:32:38 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 21:32:48 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 21:32:57 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 21:33:07 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 21:33:25 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 21:33:28 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 21:33:59 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 21:34:26 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 21:34:31 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 21:35:41 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 21:37:04 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 21:37:05 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 21:37:09 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 21:37:12 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 21:37:17 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 21:37:21 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 21:37:27 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 21:37:32 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 21:37:43 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 21:37:59 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 21:38:39 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 21:38:50 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 21:39:05 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 21:39:45 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 21:40:17 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 21:40:22 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 21:40:26 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 21:40:31 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 21:41:26 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 21:41:46 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 21:43:29 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 22:06:32 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 22:06:57 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 22:07:09 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 22:08:20 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 22:08:39 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 22:08:49 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 22:11:38 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 22:11:51 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 22:12:02 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 22:12:16 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 22:12:27 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 22:12:34 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 22:12:40 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 22:12:50 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 22:16:05 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 22:16:39 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 22:17:34 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 22:18:04 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 22:21:05 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 22:21:18 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 22:21:56 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 22:22:00 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 22:22:23 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 22:24:08 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 22:24:40 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-07 22:28:03 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 22:28:14 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 22:29:30 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 22:31:00 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 22:31:17 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 22:31:36 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 22:32:11 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 22:32:19 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 22:32:20 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 22:32:23 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 22:32:48 --> Language file contains no data: language/russian/email_lang.php
ERROR - 2016-09-07 22:32:48 --> Could not find the language line "email_sent"
ERROR - 2016-09-07 22:34:16 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 22:34:48 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 22:43:17 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 22:43:44 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-07 22:48:53 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 22:49:16 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 22:50:13 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 22:50:15 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 22:51:43 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 22:51:44 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 22:51:48 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-07 22:52:00 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 22:52:06 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-07 22:58:42 --> Severity: Notice  --> Undefined index: img D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-07 22:58:42 --> Severity: Notice  --> Undefined index: name D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 22:58:42 --> Severity: Notice  --> Undefined index: count D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 22:58:42 --> Severity: Notice  --> Undefined index: price D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 22:58:42 --> Severity: Notice  --> Undefined index: total D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 22:58:42 --> Severity: Notice  --> Undefined index: img D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-07 22:58:42 --> Severity: Notice  --> Undefined index: name D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 22:58:42 --> Severity: Notice  --> Undefined index: count D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 22:58:42 --> Severity: Notice  --> Undefined index: price D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 22:58:42 --> Severity: Notice  --> Undefined index: total D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 22:58:42 --> Severity: Notice  --> Undefined index: img D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-07 22:58:42 --> Severity: Notice  --> Undefined index: name D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 22:58:42 --> Severity: Notice  --> Undefined index: count D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 22:58:42 --> Severity: Notice  --> Undefined index: price D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 22:58:42 --> Severity: Notice  --> Undefined index: total D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 22:59:05 --> Severity: Notice  --> Undefined index: img D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-07 22:59:05 --> Severity: Notice  --> Undefined index: name D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 22:59:05 --> Severity: Notice  --> Undefined index: count D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 22:59:05 --> Severity: Notice  --> Undefined index: price D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 22:59:05 --> Severity: Notice  --> Undefined index: total D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 22:59:05 --> Severity: Notice  --> Undefined index: img D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-07 22:59:05 --> Severity: Notice  --> Undefined index: name D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 22:59:05 --> Severity: Notice  --> Undefined index: count D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 22:59:05 --> Severity: Notice  --> Undefined index: price D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 22:59:05 --> Severity: Notice  --> Undefined index: total D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 22:59:05 --> Severity: Notice  --> Undefined index: img D:\openserver\domains\ci3\application\modules\orders\views\view.php 98
ERROR - 2016-09-07 22:59:05 --> Severity: Notice  --> Undefined index: name D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 22:59:05 --> Severity: Notice  --> Undefined index: count D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 22:59:05 --> Severity: Notice  --> Undefined index: price D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 22:59:05 --> Severity: Notice  --> Undefined index: total D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 23:00:04 --> Severity: Notice  --> Undefined index: name D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 23:00:04 --> Severity: Notice  --> Undefined index: count D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 23:00:04 --> Severity: Notice  --> Undefined index: price D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 23:00:04 --> Severity: Notice  --> Undefined index: total D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 23:00:04 --> Severity: Notice  --> Undefined index: name D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 23:00:04 --> Severity: Notice  --> Undefined index: count D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 23:00:04 --> Severity: Notice  --> Undefined index: price D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 23:00:04 --> Severity: Notice  --> Undefined index: total D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 23:00:04 --> Severity: Notice  --> Undefined index: name D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 23:00:04 --> Severity: Notice  --> Undefined index: count D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 23:00:04 --> Severity: Notice  --> Undefined index: price D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 23:00:04 --> Severity: Notice  --> Undefined index: total D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 23:00:33 --> Severity: Notice  --> Undefined index: price D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 23:00:33 --> Severity: Notice  --> Undefined index: price D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 23:00:33 --> Severity: Notice  --> Undefined index: price D:\openserver\domains\ci3\application\modules\orders\views\view.php 99
ERROR - 2016-09-07 23:03:57 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 23:04:46 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 23:04:52 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-07 23:10:06 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 23:12:05 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\modules\orders\views\form.php 91
ERROR - 2016-09-07 23:12:41 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\modules\orders\views\form.php 91
ERROR - 2016-09-07 23:16:30 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-07 23:16:51 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 23:16:52 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 23:16:56 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-07 23:17:20 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 23:17:32 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 23:19:53 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 23:20:06 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 23:20:21 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 23:20:22 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 23:20:29 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 23:20:36 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 23:20:42 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 23:20:47 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 23:20:52 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 23:20:55 --> Could not find the language line "cart_image"
ERROR - 2016-09-07 23:21:00 --> Could not find the language line "cart_image"
