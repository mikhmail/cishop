<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-09-08 11:33:17 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\modules\orders\views\form.php 91
ERROR - 2016-09-08 11:35:47 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\modules\orders\views\add.php 91
ERROR - 2016-09-08 11:37:01 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\modules\orders\views\add.php 91
ERROR - 2016-09-08 11:37:21 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\modules\orders\views\add.php 91
ERROR - 2016-09-08 11:39:02 --> Severity: Notice  --> Undefined variable: id_product D:\openserver\domains\ci3\application\modules\orders\views\add.php 91
ERROR - 2016-09-08 11:39:02 --> Severity: Notice  --> Undefined variable: id_product D:\openserver\domains\ci3\application\modules\orders\views\add.php 93
ERROR - 2016-09-08 11:39:02 --> Severity: Notice  --> Undefined variable: id_product D:\openserver\domains\ci3\application\modules\orders\views\add.php 94
ERROR - 2016-09-08 11:39:02 --> Severity: Notice  --> Undefined variable: id_product D:\openserver\domains\ci3\application\modules\orders\views\add.php 98
ERROR - 2016-09-08 11:39:02 --> Severity: Notice  --> Undefined variable: content D:\openserver\domains\ci3\application\modules\orders\views\add.php 103
ERROR - 2016-09-08 11:39:02 --> Severity: Notice  --> Undefined variable: id_product D:\openserver\domains\ci3\application\modules\orders\views\add.php 108
ERROR - 2016-09-08 11:39:02 --> Severity: Notice  --> Undefined variable: id_product D:\openserver\domains\ci3\application\modules\orders\views\add.php 109
ERROR - 2016-09-08 11:39:02 --> Severity: Notice  --> Undefined variable: content D:\openserver\domains\ci3\application\modules\orders\views\add.php 114
ERROR - 2016-09-08 11:39:02 --> Severity: Notice  --> Undefined variable: id_product D:\openserver\domains\ci3\application\modules\orders\views\add.php 119
ERROR - 2016-09-08 11:39:02 --> Severity: Notice  --> Undefined variable: content D:\openserver\domains\ci3\application\modules\orders\views\add.php 124
ERROR - 2016-09-08 11:39:02 --> Severity: Notice  --> Undefined variable: id_product D:\openserver\domains\ci3\application\modules\orders\views\add.php 129
ERROR - 2016-09-08 11:39:02 --> Severity: Notice  --> Undefined variable: content D:\openserver\domains\ci3\application\modules\orders\views\add.php 134
ERROR - 2016-09-08 11:40:27 --> Severity: Notice  --> Undefined variable: id_product D:\openserver\domains\ci3\application\modules\orders\views\add.php 93
ERROR - 2016-09-08 11:40:27 --> Severity: Notice  --> Undefined variable: id_product D:\openserver\domains\ci3\application\modules\orders\views\add.php 94
ERROR - 2016-09-08 11:40:27 --> Severity: Notice  --> Undefined variable: content D:\openserver\domains\ci3\application\modules\orders\views\add.php 103
ERROR - 2016-09-08 11:40:27 --> Severity: Notice  --> Undefined variable: id_product D:\openserver\domains\ci3\application\modules\orders\views\add.php 109
ERROR - 2016-09-08 11:40:27 --> Severity: Notice  --> Undefined variable: content D:\openserver\domains\ci3\application\modules\orders\views\add.php 114
ERROR - 2016-09-08 11:40:27 --> Severity: Notice  --> Undefined variable: content D:\openserver\domains\ci3\application\modules\orders\views\add.php 124
ERROR - 2016-09-08 11:40:27 --> Severity: Notice  --> Undefined variable: content D:\openserver\domains\ci3\application\modules\orders\views\add.php 134
ERROR - 2016-09-08 11:47:48 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-08 11:54:51 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-08 11:54:59 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-08 11:54:59 --> Severity: Notice  --> Array to string conversion D:\openserver\domains\ci3\system\database\drivers\mysqli\mysqli_driver.php 544
ERROR - 2016-09-08 11:54:59 --> Query error: Unknown column 'Array' in 'field list'
ERROR - 2016-09-08 11:54:59 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-08 11:54:59 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-08 11:54:59 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\system\core\Exceptions.php:186) D:\openserver\domains\ci3\system\core\Common.php 441
ERROR - 2016-09-08 11:55:29 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-08 12:06:07 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-08 12:06:07 --> Could not find the language line "required"
ERROR - 2016-09-08 12:07:29 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-08 12:07:45 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-08 12:07:45 --> Could not find the language line "required"
ERROR - 2016-09-08 12:09:28 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-08 12:09:28 --> Could not find the language line "required"
ERROR - 2016-09-08 12:10:43 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-08 12:10:43 --> Could not find the language line "required"
ERROR - 2016-09-08 12:10:55 --> Severity: Notice  --> Undefined index: order_email D:\openserver\domains\ci3\application\modules\orders\views\add.php 88
ERROR - 2016-09-08 12:15:51 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-08 12:15:51 --> Could not find the language line "required"
ERROR - 2016-09-08 12:16:26 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-08 12:16:26 --> Could not find the language line "required"
ERROR - 2016-09-08 12:18:48 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-08 12:18:48 --> Could not find the language line "required"
ERROR - 2016-09-08 12:18:51 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-08 12:18:51 --> Could not find the language line "required"
ERROR - 2016-09-08 12:19:11 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-08 12:19:11 --> Could not find the language line "required"
ERROR - 2016-09-08 12:21:01 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-08 12:21:01 --> Could not find the language line "required"
ERROR - 2016-09-08 12:21:14 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-08 12:21:14 --> Could not find the language line "required"
ERROR - 2016-09-08 12:21:40 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-08 12:22:02 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-08 12:22:02 --> Could not find the language line "required"
ERROR - 2016-09-08 12:22:08 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-08 12:22:08 --> Could not find the language line "required"
ERROR - 2016-09-08 12:22:53 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-08 12:23:03 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-08 12:23:49 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-08 12:34:48 --> 404 Page Not Found --> admin
ERROR - 2016-09-08 12:43:37 --> 404 Page Not Found --> admin
ERROR - 2016-09-08 12:44:57 --> 404 Page Not Found --> admin
ERROR - 2016-09-08 12:46:43 --> 404 Page Not Found --> admin
ERROR - 2016-09-08 12:48:50 --> Severity: Notice  --> Undefined variable: _output D:\openserver\domains\ci3\application\controllers\admin\hidden_admin.php 17
ERROR - 2016-09-08 12:49:22 --> Severity: Notice  --> Undefined variable: css_files D:\openserver\domains\ci3\application\views\admin\main.php 7
ERROR - 2016-09-08 12:49:22 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\views\admin\main.php 7
ERROR - 2016-09-08 12:49:22 --> Severity: Notice  --> Undefined variable: js_files D:\openserver\domains\ci3\application\views\admin\main.php 13
ERROR - 2016-09-08 12:49:22 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\views\admin\main.php 13
ERROR - 2016-09-08 12:49:22 --> Could not find the language line "admin_site"
ERROR - 2016-09-08 12:49:22 --> Could not find the language line "admin_orders"
ERROR - 2016-09-08 12:49:22 --> Could not find the language line "admin_categories"
ERROR - 2016-09-08 12:49:22 --> Could not find the language line "admin_news"
ERROR - 2016-09-08 12:49:22 --> Could not find the language line "admin_blog"
ERROR - 2016-09-08 12:49:22 --> Could not find the language line "admin_products"
ERROR - 2016-09-08 12:49:22 --> Could not find the language line "admin_pages"
ERROR - 2016-09-08 12:49:22 --> Could not find the language line "admin_users"
ERROR - 2016-09-08 12:49:22 --> Could not find the language line "admin_settings"
ERROR - 2016-09-08 12:49:22 --> Could not find the language line "admin_logout"
ERROR - 2016-09-08 12:49:22 --> Severity: Notice  --> Undefined variable: output D:\openserver\domains\ci3\application\views\admin\main.php 38
ERROR - 2016-09-08 12:49:22 --> 404 Page Not Found --> hidden_admin/index
ERROR - 2016-09-08 12:49:36 --> Severity: Notice  --> Undefined variable: css_files D:\openserver\domains\ci3\application\views\admin\main.php 7
ERROR - 2016-09-08 12:49:36 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\views\admin\main.php 7
ERROR - 2016-09-08 12:49:36 --> Severity: Notice  --> Undefined variable: js_files D:\openserver\domains\ci3\application\views\admin\main.php 13
ERROR - 2016-09-08 12:49:36 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\views\admin\main.php 13
ERROR - 2016-09-08 12:49:36 --> Could not find the language line "admin_site"
ERROR - 2016-09-08 12:49:36 --> Could not find the language line "admin_orders"
ERROR - 2016-09-08 12:49:36 --> Could not find the language line "admin_categories"
ERROR - 2016-09-08 12:49:36 --> Could not find the language line "admin_news"
ERROR - 2016-09-08 12:49:36 --> Could not find the language line "admin_blog"
ERROR - 2016-09-08 12:49:36 --> Could not find the language line "admin_products"
ERROR - 2016-09-08 12:49:36 --> Could not find the language line "admin_pages"
ERROR - 2016-09-08 12:49:36 --> Could not find the language line "admin_users"
ERROR - 2016-09-08 12:49:36 --> Could not find the language line "admin_settings"
ERROR - 2016-09-08 12:49:36 --> Could not find the language line "admin_logout"
ERROR - 2016-09-08 12:49:36 --> Severity: Notice  --> Undefined variable: output D:\openserver\domains\ci3\application\views\admin\main.php 38
ERROR - 2016-09-08 12:49:36 --> 404 Page Not Found --> hidden_admin/index
ERROR - 2016-09-08 12:50:04 --> Severity: Notice  --> Undefined variable: css_files D:\openserver\domains\ci3\application\views\admin\main.php 7
ERROR - 2016-09-08 12:50:04 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\views\admin\main.php 7
ERROR - 2016-09-08 12:50:04 --> Severity: Notice  --> Undefined variable: js_files D:\openserver\domains\ci3\application\views\admin\main.php 13
ERROR - 2016-09-08 12:50:04 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\views\admin\main.php 13
ERROR - 2016-09-08 12:50:04 --> Could not find the language line "admin_site"
ERROR - 2016-09-08 12:50:04 --> Could not find the language line "admin_orders"
ERROR - 2016-09-08 12:50:04 --> Could not find the language line "admin_categories"
ERROR - 2016-09-08 12:50:04 --> Could not find the language line "admin_news"
ERROR - 2016-09-08 12:50:04 --> Could not find the language line "admin_blog"
ERROR - 2016-09-08 12:50:04 --> Could not find the language line "admin_products"
ERROR - 2016-09-08 12:50:04 --> Could not find the language line "admin_pages"
ERROR - 2016-09-08 12:50:04 --> Could not find the language line "admin_users"
ERROR - 2016-09-08 12:50:04 --> Could not find the language line "admin_settings"
ERROR - 2016-09-08 12:50:04 --> Could not find the language line "admin_logout"
ERROR - 2016-09-08 12:50:04 --> Severity: Notice  --> Undefined variable: output D:\openserver\domains\ci3\application\views\admin\main.php 38
ERROR - 2016-09-08 12:50:04 --> 404 Page Not Found --> hidden_admin/index
ERROR - 2016-09-08 12:50:23 --> Severity: Notice  --> Undefined variable: css_files D:\openserver\domains\ci3\application\views\admin\main.php 7
ERROR - 2016-09-08 12:50:23 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\views\admin\main.php 7
ERROR - 2016-09-08 12:50:23 --> Severity: Notice  --> Undefined variable: js_files D:\openserver\domains\ci3\application\views\admin\main.php 13
ERROR - 2016-09-08 12:50:23 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\views\admin\main.php 13
ERROR - 2016-09-08 12:50:23 --> Could not find the language line "admin_site"
ERROR - 2016-09-08 12:50:23 --> Could not find the language line "admin_orders"
ERROR - 2016-09-08 12:50:23 --> Could not find the language line "admin_categories"
ERROR - 2016-09-08 12:50:23 --> Could not find the language line "admin_news"
ERROR - 2016-09-08 12:50:23 --> Could not find the language line "admin_blog"
ERROR - 2016-09-08 12:50:23 --> Could not find the language line "admin_products"
ERROR - 2016-09-08 12:50:23 --> Could not find the language line "admin_pages"
ERROR - 2016-09-08 12:50:23 --> Could not find the language line "admin_users"
ERROR - 2016-09-08 12:50:23 --> Could not find the language line "admin_settings"
ERROR - 2016-09-08 12:50:23 --> Could not find the language line "admin_logout"
ERROR - 2016-09-08 12:50:23 --> Severity: Notice  --> Undefined variable: output D:\openserver\domains\ci3\application\views\admin\main.php 38
ERROR - 2016-09-08 12:50:23 --> 404 Page Not Found --> hidden_admin/index
ERROR - 2016-09-08 12:50:30 --> 404 Page Not Found --> admin
ERROR - 2016-09-08 12:50:34 --> Severity: Notice  --> Undefined variable: css_files D:\openserver\domains\ci3\application\views\admin\main.php 7
ERROR - 2016-09-08 12:50:34 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\views\admin\main.php 7
ERROR - 2016-09-08 12:50:34 --> Severity: Notice  --> Undefined variable: js_files D:\openserver\domains\ci3\application\views\admin\main.php 13
ERROR - 2016-09-08 12:50:34 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\application\views\admin\main.php 13
ERROR - 2016-09-08 12:50:34 --> Could not find the language line "admin_site"
ERROR - 2016-09-08 12:50:34 --> Could not find the language line "admin_orders"
ERROR - 2016-09-08 12:50:34 --> Could not find the language line "admin_categories"
ERROR - 2016-09-08 12:50:34 --> Could not find the language line "admin_news"
ERROR - 2016-09-08 12:50:34 --> Could not find the language line "admin_blog"
ERROR - 2016-09-08 12:50:34 --> Could not find the language line "admin_products"
ERROR - 2016-09-08 12:50:34 --> Could not find the language line "admin_pages"
ERROR - 2016-09-08 12:50:34 --> Could not find the language line "admin_users"
ERROR - 2016-09-08 12:50:34 --> Could not find the language line "admin_settings"
ERROR - 2016-09-08 12:50:34 --> Could not find the language line "admin_logout"
ERROR - 2016-09-08 12:50:34 --> Severity: Notice  --> Undefined variable: output D:\openserver\domains\ci3\application\views\admin\main.php 38
ERROR - 2016-09-08 12:50:34 --> 404 Page Not Found --> hidden_admin/index
ERROR - 2016-09-08 12:51:03 --> 404 Page Not Found --> login/logaut
ERROR - 2016-09-08 12:51:33 --> 404 Page Not Found --> admin
ERROR - 2016-09-08 12:53:53 --> 404 Page Not Found --> admin
ERROR - 2016-09-08 13:03:09 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-08 13:05:09 --> Query error: Table 'myshop.remember_tokens' doesn't exist
ERROR - 2016-09-08 13:05:09 --> Language file contains no data: language/russian/db_lang.php
ERROR - 2016-09-08 13:05:09 --> Could not find the language line "db_error_heading"
ERROR - 2016-09-08 13:07:10 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-08 13:08:34 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-08 13:10:18 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-08 13:10:32 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-08 13:11:29 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-08 13:25:04 --> Severity: Notice  --> Undefined index: user_password D:\openserver\domains\ci3\application\modules\users\views\form.php 69
ERROR - 2016-09-08 13:26:18 --> Severity: Notice  --> Undefined index: user_password D:\openserver\domains\ci3\application\modules\users\views\form.php 69
ERROR - 2016-09-08 14:29:52 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-08 14:30:00 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-08 14:30:20 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-08 14:31:53 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-08 14:33:01 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-08 14:35:20 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-08 14:36:52 --> Could not find the language line "cart_image"
ERROR - 2016-09-08 14:36:54 --> Could not find the language line "cart_image"
ERROR - 2016-09-08 14:36:55 --> Could not find the language line "cart_image"
ERROR - 2016-09-08 14:37:08 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-08 14:47:54 --> Could not find the language line "cart_image"
ERROR - 2016-09-08 14:47:55 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-08 14:50:53 --> Could not find the language line "cart_image"
ERROR - 2016-09-08 14:50:54 --> Severity: Notice  --> Undefined variable: delivery_method D:\openserver\domains\ci3\application\views\cart\checkout.php 64
ERROR - 2016-09-08 14:50:54 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\system\helpers\form_helper.php 332
ERROR - 2016-09-08 14:50:54 --> Severity: Notice  --> Undefined variable: payment_method D:\openserver\domains\ci3\application\views\cart\checkout.php 78
ERROR - 2016-09-08 14:50:54 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\openserver\domains\ci3\system\helpers\form_helper.php 332
ERROR - 2016-09-08 14:50:54 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-08 14:51:46 --> Severity: Notice  --> Undefined property: Cart::$orderss D:\openserver\domains\ci3\application\controllers\cart.php 37
ERROR - 2016-09-08 14:52:27 --> Could not find the language line "cart_image"
ERROR - 2016-09-08 14:52:27 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-08 14:53:31 --> Could not find the language line "cart_image"
ERROR - 2016-09-08 14:53:37 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-08 15:05:50 --> Could not find the language line "cart_image"
ERROR - 2016-09-08 15:05:52 --> Could not find the language line "cart_image"
ERROR - 2016-09-08 15:07:06 --> Could not find the language line "cart_image"
ERROR - 2016-09-08 15:07:32 --> Could not find the language line "cart_image"
ERROR - 2016-09-08 15:07:55 --> Could not find the language line "cart_image"
ERROR - 2016-09-08 15:07:58 --> Could not find the language line "cart_image"
ERROR - 2016-09-08 15:08:03 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-08 15:10:29 --> Could not find the language line "cart_image"
ERROR - 2016-09-08 15:10:30 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-08 15:10:49 --> Could not find the language line "cart_image"
ERROR - 2016-09-08 15:10:49 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-08 15:10:59 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-08 15:11:44 --> Could not find the language line "cart_image"
ERROR - 2016-09-08 15:11:44 --> 404 Page Not Found --> additions/fancyBox/lib/jquery.min.map
ERROR - 2016-09-08 15:12:10 --> Severity: Notice  --> Undefined index: message D:\openserver\domains\ci3\application\controllers\cart.php 55
ERROR - 2016-09-08 15:12:11 --> Language file contains no data: language/russian/email_lang.php
ERROR - 2016-09-08 15:12:11 --> Could not find the language line "email_sent"
ERROR - 2016-09-08 15:14:20 --> Language file contains no data: language/russian/form_validation_lang.php
ERROR - 2016-09-08 15:17:25 --> Could not find the language line "cart_image"
ERROR - 2016-09-08 15:17:27 --> Could not find the language line "cart_image"
ERROR - 2016-09-08 15:23:06 --> Could not find the language line "cart_image"
ERROR - 2016-09-08 15:23:07 --> Could not find the language line "cart_image"
ERROR - 2016-09-08 15:23:46 --> Could not find the language line "cart_image"
ERROR - 2016-09-08 15:23:49 --> Could not find the language line "cart_image"
ERROR - 2016-09-08 15:23:50 --> Could not find the language line "cart_image"
ERROR - 2016-09-08 15:24:25 --> Could not find the language line "cart_image"
ERROR - 2016-09-08 15:30:45 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-08 15:31:05 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-08 15:31:07 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-08 15:31:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\dashboard\controllers\dashboard.php:2) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-08 15:31:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\dashboard\controllers\dashboard.php:2) D:\openserver\domains\ci3\system\core\Input.php 287
ERROR - 2016-09-08 15:31:08 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-08 15:31:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\dashboard\controllers\dashboard.php:2) D:\openserver\domains\ci3\system\libraries\Session.php 433
ERROR - 2016-09-08 15:31:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\dashboard\controllers\dashboard.php:2) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-08 15:31:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\dashboard\controllers\dashboard.php:2) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-08 15:31:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\dashboard\controllers\dashboard.php:2) D:\openserver\domains\ci3\system\core\Input.php 287
ERROR - 2016-09-08 15:31:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\dashboard\controllers\dashboard.php:2) D:\openserver\domains\ci3\system\libraries\Session.php 433
ERROR - 2016-09-08 15:31:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\dashboard\controllers\dashboard.php:2) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-08 15:31:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\dashboard\controllers\dashboard.php:2) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-08 15:31:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\dashboard\controllers\dashboard.php:2) D:\openserver\domains\ci3\system\core\Input.php 287
ERROR - 2016-09-08 15:32:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\dashboard\controllers\dashboard.php:2) D:\openserver\domains\ci3\system\libraries\Session.php 433
ERROR - 2016-09-08 15:32:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\dashboard\controllers\dashboard.php:2) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-08 15:32:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\dashboard\controllers\dashboard.php:2) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-08 15:32:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\dashboard\controllers\dashboard.php:2) D:\openserver\domains\ci3\system\core\Input.php 287
ERROR - 2016-09-08 15:32:02 --> 404 Page Not Found --> login/logout
ERROR - 2016-09-08 15:32:05 --> 404 Page Not Found --> login/logout
ERROR - 2016-09-08 15:43:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\dashboard\controllers\dashboard.php:2) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-08 15:44:15 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\dashboard\controllers\dashboard.php:2) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-08 15:44:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\dashboard\controllers\dashboard.php:2) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-08 15:44:31 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\dashboard\controllers\dashboard.php:2) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-08 15:49:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\dashboard\controllers\dashboard.php:2) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-08 15:49:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\dashboard\controllers\dashboard.php:2) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-08 15:56:21 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\dashboard\controllers\dashboard.php:2) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-08 15:56:24 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\dashboard\controllers\dashboard.php:2) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-08 15:59:05 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\dashboard\controllers\dashboard.php:2) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-08 15:59:06 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\dashboard\controllers\dashboard.php:2) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-08 15:59:09 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\dashboard\controllers\dashboard.php:2) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-08 16:10:21 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\dashboard\controllers\dashboard.php:2) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-08 16:15:08 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-08 16:15:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\dashboard\controllers\dashboard.php:2) D:\openserver\domains\ci3\system\libraries\Session.php 433
ERROR - 2016-09-08 16:15:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\dashboard\controllers\dashboard.php:2) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-08 16:15:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\dashboard\controllers\dashboard.php:2) D:\openserver\domains\ci3\system\helpers\url_helper.php 543
ERROR - 2016-09-08 16:15:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\dashboard\controllers\dashboard.php:2) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-08 16:15:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\dashboard\controllers\dashboard.php:2) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-08 16:15:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\openserver\domains\ci3\application\modules\dashboard\controllers\dashboard.php:2) D:\openserver\domains\ci3\system\libraries\Session.php 689
ERROR - 2016-09-08 16:22:19 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\posts\views\form.php 81
ERROR - 2016-09-08 16:22:19 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\posts\views\form.php 82
ERROR - 2016-09-08 16:24:02 --> 404 Page Not Found --> admin
ERROR - 2016-09-08 16:25:15 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\posts\views\form.php 81
ERROR - 2016-09-08 16:25:15 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\posts\views\form.php 82
ERROR - 2016-09-08 16:25:20 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\posts\views\form.php 81
ERROR - 2016-09-08 16:25:20 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\posts\views\form.php 82
ERROR - 2016-09-08 16:28:04 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\posts\views\form.php 81
ERROR - 2016-09-08 16:28:04 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\posts\views\form.php 82
ERROR - 2016-09-08 16:28:23 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\posts\views\form.php 81
ERROR - 2016-09-08 16:28:23 --> Severity: Notice  --> Undefined index: post_status D:\openserver\domains\ci3\application\modules\posts\views\form.php 82
ERROR - 2016-09-08 16:36:32 --> 404 Page Not Found --> assets/bootstrap/css/bootstrap.min.css.map
ERROR - 2016-09-08 16:37:24 --> Could not find the language line "cart_image"
ERROR - 2016-09-08 16:37:47 --> Could not find the language line "contact_new_message"
ERROR - 2016-09-08 16:37:47 --> Could not find the language line "contact_new_message"
ERROR - 2016-09-08 16:37:48 --> Language file contains no data: language/russian/email_lang.php
ERROR - 2016-09-08 16:37:48 --> Could not find the language line "email_sent"
ERROR - 2016-09-08 16:37:48 --> Severity: Notice  --> Undefined index: title D:\openserver\domains\ci3\application\views\layout\main.php 6
ERROR - 2016-09-08 16:37:48 --> Severity: Notice  --> Undefined index: description D:\openserver\domains\ci3\application\views\layout\main.php 7
ERROR - 2016-09-08 16:37:48 --> Severity: Notice  --> Undefined index: keywords D:\openserver\domains\ci3\application\views\layout\main.php 8
ERROR - 2016-09-08 16:37:48 --> Could not find the language line "contact_message_send"
ERROR - 2016-09-08 16:39:49 --> Could not find the language line "contact_new_message"
ERROR - 2016-09-08 16:39:49 --> Could not find the language line "contact_new_message"
ERROR - 2016-09-08 16:39:50 --> Language file contains no data: language/russian/email_lang.php
ERROR - 2016-09-08 16:39:50 --> Could not find the language line "email_sent"
ERROR - 2016-09-08 16:39:50 --> Could not find the language line "contact_message_send"
ERROR - 2016-09-08 16:41:56 --> Could not find the language line "contact_new_message"
ERROR - 2016-09-08 16:41:56 --> Could not find the language line "contact_new_message"
ERROR - 2016-09-08 16:41:56 --> Language file contains no data: language/russian/email_lang.php
ERROR - 2016-09-08 16:41:56 --> Could not find the language line "email_sent"
ERROR - 2016-09-08 16:42:17 --> Could not find the language line "contact_new_message"
ERROR - 2016-09-08 16:42:17 --> Could not find the language line "contact_new_message"
ERROR - 2016-09-08 16:42:17 --> Language file contains no data: language/russian/email_lang.php
ERROR - 2016-09-08 16:42:17 --> Could not find the language line "email_sent"
